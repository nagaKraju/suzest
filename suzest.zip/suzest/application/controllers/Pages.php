<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
    function __construct() {

        parent::__construct();

        // Load Countries Library
        $this->load->library(array('Countries_Lib', 'Categories_Lib'));
    }

/**
 * _remap method
 *
 * @param string $method, array $params
 * @return void
 */
    public function _remap($method, $params = array()) {

        if(method_exists($this, $method)) {

            return call_user_func_array(array($this, $method), $params);
        }

        return show_404();
    }

/**
 * index method
 *
 * @return void
 */
    public function index() {

        return $this->load->view($this->config->item('template_view'));
    }

/**
 * register method
 *
 * @return void
 */
    public function register() {

        // Get countries list
        $data['countries'] = $this->countries_lib->get_all_countries_list(1);

        // Get zones list
        $data['zones'] = $this->countries_lib->get_all_zones_list(1);

        // Get categories list
        $data['categories'] = $this->categories_lib->get_all_categories_list(1);

        return $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * suzest_id method
 *
 * @return void
 */
    public function suzest_id() {

        // Get categories list
        $data['categories'] = $this->categories_lib->get_all_categories_list(1);

        return $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * map method
 *
 * @return void
 */
    public function map() {

        // Set validation rules
        $this->form_validation->set_rules('geocode', 'suzest id', 'trim|required');

        // Run validation
        if($this->form_validation->run() == false) {

            return $this->load->view($this->config->item('template_view'));
        }

        $data = $this->countries_lib->get_geocode($this->input->post('geocode'));

        return $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * ajax_get_all_states_by_country_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_all_states_by_country_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get states by country id
        $states = $this->countries_lib->get_all_states_by_country_id($this->input->post('country_id'))->result();
        $result = array(
            'response' => true,
            'states' => $states
        );
        echo json_encode($result);
    }

/**
 * ajax_get_all_districts_by_state_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_all_districts_by_state_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get districts by country id
        $districts = $this->countries_lib->get_all_districts_by_state_id($this->input->post('state_id'))->result();
        $result = array(
            'response' => true,
            'districts' => $districts
        );
        echo json_encode($result);
    }

/**
 * ajax_get_all_mandals_by_zone_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_all_mandals_by_district_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get mandals by district id and zone id
        $mandals = $this->countries_lib->get_all_mandals_by_district_id($this->input->post('district_id'))->result();
        $result = array(
            'response' => true,
            'mandals' => $mandals
        );
        echo json_encode($result);
    }

    /**
     * ajax_get_zones_by_mandal_id method
     *
     * @throws error
     * @return void
     */
    public function ajax_get_zone_by_mandal_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get zones by state_id
        $zones = $this->countries_lib->get_zone_by_mandal_id($this->input->post('mandal_id'))->result();

        $result = array(
            'response' => true,
            'zones' => $zones
        );
        echo json_encode($result);
        return;
    }
/**
 * ajax_add_property method
 *
 * @throws error
 * @return void
 */
    public function ajax_add_property() {
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Validation rules
        $this->form_validation->set_rules('country_id', 'country', 'trim|required|numeric');
        $this->form_validation->set_rules('district_id', 'district', 'trim|required|numeric');
        $this->form_validation->set_rules('zone_id', 'zone', 'trim|required|numeric');
        $this->form_validation->set_rules('mandal_id', 'mandal', 'trim|required|numeric');
        $this->form_validation->set_rules('pincode', 'pincode', 'trim|required|numeric');
        if($this->input->post('category_id') == 1) {
            $this->form_validation->set_rules('flat_number', 'flat number', 'trim|required');
            $this->form_validation->set_rules('apartment_number', 'apartment number', 'trim|required');
            $this->form_validation->set_rules('apartment_name', 'apartment name', 'trim|required');
        } else {
            $this->form_validation->set_rules('door_number', 'door number', 'trim|required');
            $this->form_validation->set_rules('area', 'area', 'trim|required');
        }

        $this->form_validation->set_rules('street_name', 'street name', 'trim|required');
        $this->form_validation->set_rules('agree', 'agree', 'trim|required');

        // Run validation
        if($this->form_validation->run() === false) {

            $result = array(
                'response' => false,
                'message' => 'Find the below validation errors',
                'validations' => array(
                            'country_id' => form_error('country_id', '<label class="error">', '</label>'),
                            'state_id' => form_error('state_id', '<label class="error">', '</label>'),
                            'district_id' => form_error('district_id', '<label class="error">', '</label>'),
                            'zone_id' => form_error('zone_id', '<label class="error">', '</label>'),
                            'mandal_id' => form_error('mandal_id', '<label class="error">', '</label>'),
                            'pincode' => form_error('pincode', '<label class="error">', '</label>'),
                            'flat_number' => form_error('flat_number', '<label class="error">', '</label>'),
                            'apartment_number' => form_error('apartment_number', '<label class="error">', '</label>'),
                            'apartment_name' => form_error('apartment_name', '<label class="error">', '</label>'),
                            'door_number' => form_error('door_number', '<label class="error">', '</label>'),
                            'area' => form_error('area', '<label class="error">', '</label>'),
                            'street_name' => form_error('street_name', '<label class="error">', '</label>'),
                            'agree' => form_error('agree', '<label class="error">', '</label>')
                )
            );
            echo json_encode($result);
            return;
        }
        // Get State Code By State ID
        $state_code = $this->countries_lib->get_state_code_by_state_id($this->input->post('state_id'), 1)->row()->code;
        // Get Zone Code By Zone ID
        $zone_code = $this->countries_lib->get_zone_code_by_zone_id($this->input->post('zone_id'), 1)->row()->code;

        $district_id = (($this->input->post('district_id') < 10) ? '0'.$this->input->post('district_id') : $this->input->post('district_id'));
        $Two_Numeric = rand(10, 99);
        $Three_Alphabetic =  substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZAABBCCDDEEFFGGHHIIJJKKLLNMMNNOOPPQQRRSSTTUUVVWWXXYYZZABBCCDEFFGGHHIJKKLLMMNNOOPPQQRRSSTTUUVWXXYYZZabcdefghijklmnopqrstuvwxyz"), 0, 3);

        //Generate Unique ID
        $unique_id = $state_code.$district_id.$zone_code.'-'.$Two_Numeric.$Three_Alphabetic;

        // property data
        $property = array(
            'unique_id' => $unique_id,
            'category_id' => $this->input->post('category_id'),
            'country_id' => $this->input->post('country_id'),
            'state_id' => $this->input->post('state_id'),
            'district_id' => $this->input->post('district_id'),
            'zone_id' => $this->input->post('zone_id'),
            'mandal_id' => $this->input->post('mandal_id'),
            'pincode' => $this->input->post('pincode'),
            'flat_number' => $this->input->post('flat_number'),
            'apartment_number' => $this->input->post('apartment_number'),
            'apartment_name' => $this->input->post('apartment_name'),
            'door_number' => $this->input->post('door_number'),
            'area' => $this->input->post('area'),
            'street_name' => $this->input->post('street_name'),
            'agree' => $this->input->post('agree')
        );

        // add data
        if($uid = $this->countries_lib->add_property($property)) {

            $result = array(
                'response' => true,
                'uid' => $uid,
                'message' => 'The Property Could Be Added Successfully'
            );
            echo json_encode($result);
            return;
        }

        $result = array(
            'response' => false,
            'message' => 'The Property Could Not Be Added'
        );
        echo json_encode($result);
        return;
    }

/**
 * ajax_get_suzest_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_suzest_id() {
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Validation rules
        $this->form_validation->set_rules('phone_number', 'phone number', 'trim|required');
        if($this->input->post('category_id') == 1) {
            $this->form_validation->set_rules('flat_number', 'flat number', 'trim|required');
            $this->form_validation->set_rules('apartment_number', 'apartment number', 'trim|required');
        } else {
            $this->form_validation->set_rules('door_number', 'door number', 'trim|required');
        }

        // Run validation
        if($this->form_validation->run() === false) {

            $result = array(
                'response' => false,
                'message' => 'Find the below validation errors',
                'validations' => array(
                    'phone_number' => form_error('phone_number', '<label class="error">', '</label>'),
                    'flat_number' => form_error('flat_number', '<label class="error">', '</label>'),
                    'apartment_number' => form_error('apartment_number', '<label class="error">', '</label>'),
                    'door_number' => form_error('door_number', '<label class="error">', '</label>'),
                )
            );
            echo json_encode($result);
            return;
        }

        // Suzest Id Data
        $suzest = array(
            'phone_number' => $this->input->post('phone_number'),
            'flat_number' => $this->input->post('flat_number'),
            'apartment_number' => $this->input->post('apartment_number'),
            'door_number' => $this->input->post('door_number'),
        );

        // update data
        if($uid = $this->countries_lib->update_property($suzest)) {

            $result = array(
                'response' => true,
                'uid' => $uid,
                'message' => 'Your\'s Phone Number Updated Successfully!!!'
            );
            echo json_encode($result);
            return;
        }

        $result = array(
            'response' => false,
            'message' => 'Suzest Id Not Available!!!'
        );
        echo json_encode($result);
        return;
    }

/**
 * ajax_flat_number_available_for_registration method
 *
 * @return void
 */
    public function ajax_flat_number_available_for_registration() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            echo 'false';
            return;
        }

        // Flat Number
        $flat_number = $this->input->post('flat_number');
        $apartment_number = $this->input->post('apartment_number');

        if(!$this->countries_lib->get_flat_number_available_for_registration($flat_number, $apartment_number)) {

			echo 'false';
        	return;
		}
		
		echo 'true';
        return;
    }

/**
 * ajax_door_number_available_for_registration method
 *
 * @return void
 */
    public function ajax_door_number_available_for_registration() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            echo 'false';
            return;
        }

        // Door Number
        $door_number = $this->input->post('door_number');

        if(!$this->countries_lib->get_door_number_available_for_registration($door_number)) {

			echo 'false';
        	return;
		}
		
		echo 'true';
        return;
    }

    /**
     * _check_email_exist_for_session_in_demo_class method
     *
     * @return void
     */
    function _check_email_exist_for_session_in_demo_class() {

        // Email
        $email = $this->input->post('email');
        $session_id = $this->input->post('session_id');

        // Check session_id is 0
        if($session_id == 0) {

            return true;
        }

        if($this->zl_forms->email_available_for_session_in_demo_class($email, $session_id)) {

            $this->form_validation->set_message('_check_email_exist_for_session_in_demo_class', 'You\'ve registered for this date.');
            return false;
        }

        return true;
    }
}

/* End of file pages.php */
/* Location: ./application/controllers/pages.php */