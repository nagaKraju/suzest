<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forms extends CI_Controller {

    public $_cleanup;

/**
* construct method
*
* @return void
*/
	function __construct() {

		parent::__construct();

		// Load Forms_Lib library
		$this->load->library('Forms_Lib');
	}

/**
* _remap method
*
* @param string $method
* @return void
*/
    public function _remap($method) {
        
        if(method_exists($this, $method)) {

            return $this->$method();
        }

        return show_404();
    }

/**
 * ajax_add_contact_us method
 *
 * @return void
 */
    public function ajax_add_contact_us() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
               
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Validation rules
        $this->form_validation->set_rules('name', 'name', 'trim|required');
        $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
        $this->form_validation->set_rules('phone', 'phone number', 'trim|required|numeric');
        $this->form_validation->set_rules('message', 'message', 'trim|required');
        $this->form_validation->set_rules('company', 'company name', 'trim|required');

        // Run validation
        if($this->form_validation->run() === false) {

            $result = array(
                'response' => false,
                'message' => $this->config->item('contact_us_failure_message'),
                'validations' => array(
                    'name' => form_error('name', '<label class="error" for="name">', '</label>'),
                    'email' => form_error('email', '<label class="error" for="email">', '</label>'),
                    'phone' => form_error('phone', '<label class="error" for="phone">', '</label>'),
                    'message' => form_error('message', '<label class="error" for="message">', '</label>'),
                    'company' => form_error('company', '<label class="error" for="company">', '</label>')
                )
            ); 
            echo json_encode($result);
            return;
        }

        // Contact us data
        $contact_us = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'phone' => $this->input->post('phone'),
            'message' => $this->input->post('message'),
            'company' => $this->input->post('company')
        );

        // Send mail and insert data
        if($this->forms_lib->add_contact_us_and_send_mail($contact_us)) {

            $result = array(
                'response' => true,
                'message' => $this->config->item('contact_us_success_message')
            );
            echo json_encode($result);
            return;
        }

        $result = array(
            'response' => false,
            'message' => $this->config->item('contact_us_failure_message')
        );
        echo json_encode($result);
        return;
    }
}

/* End of file forms.php */
/* Location: ./application/controllers/forms.php */