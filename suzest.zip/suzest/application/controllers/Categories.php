<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
    function __construct() {

        parent::__construct();

        // Load Categories Library
        $this->load->library(array('Categories_Lib'));
    }

/**
 * _remap method
 *
 * @param string $method, array $params
 * @return void
 */
    public function _remap($method, $params = array()) {

        if(method_exists($this, $method)) {

            return call_user_func_array(array($this, $method), $params);
        }

        return show_404();
    }

/**
 * Get  Categories method
 *
 * @return array
 */
    public function get_all_categories_list() {

        return $this->categories_lib->get_all_categories_list();
    }
}

/* End of file pages.php */
/* Location: ./application/controllers/pages.php */