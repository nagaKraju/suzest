<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// View
$config['scripts_view'] = 'scripts';

// jquery
$config['js_jquery_min'] = 'assets/js/jquery.min.js';

// bootstrap.min
$config['js_bootstrap_min'] = 'assets/js/bootstrap.min.js';

// Main
$config['js_scripts'] = 'assets/js/script.min.js?v=20160516434';

// form.min
$config['js_form_min'] = 'assets/js/form.min.js';

// select2 min
$config['js_select2_min'] = 'assets/js/select2.min.js';

// inputmask
$config['js_inputmask'] = 'assets/js/inputmask.js';

// autosize
$config['js_autosize'] = 'assets/js/autosize.js';

// inputlimit min
$config['js_inputlimit_min'] = 'assets/js/inputlimit.min.js';

// listbox
$config['js_listbox'] = 'assets/js/listbox.js';

// search
$config['js_search'] = 'assets/js/search.js';

// multiselect
$config['js_multiselect'] = 'assets/js/multiselect.js';

// validate.min
$config['js_validate_min'] = 'assets/js/validate.min.js';