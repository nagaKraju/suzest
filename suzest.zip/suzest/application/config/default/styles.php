<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// View
$config['styles_view'] = 'styles';

// bootstrap min
$config['css_bootstrap_min'] = 'assets/css/bootstrap.min.css';
// usebootstrap
$config['css_usebootstrap'] = 'assets/css/usebootstrap.css';
// styles
$config['css_styles']	= 'assets/css/style.css';