<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


// Template
$config['template_view'] = 'template';

// Header
$config['header_view'] = 'header';

// Footer
$config['footer_view'] = 'footer';

// Success
$config['success_view'] = 'success';

// Success
$config['failure_view'] = 'failure';

// Assets
$config['assets_path'] = 'assets/';

// Image
$config['images_path'] = 'assets/images/';

// Email IDs
switch(ENVIRONMENT) {
    case 'development':
        $config['support_email'] = '';
        $config['corporate_email'] = '';
        $config['admin_email'] = '';
        $config['noreply_email'] = '';
        $config['admin_email_name'] = '';
        break;
    case 'testing':
        $config['support_email'] = '';
        $config['corporate_email'] = '';
        $config['admin_email'] = '';
        $config['noreply_email'] = '';
        $config['admin_email_name'] = '';
        break;
    case 'production':
        $config['support_email'] = '';
        $config['corporate_email'] = '';
        $config['admin_email'] = '';
        $config['noreply_email'] = '';
        $config['admin_email_name'] = '';
        break;
}

// URIs

// Home
$config['pages_register_uri'] = 'pages/register';
$config['pages_suzest_id_uri'] = 'pages/suzest_id';
$config['pages_map_uri'] = 'pages/map';
$config['pages_uid_uri'] = 'pages/instructor';
$config['pages_index_uri'] = 'pages';
$config['properties_ajax_add_property_uri'] = 'pages/ajax_add_property';
$config['properties_ajax_check_property_exist_by_unique_id_uri'] = 'pages/ajax_check_property_exist_by_unique_id';
$config['properties_ajax_get_property_by_unique_id_uri'] = 'pages/ajax_get_property_by_unique_id';
$config['countries_ajax_get_states_by_country_id_uri'] = 'pages/ajax_get_all_states_by_country_id';
$config['states_ajax_get_districts_by_state_id_uri'] = 'pages/ajax_get_all_districts_by_state_id';
$config['districts_ajax_get_mandals_by_district_id_uri'] = 'pages/ajax_get_all_mandals_by_district_id';
$config['zones_ajax_get_mandals_by_zone_id_uri'] = 'pages/ajax_get_all_mandals_by_zone_id';
$config['mandals_ajax_get_mandals_by_mandal_id_uri'] = 'pages/ajax_get_zone_by_mandal_id';

// Views

// Home
$config['pages_index_view'] = 'pages/index';
$config['pages_map_view'] = 'pages/map';
$config['pages_map_script_view'] = 'pages/map_script';
$config['pages_register_view'] = 'pages/register';
$config['pages_suzest_id_view'] = 'pages/suzest_id';