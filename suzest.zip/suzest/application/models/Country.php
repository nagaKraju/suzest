<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Country extends CI_Model {
    
/**
 * construct method
 * 
 */    
    public function __construct() {

        parent::__construct();
    }

/**
 * get_all_countries method
 *
 * @param integer $status
 * @return object
 */
    function get_all_countries($status = null) {

        // Load Countries Table
        $_countries_table = 'countries';
        // Select parameters
        $this->db->select("$_countries_table.id, $_countries_table.name");

        if($status)
            $this->db->where('status', $status);

        $this->db->distinct();
        return $this->db->get($_countries_table);
    }

/**
 * get_all_zones method
 *
 * @param integer $status
 * @return object
 */
    function get_all_zones($status = null) {

        // Load zones Table
        $_zones_table = 'zones';
        // Select parameters
        $this->db->select("$_zones_table.id, $_zones_table.name");

        if($status)
            $this->db->where('status', $status);

        $this->db->distinct();
        return $this->db->get($_zones_table);
    }

/**
 * get_all_states_by_country_id method
 *
 * @param integer $country_id, integer $status
 * @return object
 */
    function get_all_states_by_country_id($country_id, $status = null) {

        // Load Countries Table
        $_countries_table = 'countries';
        $_states_table = 'states';

        // Select parameters
        $this->db->select("$_states_table.id, $_states_table.name");
        $this->db->where("$_states_table.country_id", $country_id);

        if($status)
            $this->db->where('status', $status);

        $this->db->order_by("$_states_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($_states_table);
    }

/**
 * get_all_districts_by_state_id method
 *
 * @param integer $state_id, integer $status
 * @return object
 */
    function get_all_districts_by_state_id($state_id, $status = null) {

        // Load Countries Table
        $_countries_table = 'countries';
        $_districts_table = 'districts';

        // Select parameters
        $this->db->select("$_districts_table.id, $_districts_table.name");
        $this->db->where("$_districts_table.state_id", $state_id);

        if($status)
            $this->db->where('status', $status);

        $this->db->order_by("$_districts_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($_districts_table);
    }

/**
 * get_all_mandals_by_zone_id method
 *
 * @param integer $zone_id, integer $status
 * @return object
 */
    function get_all_mandals_by_district_id($district_id, $status = null) {

        // Load Countries Table
        $_countries_table = 'countries';
        $_mandals_table = 'mandals';

        // Select parameters
        $this->db->select("$_mandals_table.id, $_mandals_table.name");
        $this->db->where("$_mandals_table.district_id", $district_id);

        if($status)
            $this->db->where('status', $status);

        $this->db->order_by("$_mandals_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($_mandals_table);
    }

/**
 * get_zone_by_mandal_id method
 *
 * @param integer $mandal_id, integer $status
 * @return object
 */
    function get_zone_by_mandal_id($mandal_id, $status = null) {

        // Load Countries Table
        $_zones_table = 'zones';
        $_mandals_table = 'mandals';

        // Select parameters
        $this->db->select("$_zones_table.id, $_zones_table.name");
        $this->db->join("$_mandals_table", "$_mandals_table.zone_id = $_zones_table.id");
        $this->db->where("$_mandals_table.id", $mandal_id);

        if($status)
            $this->db->where("$_zones_table.status", $status);

        $this->db->order_by("$_zones_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($_zones_table);
    }

/**
 * get_state_code_by_state_id method
 *
 * @param integer $state_id, integer $status
 * @return object
 */
    function get_state_code_by_state_id($state_id, $status = null) {

        // Load State Table
        $_stetes_table = 'states';

        // Select parameters
        $this->db->select("$_stetes_table.code");
        $this->db->where("$_stetes_table.id", $state_id);

        if($status)
            $this->db->where('status', $status);
        $this->db->distinct();

        return $this->db->get($_stetes_table);
    }

/**
 * get_zone_code_by_zone_id method
 *
 * @param integer $zone_id, integer $status
 * @return object
 */
    function get_zone_code_by_zone_id($zone_id, $status = null) {

        // Load State Table
        $_zones_table = 'zones';

        // Select parameters
        $this->db->select("$_zones_table.code");
        $this->db->where("$_zones_table.id", $zone_id);

        if($status)
            $this->db->where('status', $status);
        $this->db->distinct();

        return $this->db->get($_zones_table);
    }

/**
 * add_property method
 *
 * @param arr $property
 * @return string $uniqueid
 */
    function add_property($property) {

        $uid = $property['unique_id'];
        // Load properties Table
        $_properties_table = 'properties';

        $this->db->insert($_properties_table, $property);

        if($this->db->affected_rows() > 0)
            return $uid;

        return false;
    }

/**
 * update_property method
 *
 * @param arr $suzest
 * @return string $uniqueid
 */
    function update_property($suzest) {

        // Load properties Table
        $_properties_table = 'properties';

        $this->db->set('phone_number', $suzest['phone_number']);

        if(!empty($suzest['apartment_number']) && !empty($suzest['flat_number'])){
            $this->db->where('apartment_number', $suzest['apartment_number']);
            $this->db->where('flat_number', $suzest['flat_number']);
        } else{
            $this->db->where('door_number', $suzest['door_number']);
        }

        if($this->db->update($_properties_table, $suzest)){
            if(!empty($suzest['apartment_number']) && !empty($suzest['flat_number'])){
                $this->db->select('unique_id');
                $this->db->where('apartment_number', $suzest['apartment_number']);
                $this->db->where('flat_number', $suzest['flat_number']);
                $this->db->limit(1);

                $flat = $this->db->get($_properties_table)->row();

                if (!empty($flat))
                    return $flat->unique_id;
                else
                    return 0;
            } else{
                $this->db->select('unique_id');
                $this->db->where('door_number', $suzest['door_number']);
                $this->db->limit(1);

                $house =  $this->db->get($_properties_table)->row();

                if (!empty($house))
                    return $house->unique_id;
                else
                    return 0;
            }

        }

        return false;
    }

/**
 * get_flat_number_available_for_registration method
 *
 * @param integer $flat_number, string $apartment_number
 * @return bool
 */
    function get_flat_number_available_for_registration($flat_number, $apartment_number) {

        $_properties_table = 'properties';

        $this->db->select('1', FALSE);
        $this->db->where('flat_number', $flat_number);
        $this->db->where('apartment_number', $apartment_number);
        $this->db->limit(1);

        return $this->db->get($_properties_table);
    }

/**
 * ajax_door_number_available_for_registration method
 *
 * @param string $door_number
 * @return bool
 */
    function ajax_door_number_available_for_registration($door_number) {

        $_properties_table = 'properties';

        $this->db->select('1', FALSE);
        $this->db->where('door_number', $door_number);
        $this->db->limit(1);

        return $this->db->get($_properties_table);
    }

/**
 * get_pincode_by_unique_code method
 *
 * @param string $geocode
 * @return bool
 */
    function get_pincode_by_unique_code($geocode) {

        $_properties_table = 'properties';
        $_countries_table = 'countries';
        $_states_table = 'states';
        $_districts_table = 'districts';
        $_mandals_table = 'mandals';

        $this->db->select("$_properties_table.*, $_countries_table.name as country, $_states_table.name as state, $_districts_table.name as district, $_mandals_table.name as mandal");
        $this->db->join("$_countries_table","$_countries_table.id = $_properties_table.country_id");
        $this->db->join("$_states_table","$_states_table.id = $_properties_table.state_id");
        $this->db->join("$_districts_table","$_districts_table.id = $_properties_table.district_id");
        $this->db->join("$_mandals_table","$_mandals_table.id = $_properties_table.mandal_id");
        $this->db->where('unique_id', $geocode);

        return $this->db->get($_properties_table);
    }
}