<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Formm extends CI_Model {

/**
 * construct method
 * 
 */    
    public function __construct() {

    }

/**
 * add_drop_query method
 *
 * @param array $details
 * @return bool
 */
    function add_drop_query($details) {

        $_drop_queries_table = $this->config->item('drop_queries_table');

        $this->db->insert($_drop_queries_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * get_drop_query_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_drop_query_by_id($id) {

        $_drop_queries_table = $this->config->item('drop_queries_table');

        // Load courses config
        $this->load->config('default/courses');
        $_courses_table = $this->config->item('courses_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_drop_queries_table.*, $_courses_table.name as course, $_countries_table.name as country");
        $this->db->join("$_courses_table", "$_courses_table.id = $_drop_queries_table.course_id", "left");
        $this->db->join("$_countries_table", "$_countries_table.id = $_drop_queries_table.country_id", "left");
        $this->db->where("$_drop_queries_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_drop_queries_table);
    }


/**
 * add_on_site_training method
 *
 * @param array $details
 * @return bool
 */
    function add_on_site_training($details) {

        $_on_site_training_table = $this->config->item('on_site_trainings_table');

        $this->db->insert($_on_site_training_table, $details);

        if($this->db->affected_rows() == 1)
            return $this->db->insert_id();

        return false;
    }


/**
 * get_on_site_training_by_id method
 *
 * @param integer $id
 * @return object
 */
    function get_on_site_training_by_id($id) {

        $_on_site_training_table = $this->config->item('on_site_trainings_table');

        // Load courses config
        $this->load->config('default/courses');
        $_courses_table = $this->config->item('courses_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_on_site_training_table.*, $_courses_table.name as course, $_countries_table.name as country");
        $this->db->join("$_courses_table", "$_courses_table.id = $_on_site_training_table.course_id", "left");
        $this->db->join("$_countries_table", "$_countries_table.id = $_on_site_training_table.country_id", "left");
        $this->db->where("$_on_site_training_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_on_site_training_table);
    }


/**
 * add_contact_us method
 *
 * @param array $details
 * @return bool
 */
    function add_contact_us($details) {

        $_contact_us_table = $this->config->item('contact_us_table');

        $this->db->insert($_contact_us_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * get_contact_us_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_contact_us_by_id($id) {

        $_contact_us_table = $this->config->item('contact_us_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_contact_us_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id = $_contact_us_table.country_id", "left");
        $this->db->where("$_contact_us_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_contact_us_table);
    }

/**
 * add_become_faculty method
 *
 * @param array $details
 * @return bool
 */
    function add_become_faculty($details) {

        $_become_faculties_table = $this->config->item('become_faculties_table');

        $this->db->insert($_become_faculties_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * get_become_faculty_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_become_faculty_by_id($id) {

        $_become_faculties_table = $this->config->item('become_faculties_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_become_faculties_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id = $_become_faculties_table.country_id", "left");
        $this->db->where("$_become_faculties_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_become_faculties_table);
    }


/**
 * add_connect method
 *
 * @param array $details
 * @return bool
 */
    function add_connect($details) {

        $_connect_table = $this->config->item('connect_table');

        $this->db->insert($_connect_table, $details);

        if($this->db->affected_rows() == 1)
            return $this->db->insert_id();

        return false;
    }

/**
 * get_connect_by_id method
 *
 * @param integer $id
 * @return object
 */
    function get_connect_by_id($id) {

        $_connect_table = $this->config->item('connect_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        // Load instructors config
        $this->load->config('default/instructors');
        $_instructors_table = $this->config->item('instructors_table');

        $this->db->select("$_connect_table.*, $_countries_table.name as country, $_instructors_table.first_name,
        $_instructors_table.last_name");
        $this->db->join("$_countries_table", "$_countries_table.id = $_connect_table.country_id", "left");
        $this->db->join("$_instructors_table", "$_instructors_table.id = $_connect_table.instructor_id");
        $this->db->where("$_connect_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_connect_table);
    }

/**
 * add_notification method
 *
 * @param array $details
 * @return bool
 */
    function add_notification($details) {

        $_notifications_table = $this->config->item('notifications_table');

        $this->db->insert($_notifications_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * get_notification_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_notification_by_id($id) {

        $_notifications_table = $this->config->item('notifications_table');

        // Load courses config
        $this->load->config('default/courses');
        $_learning_types_table = $this->config->item('learning_types_table');
        $_courses_table = $this->config->item('courses_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_notifications_table.*, $_courses_table.name as course,
            $_learning_types_table.name as learning_type, $_countries_table.name as country");
        $this->db->join("$_courses_table", "$_courses_table.id = $_notifications_table.course_id", "left");
        $this->db->join("$_learning_types_table", "$_learning_types_table.id = $_notifications_table.learning_type_id", "left");
        $this->db->join("$_countries_table", "$_countries_table.id = $_notifications_table.country_id", "left");
        $this->db->where("$_notifications_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_notifications_table);
    }

/**
 * add_virtual_demo_register method
 *
 * @param array $details
 * @return bool
 */
    function add_virtual_demo_register($details) {

        $_virtual_demo_registrations_table = $this->config->item('virtual_demo_registrations_table');
        
        $this->db->insert($_virtual_demo_registrations_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * email_available_for_virtual_demo_registration method
 *
 * @param string $email, integer $virtual_session_id
 * @return bool
 */
    function email_available_for_virtual_demo_registration($email, $virtual_session_id) {

        $_virtual_demo_registrations = $this->config->item('virtual_demo_registrations_table');

        $this->db->where('email', $email);
        $this->db->where('virtual_session_id', $virtual_session_id);

        $query = $this->db->get($_virtual_demo_registrations);
        if($query->num_rows() == 0)
            return false;

        return true;
    }

/**
 * get_virtual_demo_register_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_virtual_demo_register_by_id($id) {

        // Default offset
        $default = $this->config->item('offset');

        $_virtual_demo_registrations_table = $this->config->item('virtual_demo_registrations_table');

        // Load courses config
        $this->load->config('default/courses');
        $_courses_table = $this->config->item('courses_table');
        $_virtual_sessions_table = $this->config->item('virtual_sessions_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        // Query
        $query = "select $_virtual_demo_registrations_table.*, $_courses_table.name as course, $_countries_table.name as country,
                  convert_tz($_virtual_sessions_table.start_date, '".$default."', $_virtual_demo_registrations_table.offset) as start_date,
                  convert_tz($_virtual_sessions_table.end_date, '".$default."', $_virtual_demo_registrations_table.offset) as end_date
                  from $_virtual_demo_registrations_table
                  join $_courses_table on $_courses_table.id = $_virtual_demo_registrations_table.course_id
                  left join $_virtual_sessions_table on $_virtual_sessions_table.id = $_virtual_demo_registrations_table.virtual_session_id
                  left join $_countries_table on $_countries_table.id = $_virtual_demo_registrations_table.country_id
                  where $_virtual_demo_registrations_table.id = $id
                  limit 1
                  ";

        return $this->db->query($query);
    }

/**
 * get_virtual_demo_register_by_email method
 *
 * @param string $email, integer $virtual_session_id, integer $country_id
 * @return object
 */
    function get_virtual_demo_register_by_email($email, $virtual_session_id, $country_id, $course_id) {

        // Default offset
        $default = $this->config->item('offset');

        $_virtual_demo_registrations_table = $this->config->item('virtual_demo_registrations_table');

        // Load courses config
        $this->load->config('default/courses');
        $_courses_table = $this->config->item('courses_table');

        // Load sessions config
        $this->load->config('default/sessions');
        $_virtual_sessions_table = $this->config->item('virtual_sessions_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        // Query
        $query = "select $_virtual_demo_registrations_table.*, $_courses_table.name as course, $_countries_table.name as country,
                  convert_tz($_virtual_sessions_table.start_date, '".$default."', $_virtual_demo_registrations_table.offset) as start_date,
                  convert_tz($_virtual_sessions_table.end_date, '".$default."', $_virtual_demo_registrations_table.offset) as end_date
                  from $_virtual_demo_registrations_table
                  join $_courses_table on $_courses_table.id = $_virtual_demo_registrations_table.course_id
                  left join $_virtual_sessions_table on $_virtual_sessions_table.id = $_virtual_demo_registrations_table.virtual_session_id
                  left join $_countries_table on $_countries_table.id = $_virtual_demo_registrations_table.country_id
                  where $_virtual_demo_registrations_table.email = '".$email."' and
                        $_virtual_demo_registrations_table.virtual_session_id = $virtual_session_id and
                        $_virtual_demo_registrations_table.country_id = $country_id and
                        $_virtual_demo_registrations_table.course_id = $course_id
                  limit 1
                  ";

        return $this->db->query($query);
    }

/**
 * add_custom_quote method
 *
 * @param array $details
 * @return bool
 */
    function add_custom_quote($details) {

        $_custom_quotes_table = $this->config->item('custom_quotes_table');
        
        $this->db->insert($_custom_quotes_table, $details);
        
        if($this->db->affected_rows() == 1) 
            return $this->db->insert_id();

        return false;
    }

/**
 * get_custom_quote_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_custom_quote_by_id($id) {

        $_custom_quotes_table = $this->config->item('custom_quotes_table');

        // Load courses config
        $this->load->config('default/courses');
        $_courses_table = $this->config->item('courses_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');
        $_cities_table = $this->config->item('cities_table');

        $this->db->select("$_custom_quotes_table.*, $_courses_table.name as course, $_countries_table.name as country, $_cities_table.name as city");
        $this->db->join("$_courses_table", "$_courses_table.id = $_custom_quotes_table.course_id");
        $this->db->join("$_countries_table", "$_countries_table.id = $_custom_quotes_table.country_id");
        $this->db->join("$_cities_table", "$_cities_table.id = $_custom_quotes_table.city_id");
        $this->db->where("$_custom_quotes_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_custom_quotes_table);
    }

/**
 * add_career method
 *
 * @param array $details
 * @return bool
 */
    function add_career($details) {

        $_careers_table = $this->config->item('careers_table');

        $this->db->insert($_careers_table, $details);

        if($this->db->affected_rows() == 1)
            return $this->db->insert_id();

        return false;
    }

/**
 * get_career_by_id method
 *
 * @param integer $id
 * @return object
 */
    function get_career_by_id($id) {

        $_careers_table = $this->config->item('careers_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_careers_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id = $_careers_table.country_id", "left");
        $this->db->where("$_careers_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_careers_table);
    }

/**
 * add_my_support method
 *
 * @param array $details
 * @return bool
 */
    function add_my_support($details) {

        $_my_supports_table = $this->config->item('my_supports_table');

        $this->db->insert($_my_supports_table, $details);

        if($this->db->affected_rows() == 1)
            return $this->db->insert_id();

        return false;
    }

/**
 * get_my_support_by_id method
 *
 * @param integer $id
 * @return object
 */
    function get_my_support_by_id($id) {

        $_my_supports_table = $this->config->item('my_supports_table');

        // Load countries
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$_my_supports_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id = $_my_supports_table.country_id", "left");
        $this->db->where("$_my_supports_table.id", $id);
        $this->db->limit(1);

        return $this->db->get($_my_supports_table);
    }
}