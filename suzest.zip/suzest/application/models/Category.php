<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Model {
    
/**
 * construct method
 * 
 */    
    public function __construct() {

        parent::__construct();
    }

/**
 * get_all_categories method
 *
 * @param integer $status
 * @return object
 */
    function get_all_categories($status = null) {

        // Load categories Table
        $_categories_table = 'categories';
        // Select parameters
        $this->db->select("$_categories_table.id, $_categories_table.name");

        if($status)
            $this->db->where('status', $status);

        $this->db->distinct();
        return $this->db->get($_categories_table);
    }
}