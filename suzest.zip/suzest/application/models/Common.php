<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common extends CI_Model { 
    
/**
 * construct method
 * 
 */    
    public function __construct() {

        parent::__construct();
    }

/**
 * get_redirection_by_url method
 * 
 * @param string $from
 * @return object
 */
    function get_redirection_by_url($from) {
        
        $_redirections_table = $this->config->item('redirections_table');
        
        $this->db->where('from', $from);
        $this->db->order_by('modified', 'desc');
        $this->db->limit(1);
        
        return $this->db->get($_redirections_table);
    }

/**
 * get_page_by_slug method
 *
 * @param string $slug
 * @return object
 */
    function get_page_by_slug($slug) {

        $_pages_table = $this->config->item('pages_table');

        $this->db->where('slug', $slug);

        return $this->db->get($_pages_table);
    }

/**
 * get_all_countries method
 *
 * @param integer $status
 * @return object
 */
    function get_all_countries($status = null) {

        // Load Countries Table
        $_countries_table = 'countries';
        // Select parameters
        $this->db->select("$_countries_table.id, $_countries_table.name");

        if($status)
            $this->db->where('status', $status);

        $this->db->distinct();
        return $this->db->get($_countries_table);
    }
}