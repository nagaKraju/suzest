<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Locate Me suZest.com</title>
<meta name="description" content="<?php echo !empty($page->meta_description)?$page->meta_description:''; ?>">

<title></title>
<meta name="description" content="">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<!--Let browser know website is optimized for mobile-->
<style>
    .divdisplay{ display:none; }
</style>
<!--Import Google Icon Font-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->config->item('css_bootstrap_min')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->config->item('css_usebootstrap')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->config->item('css_styles')); ?>" />
<link rel='icon' type='image/png' href="<?php echo base_url($this -> config -> item('images_path').'suzest-orange-03.png'); ?>" />