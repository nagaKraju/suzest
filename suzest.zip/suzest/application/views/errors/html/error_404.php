<?php
	$this->ci = &get_instance();
	//$this->ci->load->helper('url');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

		<title>Page Not Found</title>
		<meta name="description" content="Page Not Found">


		<!--Import Google Icon Font-->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->ci->config->item('css_bootstrap_min')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->ci->config->item('css_font_awesome_min')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url($this->ci->config->item('css_styles')); ?>" />
	</head>
	<body class="pad-top">
		<!-- header -->
		<?php /*$this->ci->load->view($this->ci->config->item('header_view')); */?>
		<!-- /headr -->

			<header>
				<nav class="navbar navbar-default">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed visible-xs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<?php echo anchor(base_url(), img(array('src' => base_url($this->ci->config->item('images_path').'knowledgehut-logo.svg'), 'alt'=>'kh-landing-page')), 'class="navbar-brand"'); ?>
					</div>
				</div>
		</nav>
		</header>
		<section class="error-page">
			<div class="text-center">
				<h2>404,page not found</h2>
				<p>
					The page you are looking for does not exist.Go to <?php echo anchor(base_url(), 'HOME') ?> page or use menu above
				</p>
			</div>
		</section>

		<!-- footer -->
		<?php $this->ci->load->view($this->ci->config->item('footer_view')); ?>
		<!-- /footer -->
	</body>
</html>