<section class="register">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-4">
                <div class="unique_id">
                    <div class="row">
                            <div class="form-group">
								<div class="col-md-6">
                                    <?php echo form_label('Suzest Id', 'Unique_Id'); ?>
                                    <?php echo form_input(array('name' => 'unique_id', 'class' => 'form-control', 'placeholder' => 'Enter Street Name here', 'value' => set_value('slug'))); ?>
								</div>
							</div>
                    </div>
                </div>
                <form action="javascript:void(0);" class = 'form-horizontal' id = 'suzest_form' >
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('Category', 'category');
                                echo form_dropdown('category_id', array('' => 'Choose a Category...') + $categories, set_value('category_id', 1), 'data-placeholder="Choose a Category..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('Phone Number', 'PhoneNumber');
                                echo form_input(array('name' => 'phone_number', 'class' => 'form-control', 'placeholder' => 'Enter Phone Number here', 'value' => set_value('phone_number')));
                            ?>
                        </div>
                    </div>
                    <div class="apartment">
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Apartment Number', 'Apartment_Number');
                                    echo form_input(array('name' => 'apartment_number', 'class' => 'form-control', 'placeholder' => 'Enter Apartment Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                echo form_label('Flat Number', 'Flat_Number');
                                echo form_input(array('name' => 'flat_number', 'class' => 'form-control', 'placeholder' => 'Enter Flat Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="house">
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Door Number', 'Door_Number');
                                    echo form_input(array('name' => 'door_number', 'class' => 'form-control', 'placeholder' => 'Enter Door Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3">
                            <?php echo form_submit(array('class' => 'btn btn-success btn-block', 'value' => 'Submit', 'name' => 'submit', 'id' => 'submit')); ?>
                        </div>
                        <div class="col-md-3">
                            <?php echo form_reset(array('class' => 'btn btn-danger btn-block', 'value' => 'Cancel', 'name' => 'cancel', 'id' => 'cancel')); ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script>
    // Base URL
    var base_url = "<?php echo base_url(); ?>";
</script>
<!-- scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->
<!-- Scripts -->
<script type="text/javascript">

    // On load of body
    $(function() {

        $('.unique_id').hide();
        // Check category selected
        if($('select[name="category_id"]').val()) {

            // Check Apartment Selected
            if ($('select[name="category_id"]').val() == 1) {

                $('.house').hide();
                $('.apartment').show();
            } else {

                $('.apartment').hide();
                $('.house').show();
            }
        }

    });

    // On change of category
    $('select[name="category_id"]').change(function () {

        if($('select[name="category_id"]').val() != '')

            // Check Apartment Selected
            if($('select[name="category_id"]').val() == 1) {

                $('.house').hide();
                $('.apartment').show();
            } else {

                $('.apartment').hide();
                $('.house').show();
            }
    });
</script>
<!-- Scripts -->
