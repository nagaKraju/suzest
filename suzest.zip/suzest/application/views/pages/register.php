<section class="register">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="unique_id">
                    <div class="row">
                            <div class="form-group">
								<div class="col-md-6">
								<?php echo form_label('Suzest Id', 'Unique_Id'); ?>
                                <?php echo form_input(array('name' => 'unique_id', 'class' => 'form-control', 'placeholder' => 'Enter Street Name here', 'value' => set_value('slug'))); ?>
								</div>
							</div>
                    </div>
                </div>
                <?php //echo form_open('javscript:void(0)', array('class' => 'form-horizontal', 'id' => 'property_form')); ?>
                <form action="javascript:void(0);" class = 'form-horizontal' id = 'property_form' >
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('Category', 'category');
                                echo form_dropdown('category_id', array('' => 'Choose a Category...') + $categories, set_value('category_id', 1), 'data-placeholder="Choose a Category..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                        <div class="col-md-6">
                            <?php
                                echo form_label('Country', 'country');
                                echo form_dropdown('country_id', array('' => 'Choose a Country...') + $countries, $this->input->post('country_id'), 'data-placeholder="Choose a Country..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('State', 'state');
                                echo form_dropdown('state_id', array('' => 'Choose a State...'), $this->input->post('state_id'), 'data-placeholder="Choose a State..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                        <div class="col-md-6">
                            <?php
                                echo form_label('District', 'district');
                                echo form_dropdown('district_id', array('' => 'Choose a District...'), $this->input->post('district_id'), 'data-placeholder="Choose a District..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('Mandal', 'mandal');
                                echo form_dropdown('mandal_id', array('' => 'Choose a Mandal...'), $this->input->post('mandal_id'), 'data-placeholder="Choose a Mandal..." class="select-search form-control" tabindex="2"');
                            ?>
                        </div>
                        <div class="col-md-6">
                            <input type="hidden" name="zone_id" value=""/>
                            <?php
                                echo form_label('Zone', 'zone');
                                echo form_input(array('name' => 'zone', 'class' => 'form-control', 'placeholder' => 'Enter zone Name here', 'value' => set_value('slug'), 'readonly' => 'readonly'));
                                /*echo form_dropdown('zone_id', array('' => 'Choose a Zone...') + $zones, $this->input->post('zone_id'), 'data-placeholder="Choose a Zone..." class="select-search form-control" tabindex="2"');*/
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_label('Pincode', 'pincode');
                                echo form_input(array('name' => 'pincode', 'class' => 'form-control', 'placeholder' => 'Enter pincode here', 'value' => set_value('slug')));
                            ?>
                        </div>
                        <div class="col-md-6">
                            <?php
                                echo form_label('Street Name', 'Street_Name');
                                echo form_input(array('name' => 'street_name', 'class' => 'form-control', 'placeholder' => 'Enter Street Name here', 'value' => set_value('slug')));
                            ?>
                        </div>
                    </div>
                    <div class="apartment">
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Apartment Number', 'Apartment_Number');
                                    echo form_input(array('name' => 'apartment_number', 'class' => 'form-control', 'placeholder' => 'Enter Apartment Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Flat Number', 'Flat_Number');
                                    echo form_input(array('name' => 'flat_number', 'class' => 'form-control', 'placeholder' => 'Enter Flat Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Apartment Name', 'Apartment_Name');
                                    echo form_input(array('name' => 'apartment_name', 'class' => 'form-control', 'placeholder' => 'Enter Apartment Name here', 'value' => set_value('slug')));?>
                            </div>
                        </div>
                    </div>
                    <div class="house">
                        <div class="form-group">
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Door Number', 'Door_Number');
                                    echo form_input(array('name' => 'door_number', 'class' => 'form-control', 'placeholder' => 'Enter Door Number here', 'value' => set_value('slug')));
                                ?>
                            </div>
                            <div class="col-md-6">
                                <?php
                                    echo form_label('Area', 'Area');
                                    echo form_input(array('name' => 'area', 'class' => 'form-control', 'placeholder' => 'Enter Area here', 'value' => set_value('slug')));
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php
                                echo form_checkbox('agree', 1, TRUE);
                                echo form_label('I Agree', 'I Agree');
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-6">
                            <?php echo form_submit(array('class' => 'btn btn-success btn-block', 'value' => 'Submit', 'name' => 'submit', 'id' => 'submit')); ?>
                        </div>
                        <div class="col-md-6">
                            <?php echo form_reset(array('class' => 'btn btn-danger btn-block', 'value' => 'Cancel', 'name' => 'cancel', 'id' => 'cancel')); ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script>
    // Base URL
    var base_url = "<?php echo base_url(); ?>";
</script>
<!-- scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->
<!-- Scripts -->
<script type="text/javascript">

    // On load of body
    $(function() {

        $('.unique_id').hide();
        // Check category selected
        if($('select[name="category_id"]').val()) {

            // Check Apartment Selected
            if ($('select[name="category_id"]').val() == 1) {

                $('.house').hide();
                $('.apartment').show();
            } else {

                $('.apartment').hide();
                $('.house').show();
            }
        }
        if($('select[name="country_id"]').val()) {
            // Get states
            get_states($('select[name="country_id"]').val(), "<?php echo $this->input->post('state_id'); ?>");
        }
        // Check state selected
        if($('select[name="state_id"]').val()) {

            // Get Districts
            get_districts($('select[name="state_id"]').val(), "<?php echo $this->input->post('district_id'); ?>");
        }

        // Check Districts selected
        if($('select[name="district_id"]').val()) {

            // Get Districts
            get_mandals($('select[name="district_id"]').val(), "<?php echo $this->input->post('mandal_id'); ?>");
        }

        // Check Mandals selected
        if($('select[name="mandal_id"]').val()) {

            // Get Mandals
            get_zones($('select[name="mandal_id"]').val(), "<?php echo $this->input->post('zone_id'); ?>");
        }

    });

    // On change of category
    $('select[name="category_id"]').change(function () {

        if($('select[name="category_id"]').val() != '')

            // Check Apartment Selected
            if($('select[name="category_id"]').val() == 1) {

                $('.house').hide();
                $('.apartment').show();
            } else {

                $('.apartment').hide();
                $('.house').show();
            }
    });

    // On change of country
    $('select[name="country_id"]').change(function () {

        // Empty the state dropdown
        $('select[name="state_id"]').val('');
        $('select[name="district_id"]').val('');

        // Check value exist
        if ($(this).val()) {

            get_states($(this).val(), 0);
        }
    });

    // On change of state
    $('select[name="state_id"]').change(function () {

        // Empty the state dropdown
        $('select[name="district_id"]').val('');
        $('select[name="mandal_id"]').val('');

        // Check value exist
        if ($(this).val()) {

            get_districts($(this).val(), 0);
        }
    });

    // On change of district
    $('select[name="district_id"]').change(function () {

        // Empty the zone, mandal dropdown
        $('select[name="mandal_id"]').val('');
        $('select[name="zone_id"]').val('');

        // Check value exist
        if ($('select[name="district_id"]').val()) {

            get_mandals($(this).val(), 0);
        }
    });

    // On change of mandal
    $('select[name="mandal_id"]').change(function () {

        // Empty the zone dropdown
        $('select[name="zone_id"]').val('');

        // Check value exist
        if ($('select[name="mandal_id"]').val()) {

            get_zones($(this).val(), 0);
        }

    });

    // Get states
    function get_states(country_id, state_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('countries_ajax_get_states_by_country_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"country_id": country_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.states != 'undefined') {

                        var options = '<option value=""> Choose a State...</option>';

                        $.each(data.states, function (key, value) {

                            if (state_id == value.id) {

                                options += '<option value="' + value.id + '" selected="selected">' + value.name + '</option>';
                            } else {

                                options += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        });

                        $('select[name="state_id"]').html(options);

                        $('select .form-select[name="state_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }

    // Get Districts
    function get_districts(state_id, district_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('states_ajax_get_districts_by_state_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"state_id": state_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.districts != 'undefined') {

                        var options = '<option value="">Choose a District...</option>';

                        $.each(data.districts, function (key, value) {

                            if (district_id == value.id) {

                                options += '<option value="' + value.id + '" selected="selected">' + value.name + '</option>';
                            } else {

                                options += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        });

                        $('select[name="district_id"]').html(options);

                        $('select .form-select[name="district_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }

    // Get Mandals
    function get_mandals(district_id, mandal_id) {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('districts_ajax_get_mandals_by_district_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"district_id": district_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.mandals != 'undefined') {

                        var options = '<option value="">Choose a Mandal...</option>';

                        $.each(data.mandals, function (key, value) {

                            if (mandal_id == value.id) {

                                options += '<option value="' + value.id + '" selected="selected">' + value.name + '</option>';
                            } else {

                                options += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        });

                        $('select[name="mandal_id"]').html(options);

                        $('select .form-select[name="mandal_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }

    // Get Zones
    function get_zones(mandal_id, zone_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('mandals_ajax_get_mandals_by_mandal_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"mandal_id": mandal_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.zones != 'undefined') {
                        var options = '<option value="">Choose a Zone...</option>';

                        $.each(data.zones, function (key, value) {

                            $('input[name="zone"]').val(value.name);
                            $('input[name="zone_id"]').val(value.id);
                        });

                        $('select[name="zone_id"]').html(options);

                        $('select .form-select[name="zone_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }
</script>
<!-- Scripts -->
