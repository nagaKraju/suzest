<!-- header -->
<?php //$this->load->view($this->config->item('header_view')); ?>
<!-- /header -->
<!-- Begin page content -->
<section class="home-page">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-md-offset-9 ">
                <?php echo anchor(base_url(), 'Home', 'class="btn btn-success home_button"'); ?>
                <?php echo anchor(base_url($this->config->item('pages_suzest_id_uri')), 'Check Suzest ID', 'class="btn btn-success home_button"'); ?>
            </div>
            <div class="col-md-4 col-md-offset-4 content">
                <div class="image">
                    <?php echo img(array('src' => base_url($this -> config -> item('images_path').'suzest orange-01.jpg'), "class" => "logo-size", "title" => "suZest", "alt" => "Suzest")); ?>
                </div>
                <?php echo form_open(base_url($this->config->item('pages_map_uri')), array('class' => 'form-horizontal', 'id' => 'search_form')); ?>
                    <div class="form-group row">

                        <div class="col-md-12">
                            <input type="text" class="form-control" id="geocode" name="geocode">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <input type="submit" name="submit" value="Search" class="btn btn-info btn-block" />
                        </div>
                        <div class="col-md-6">
                            <?php echo anchor(base_url($this->config->item('pages_register_uri')), 'Register', 'class="btn btn-info"'); ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script>
    // Base URL
    var base_url = "<?php echo base_url(); ?>";
</script>
<!-- script view -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- script view -->