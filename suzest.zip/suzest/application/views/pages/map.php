<section class="map">
    <div class="container">
        <div class="row">
            <div class="col-md-4">

            </div>
            <div class="col-md-6">
                <?php echo form_open(base_url($this->config->item('pages_map_uri')), array('class' => 'form-horizontal', 'id' => 'search_form')); ?>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <input type="text" class="form-control" id="geocode" name="geocode">
                                <?php echo form_error('geocode', '<label class="error" style="color: red">', '</label>');  ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <input type="submit" name="submit" value="Search" class="btn btn-info" />
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-12">
                <?php if(isset($latitude) && isset($longitude) && isset($formatted_address)): ?>
                    <address>
                        <?php
                            echo 'Apartment Name/Area: '.$address['add1'].', <br />';

                            if($address['add2'])
                                echo 'Apartment Number: '.$address['add2'].', <br />';

                            echo 'Flat/Door Number: '.$address['add3'].', <br />';
                            echo 'Street: '.$address['street'].', <br />';
                            echo 'Mandal: '.$address['mandal'].', <br />';
                            echo 'District'.$address['district'].', <br />';
                            echo 'State'.$address['state'].', <br />';
                            echo 'Country'.$address['country'].' - '.$address['pincode'].'. <br />';
                        ?>
                    </address>
                        <!-- google map will be shown here -->
                        <div id="gmap_canvas">Loading map...</div>
                        <div id='map-label'>Map shows approximate location.</div>
                        <!-- JavaScript to show google map -->
                        <script type="text/javascript" src="http://maps.google.com/maps/api/js?v=3"></script>
                <?php
                        $this->load->view($this->config->item('pages_map_script_view'));
                    else:
                        echo isset($error) ? $error : '';
                    endif;
                ?>
            </div>
        </div>
    </div>
</section>