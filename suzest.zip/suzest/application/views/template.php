<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- styles -->
    <?php $this->load->view($this->config->item('styles_view')); ?>
    <!-- /styles -->
</head>
<?php echo ($this->router->fetch_method() != 'index') ? '<body id="register">' : '<body>' ?>
    <?php $this->load->view($this->config->item($this->router->fetch_class().'_'.$this->router->fetch_method().'_view')); ?>
</body>
</html>