<header>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <?php echo anchor(base_url(), img(array('src' => base_url($this -> config -> item('images_path').$this->config->item('website_logo')), 'alt' => 'Suzest logo')), array('title' => 'Suzest')); ?>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
</header>