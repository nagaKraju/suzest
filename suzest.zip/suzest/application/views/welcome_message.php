<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- styles -->
	<?php $this->load->view($this->config->item('styles_view')); ?>
	<!-- /styles -->
</head>
<body>
	<!-- header -->
	<?php $this->load->view($this->config->item('header_view')); ?>
	<!-- /headr -->
	<!-- footer -->
	<?php $this->load->view($this->config->item('footer_view')); ?>
	<!-- /footer -->
</body>
</html>