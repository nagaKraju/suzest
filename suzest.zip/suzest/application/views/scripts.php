<script type="text/javascript" src="<?php echo base_url($this->config->item('js_jquery_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_bootstrap_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_scripts')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_validate_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_form_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_select2_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_autosize')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_search')); ?>"></script>