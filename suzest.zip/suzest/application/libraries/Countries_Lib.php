<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Countries_Lib {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load common model
		$this->ci->load->model('country');

	}

/**
 * get_all_countries method
 *
 * @param integer $status
 * @return object
 */
    function get_all_countries($status = null) {

        return $this->ci->country->get_all_countries($status);
    }

/**
 * get_all_countries_list method
 *
 * @param integer $status
 * @return object
 */
    function get_all_countries_list($status = null) {

        $countries = $this->get_all_countries($status)->result();

        $new_countries = array();

        foreach ($countries as $key => $country) {

            $new_countries[$country->id] = $country->name;
        }

        return $new_countries;
    }

/**
 * get_all_zones method
 *
 * @param integer $status
 * @return object
 */
    function get_all_zones($status = null) {

        return $this->ci->country->get_all_zones($status);
    }

    /**
     * get_all_zones_list method
     *
     * @param integer $status
     * @return object
     */
    function get_all_zones_list($status = null) {

        $zones = $this->get_all_zones($status)->result();

        $new_zones = array();

        foreach ($zones as $key => $zone) {

            $new_zones[$zone->id] = $zone->name;
        }

        return $new_zones;
    }

/**
 * get_all_states_by_country_id method
 *
 * @param integer $country_id, integer $status
 * @return object
 */
    function get_all_states_by_country_id($country_id, $status = null) {

        return $this->ci->country->get_all_states_by_country_id($country_id, $status);
    }

/**
 * get_all_districts_by_state_id method
 *
 * @param integer $state_id, integer $status
 * @return object
 */
    function get_all_districts_by_state_id($state_id, $status = null) {

        return $this->ci->country->get_all_districts_by_state_id($state_id, $status);
    }

/**
 * get_all_mandals_by_district_id method
 *
 * @param integer $district_id, integer $status
 * @return object
 */
    function get_all_mandals_by_district_id($district_id, $status = null) {

        return $this->ci->country->get_all_mandals_by_district_id($district_id, $status);
    }

/**
 * get_zone_by_mandal_id method
 *
 * @param integer $mandl_id, integer $status
 * @return object
 */
    function get_zone_by_mandal_id($mandl_id, $status = null) {

        return $this->ci->country->get_zone_by_mandal_id($mandl_id, $status);
    }

/**
 * get_state_code_by_state_id method
 *
 * @param integer $state_id, integer $status
 * @return object
 */
    function get_state_code_by_state_id($state_id, $status = null) {

        return $this->ci->country->get_state_code_by_state_id($state_id, $status);
    }

/**
 * get_zone_code_by_zone_id method
 *
 * @param integer $zone_id, integer $status
 * @return object
 */
    function get_zone_code_by_zone_id($zone_id, $status = null) {

        return $this->ci->country->get_zone_code_by_zone_id($zone_id, $status);
    }

/**
 * add_property method
 *
 * @param arr $property
 * @return string $uniqueid
 */
    function add_property($property) {

        return $this->ci->country->add_property($property);
    }

/**
 * update_property method
 *
 * @param arr $suzest
 * @return string $uniqueid
 */
    function update_property($suzest) {

        return $this->ci->country->update_property($suzest);
    }

/**
 * get_flat_number_available_for_registration method
 *
 * @param integer $flat_number, string $apartment_number
 * @return bool
 */
    function get_flat_number_available_for_registration($flat_number, $apartment_number) {

        $flat = $this->ci->country->get_flat_number_available_for_registration($flat_number, $apartment_number);
		
		return $flat->num_rows() == 0;
    }

/**
 * ajax_door_number_available_for_registration method
 *
 * @param string $door_number
 * @return bool
 */
    function ajax_door_number_available_for_registration($door_number) {

        $door_number = $this->ci->country->get_door_number_available_for_registration($door_number);
		
		return $door_number->num_rows() == 0;
    }

// function to geocode address, it will return false if unable to geocode address
    function geocode($address){

        // url encode the address
        $address = urlencode($address);

        // google map geocode api url
        $url = "http://maps.google.com/maps/api/geocode/json?address={$address}";

        // get the json response
        $resp_json = file_get_contents($url);

        // decode the json
        $resp = json_decode($resp_json, true);

        // response status will be 'OK', if able to geocode given address
        if($resp['status']=='OK'){

            // get the important data
            $lati = $resp['results'][0]['geometry']['location']['lat'];
            $longi = $resp['results'][0]['geometry']['location']['lng'];
            $formatted_address = $resp['results'][0]['formatted_address'];

            // verify if data is complete
            if($lati && $longi && $formatted_address){

                // put the data in the array
                $data_arr = array();

                array_push(
                    $data_arr,
                    $lati,
                    $longi,
                    $formatted_address
                );

                return $data_arr;

            }else{
                return false;
            }

        }else{
            return false;
        }
    }

    function get_geocode($geocode){

        $address_data = $this->ci->country->get_pincode_by_unique_code($geocode)->row();

        $add_arr['country'] = $address_data->country;
        $add_arr['state'] = $address_data->state;
        $add_arr['district'] = $address_data->district;
        $add_arr['mandal'] = $address_data->mandal;
        $add_arr['add1'] = !empty($address_data->apartment_name) ? $address_data->apartment_name : $address_data->area;
        $add_arr['add2'] = !empty($address_data->apartment_number) ? $address_data->apartment_number : "";
        $add_arr['add3'] = !empty($address_data->flat_number) ? $address_data->flat_number : $address_data->door_number;
        $add_arr['street'] = $address_data->street_name;
        $add_arr['pincode'] = $address_data->pincode;

        // get latitude, longitude and formatted address
        $data_arr = $this->geocode($address_data->pincode);

        $new_data_arr = array();
        if($data_arr) {
            $new_data_arr['latitude'] = $data_arr[0];
            $new_data_arr['longitude'] = $data_arr[1];
            $new_data_arr['formatted_address'] = $data_arr[2];
            $new_data_arr['address'] = $add_arr;

        } else{
            $new_data_arr['address'] = $add_arr;
            $new_data_arr['error'] = "No map found.";
        }

        return $new_data_arr;
    }
}

/* End of file Common_Lib.php */
/* Location: ./application/controllers/libraries/Common_Lib.php */