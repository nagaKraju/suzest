<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pagination_Lib {
    
/**
 * constructor
 *
 * @return void
 */
	function __construct() {
	    
		$this->ci = &get_instance();
	}

/**
 * pagination
 *
 * @return string
 */    
    function pagination($base_url, $total_rows, $per_page, $uri_segment, $suffix = null) {
        
        // Pagination config
        $pagination['first_link'] = 'First';
        $pagination['first_tag_open'] = '<li>';
        $pagination['first_tag_close'] = '</li>';
        
        $pagination['cur_tag_open'] = '<li class="active disabled"><a class="" href="#">';
        $pagination['cur_tag_close'] = '</a></li>';
        
        $pagination['prev_link'] = '&laquo;';
        $pagination['prev_tag_open'] = '<li>';
        $pagination['prev_tag_close'] = '</li>';
        
        $pagination['next_link'] = '&raquo;';
        $pagination['next_tag_open'] = '<li>';
        $pagination['next_tag_close'] = '</li>';
        
        $pagination['num_tag_open'] = '<li>';
        $pagination['num_tag_close'] = '</li>';
        
        $pagination['last_link'] = 'Last';
        $pagination['last_tag_open'] = '<li>';
        $pagination['last_tag_close'] = '</li>';
        
        // Pagination config
        $pagination['base_url'] = $base_url;

        if($suffix != null) {

            $pagination['suffix'] = '?'.http_build_query($_GET, '', "&");
            //$pagination['first_url'] = $base_url.$pagination['suffix'];
        }

        $pagination['total_rows'] = $total_rows;
        $pagination['per_page'] = $per_page;
        $pagination['uri_segment'] = $uri_segment;

        $pagination['use_page_numbers'] = TRUE;
        
        // Load pagination library
        $this->ci->load->library('pagination');
        
        // Initialize pagination
        $this->ci->pagination->initialize($pagination);
        
        return $this->ci->pagination->create_links();
    }   
}

/* End of file Pagination_Lib.php */
/* Location: ./application/controllers/libraries/Pagination_Lib.php */