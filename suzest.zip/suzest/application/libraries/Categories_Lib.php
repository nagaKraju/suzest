<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories_Lib {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load category model
		$this->ci->load->model('category');

	}

/**
 * get_all_categories method
 *
 * @param integer $status
 * @return object
 */
    function get_all_categories($status = null) {

        return $this->ci->category->get_all_categories($status);
    }

/**
 * get_all_categories_list method
 *
 * @param integer $status
 * @return object
 */
    function get_all_categories_list($status = null) {

        $categories = $this->get_all_categories($status)->result();

        $new_categories = array();

        foreach ($categories as $key => $category) {

            $new_categories[$category->id] = $category->name;
        }

        return $new_categories;
    }
}

/* End of file Categories_Lib.php */
/* Location: ./application/controllers/libraries/Categories_Lib.php */