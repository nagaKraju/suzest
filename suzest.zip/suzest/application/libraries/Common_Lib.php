<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_Lib {

    public $page, $classroom_id, $virtual_id, $elearning_id, $corporate_id;

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load common model
		$this->ci->load->model('common');

		$this->classroom_id = 1;

		// Redirect
		$this->_redirect();

	}

/**
 * set_previous_url method
 *
 * @param string $url
 * @return void
 */
	function set_previous_url($url) {

		// Set redirect
		$this->ci->session->set_userdata('redirect', $url);
	}

/**
 * get_previous_url method
 *
 * @return string
 */
	function get_previous_url() {

		$url = base_url();

		if($this->ci->session->userdata('redirect')) {

			// Get previous_url
			$url = $this->ci->session->userdata('redirect');
		}

		return $url;
	}

/**
 * get_page_by_slug method
 *
 * @param string $slug
 * @return object
 */
	function get_page_by_slug($slug) {

		return $this->ci->common->get_page_by_slug($slug)->row();
	}

/**
 * send_mail method
 *
 * @param array $details, string $form, integer $type
 * @return void
 */
	public function send_mail($details, $form, $type) {

		$this->ci->load->library('email');
		$email = $this->ci->email;
		$email->initialize($this->ci->config->item('email'));
		$email->set_newline("\r\n");

		switch($type) {

			case 1:
				$from = $this->ci->config->item('noreply_email');
				$from_name = $this->ci->config->item('admin_email_name');
				$to = $details['email'];
                $subject = $this->ci->config->item($form.'_user_subject');
				$view = $this->ci->config->item($form.'_user_email_view');
				break;

			case 2:
				$from = $this->ci->config->item('noreply_email');
				$from_name = $this->ci->config->item('admin_email_name');
				$to = $this->ci->config->item($form.'_email');
                $subject = $this->ci->config->item($form.'_support_subject');
				$view = $this->ci->config->item($form.'_support_email_view');
				break;
		}

		$email->from($from, $from_name);
		$email->to($to);
		$email->subject($subject);

		// Message
		$message = $this->ci->load->view($view, $details, true);

		$email->message($message);

		return $email->send();
	}

/**
 * _redirect method
 *
 * @return void
 */
	function _redirect() {

		// Get current url
		$current_url = current_url();

		// Check query exist in url
		$current_url = $_SERVER['QUERY_STRING'] ? $current_url.'?'.$_SERVER['QUERY_STRING'] : $current_url;

		// Get redirection by url
		$redirection = $this->ci->common->get_redirection_by_url($current_url)->row();

		// Check empty
		if(!empty($redirection)) {

			// Check current url equals to redirect from
			if($current_url == $redirection->from) {

				redirect($redirection->to, 'location', $redirection->status);
			}
		}
	}
}

/* End of file Common_Lib.php */
/* Location: ./application/controllers/libraries/Common_Lib.php */