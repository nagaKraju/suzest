<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forms_Lib {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load form model
		$this->ci->load->model('formm');
	}

/**
 * add_drop_query_and_send_mail method
 *
 * @param array $drop_query
 * @return bool
 */
	function add_drop_query_and_send_mail($drop_query) {

		// Location details
		$drop_query['uid'] = $this->_random_string();
		$drop_query['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$drop_query['city'] = $this->ci->timezones_lib->user_location->city;
		$drop_query['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$drop_query['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('drop_query_user_subject', $this->ci->config->item('drop_query_user_subject').' - '.$drop_query['uid']);
		$this->ci->config->set_item('drop_query_support_subject', $this->ci->config->item('drop_query_support_subject').' - '.$drop_query['uid']);

		// Add drop query
		$drop_query_id = $this->add_drop_query($drop_query);

		// Get drop query by id
		$drop_query = $this->ci->formm->get_drop_query_by_id($drop_query_id)->row();

		// Convert stdclass object to array
		$drop_query = json_decode(json_encode($drop_query), true);

		// Check course exist
		if(!empty($drop_query['course'])) {

			$this->ci->config->set_item('drop_query_user_subject', 'Enquiry For '.$drop_query['course'].' on '.$this->config->item('website_title').' - '.$drop_query['uid']);
			$this->ci->config->set_item('drop_query_support_subject', 'Enquiry For '.$drop_query['course'].' - '.$drop_query['uid']);
		}

		// Send mails
		return $this->ci->common_lib->send_mail($drop_query, 'drop_query', 1) && ($this->ci->common_lib->send_mail($drop_query, 'drop_query', 2));
	}

/**
 * add_drop_query method
 *
 * @param array $details
 * @return bool
 */
	function add_drop_query($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_drop_query($details);
	}


/**
 * add_drop_query_and_send_mail method
 *
 * @param array $drop_query
 * @return bool
 */
	function add_on_site_training_and_send_mail($on_site_training) {

		// Location details
		$on_site_training['uid'] = $this->_random_string();
		$on_site_training['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$on_site_training['city'] = $this->ci->timezones_lib->user_location->city;
		$on_site_training['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$on_site_training['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('on_site_training_user_subject', $this->ci->config->item('on_site_training_user_subject').' - '.$on_site_training['uid']);
		$this->ci->config->set_item('on_site_training_support_subject', $this->ci->config->item('on_site_training_support_subject').' - '.$on_site_training['uid']);

		// Add drop query
		$on_site_training_id = $this->add_on_site_training($on_site_training);

		// Get drop query by id
		$on_site_training = $this->ci->formm->get_on_site_training_by_id($on_site_training_id)->row();

		// Convert stdclass object to array
		$on_site_training = json_decode(json_encode($on_site_training), true);

		// Send mails
		return $this->ci->common_lib->send_mail($on_site_training, 'on_site_training', 1) && ($this->ci->common_lib->send_mail($on_site_training, 'on_site_training', 2));
	}

	/**
	 * add_on_site_training method
	 *
	 * @param array $details
	 * @return bool
	 */
	function add_on_site_training($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_on_site_training($details);
	}

/**
 * add_contact_us_and_send_mail method
 *
 * @param array $contact_us
 * @return bool
 */
	function add_contact_us_and_send_mail($contact_us) {

		// Location details
		$contact_us['uid'] = $this->_random_string();

		// Set config items
		$this->ci->config->set_item('contact_us_user_subject', $this->ci->config->item('contact_us_user_subject').' - '.$contact_us['uid']);
		$this->ci->config->set_item('contact_us_support_subject', $this->ci->config->item('contact_us_support_subject').' - '.$contact_us['uid']);

		if($this->ci->common_lib->send_mail($contact_us, 'contact_us', 1) && (!is_null($contact_us_id = $this->add_contact_us($contact_us)))) {

			// Get contact us by id
			$contact_us = $this->ci->formm->get_contact_us_by_id($contact_us_id)->row();

			// Convert stdclass object to array
			$contact_us = json_decode(json_encode($contact_us), true);

			// Send support mail
			if($this->ci->common_lib->send_mail($contact_us, 'contact_us', 2));
				return true;

			return false;
		}

		return false;
	}

/**
 * add_contact_us method
 *
 * @param array $details
 * @return bool
 */
	function add_contact_us($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_contact_us($details);
	}
	
/**
 * add_become_faculty_and_send_mail method
 *
 * @param array $become_faculty
 * @return bool
 */
	function add_become_faculty_and_send_mail($become_faculty) {

		// Location details
		$become_faculty['uid'] = $this->_random_string();
		$become_faculty['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$become_faculty['city'] = $this->ci->timezones_lib->user_location->city;
		$become_faculty['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$become_faculty['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('become_faculty_user_subject', $this->ci->config->item('become_faculty_user_subject').' - '.$become_faculty['uid']);
		$this->ci->config->set_item('become_faculty_support_subject', $this->ci->config->item('become_faculty_support_subject').' - '.$become_faculty['uid']);

		if($this->ci->common_lib->send_mail($become_faculty, 'become_faculty', 1) && (!is_null($become_faculty_id = $this->add_become_faculty($become_faculty)))) {

			// Get quick enquiry by id
			$become_faculty = $this->ci->formm->get_become_faculty_by_id($become_faculty_id)->row();

			// Convert stdclass object to array
			$become_faculty = json_decode(json_encode($become_faculty), true);

			// Send support mail
			if($this->ci->common_lib->send_mail($become_faculty, 'become_faculty', 2))
				return true;

			return false;
		}

		return false;
	}

/**
 * add_become_faculty method
 *
 * @param array $details
 * @return bool
 */
	function add_become_faculty($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_become_faculty($details);
	}

/**
 * add_connect_and_send_mail method
 *
 * @param array $connect
 * @return bool
 */
	function add_connect_and_send_mail($connect) {

		// Location details
		$connect['uid'] = $this->_random_string();
		$connect['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$connect['city'] = $this->ci->timezones_lib->user_location->city;
		$connect['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$connect['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('connect_user_subject', $this->ci->config->item('connect_user_subject').' - '.$connect['uid']);
		$this->ci->config->set_item('connect_support_subject', $this->ci->config->item('connect_support_subject').' - '.$connect['uid']);

		if($this->ci->common_lib->send_mail($connect, 'connect', 1) && (!is_null($connect_id = $this->add_connect($connect)))) {

			// Get connect by id
			$connect = $this->ci->formm->get_connect_by_id($connect_id)->row();

			// Convert stdclass object to array
			$connect = json_decode(json_encode($connect), true);

			// Send support mail
			if($this->ci->common_lib->send_mail($connect, 'connect', 2));
			return true;

			return false;
		}

		return false;
	}

/**
 * add_connect method
 *
 * @param array $connect
 * @return bool
 */
	function add_connect($connect) {

		$connect['created'] = $connect['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_connect($connect);
	}

/**
 * add_notification_and_send_mail method
 *
 * @param array $notification
 * @return bool
 */
	function add_notification_and_send_mail($notification) {

		// Location details
		$notification['uid'] = $this->_random_string();
		$notification['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$notification['city'] = $this->ci->timezones_lib->user_location->city;
		$notification['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$notification['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Add notification
		$notification_id = $this->add_notification($notification);

		// Get notification by id
		$notification = $this->ci->formm->get_notification_by_id($notification_id)->row();

		// Convert stdclass object to array
		$notification = json_decode(json_encode($notification), true);

		// Set config items
		$this->ci->config->set_item('notification_user_subject', 'New Scheduling Notification For '.$notification['course'].' on '.$this->config->item('website_title').' - '.$notification['uid']);
		$this->ci->config->set_item('notification_support_subject', 'New Scheduling Notification For '.$notification['course'].' - '.$notification['uid']);

		// Send mails
		return $this->ci->common_lib->send_mail($notification, 'notification', 1) && $this->ci->common_lib->send_mail($notification, 'notification', 2);
	}

/**
 * add_notification method
 *
 * @param array $details
 * @return bool
 */
	function add_notification($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_notification($details);
	}

/**
 * add_virtual_demo_register_and_send_mail method
 *
 * @param array $details
 * @return bool
 */
	function add_virtual_demo_register_and_send_mail($details) {

		// Location details
		$details['uid'] = $this->_random_string();
		$details['country_id'] = $this->ci->timezones_lib->training_location->country_id;
		$details['city'] = $this->ci->timezones_lib->training_location->city;
		$details['timezone'] = $this->ci->timezones_lib->training_location->timezone;
		$details['offset'] = $this->ci->timezones_lib->training_location->offset;

		// Get free register by email, session_id and country_id
		$virtual_demo_register = $this->ci->formm->get_virtual_demo_register_by_email($details['email'], $details['virtual_session_id'], $details['country_id'], $details['course_id'])->row();

		// Check empty
		if(empty($virtual_demo_register)) {

			// Add free register
			$virtual_demo_register_id = $this->add_virtual_demo_register($details);

			// Get virtual_demo_register by id
			$virtual_demo_register = $this->ci->formm->get_virtual_demo_register_by_id($virtual_demo_register_id)->row();
		}

		// Convert stdclass object to array
		$virtual_demo_register = json_decode(json_encode($virtual_demo_register), true);

		// Set config items
		$this->ci->config->set_item('virtual_demo_register_user_subject', 'Demo Class Registration For '.$virtual_demo_register['course'].' on '.$this->config->item('website_title').'  - '.$virtual_demo_register['uid']);
		$this->ci->config->set_item('virtual_demo_register_support_subject', 'Demo Class Registration For '.$virtual_demo_register['course'].' - '.$virtual_demo_register['uid']);

		// Send mails
		return $this->ci->common_lib->send_mail($virtual_demo_register, 'virtual_demo_register', 1) && $this->ci->common_lib->send_mail($virtual_demo_register, 'virtual_demo_register', 2);
	}

/**
 * add_virtual_demo_register method
 *
 * @param array $details
 * @return bool
 */
	function add_virtual_demo_register($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_virtual_demo_register($details);
	}

/**
 * email_available_for_virtual_demo_registration method
 *
 * @param string $email, integer $virtual_session_id
 * @return bool
 */
	function email_available_for_virtual_demo_registration($email, $virtual_session_id) {

		return $this->ci->formm->email_available_for_virtual_demo_registration($email, $virtual_session_id);
	}

/**
 * add_custom_quote_and_send_mail method
 *
 * @param array $custom_quote
 * @return bool
 */
	function add_custom_quote_and_send_mail($custom_quote) {

		// Location details
		$custom_quote['uid'] = $this->_random_string();
		$custom_quote['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		//$custom_quote['city'] = $this->ci->timezones_lib->user_location->city;
		$custom_quote['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$custom_quote['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Add custom quote
		$custom_quote_id = $this->add_custom_quote($custom_quote);

		// Get custom_quote by id
		$custom_quote = $this->ci->formm->get_custom_quote_by_id($custom_quote_id)->row();

		// Convert stdclass object to array
		$custom_quote = json_decode(json_encode($custom_quote), true);

		// Set config items
		$this->ci->config->set_item('custom_quote_user_subject', 'Custom Quote For '.$custom_quote['course'].' on '.$this->config->item('website_title').' - '.$custom_quote['uid']);
		$this->ci->config->set_item('custom_quote_support_subject', 'Custom Quote For '.$custom_quote['course'].' - '.$custom_quote['uid']);

		// Send mails
		return $this->ci->common_lib->send_mail($custom_quote, 'custom_quote', 1) && $this->ci->common_lib->send_mail($custom_quote, 'custom_quote', 2);
	}

/**
 * add_custom_quote method
 *
 * @param array $details
 * @return bool
 */
	function add_custom_quote($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_custom_quote($details);
	}

/**
 * add_career_and_send_mail method
 *
 * @param array $career
 * @return bool
 */
	function add_career_and_send_mail($career) {

		// Location details
		$career['uid'] = $this->_random_string();
		$career['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$career['city'] = $this->ci->timezones_lib->user_location->city;
		$career['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$career['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('career_user_subject', $this->ci->config->item('career_user_subject').' - '.$career['uid']);
		$this->ci->config->set_item('career_support_subject', $this->ci->config->item('career_support_subject').' - '.$career['uid']);

		if($this->ci->common_lib->send_mail($career, 'career', 1) && (!is_null($career_id = $this->add_career($career)))) {

			// Get career by id
			$career = $this->ci->formm->get_career_by_id($career_id)->row();

			// Convert stdclass object to array
			$career = json_decode(json_encode($career), true);

			// Send support mail
			if($this->ci->common_lib->send_mail($career, 'career', 2))
				return true;

			return false;
		}

		return false;
	}

/**
 * add_career method
 *
 * @param array $details
 * @return bool
 */
	function add_career($details) {

		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		return $this->ci->formm->add_career($details);
	}

/**
 * add_my_support_and_send_mail method
 *
 * @param array $my_support
 * @return bool
 */
	function add_my_support_and_send_mail($my_support) {

		// Location details
		$my_support['uid'] = $this->_random_string();
		$my_support['country_id'] = $this->ci->timezones_lib->user_location->country_id;
		$my_support['city'] = $this->ci->timezones_lib->user_location->city;
		$my_support['timezone'] = $this->ci->timezones_lib->user_location->timezone;
		$my_support['offset'] = $this->ci->timezones_lib->user_location->offset;

		// Set config items
		$this->ci->config->set_item('my_support_user_subject', $this->ci->config->item('my_support_user_subject').' - '.$my_support['uid']);
		$this->ci->config->set_item('my_support_support_subject', $this->ci->config->item('my_support_support_subject').' - '.$my_support['uid']);

		if($this->ci->common_lib->send_mail($my_support, 'my_support', 1) && (!is_null($my_support_id = $this->add_my_support($my_support)))) {

			// Get my support by id
			$my_support = $this->ci->formm->get_my_support_by_id($my_support_id)->row();

			// Convert stdclass object to array
			$my_support = json_decode(json_encode($my_support), true);

			// Send support mail
			if($this->ci->common_lib->send_mail($my_support, 'my_support', 2))
				return true;

			return false;
		}

		return false;
	}

/**
 * add_my_support method
 *
 * @param array $details
 * @return bool
 */
	function add_my_support($details) {

		$details['uid'] = $this->_random_string();
		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());

		return $this->ci->formm->add_my_support($details);
	}

/**
 * add_subscription_and_send_mail method
 *
 * @param array $subscription
 * @return bool
 */
	function add_subscription_and_send_mail($subscription) {

		if($this->ci->common_lib->send_mail($subscription, 'subscription', 1) && ($this->add_subscription($subscription))) {

			// Send support mail
			if($this->ci->common_lib->send_mail($subscription, 'subscription', 2))
				return true;

			return false;
		}

		return false;
	}

/**
 * add_quick_enquiry method
 *
 * @param array $details
 * @return bool
 */
	function add_subscription($details) {

		$details['uid'] = $this->_random_string();
		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());

		return $this->ci->formm->add_subscription($details);
	}

/**
 * _random_string method
 *
 * @return string
 */
	function _random_string() {

		return mt_rand(1111111, 9999999).substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 3);
	}
}

/* End of file Forms_Lib.php */
/* Location: ./application/controllers/libraries/Forms_Lib.php */