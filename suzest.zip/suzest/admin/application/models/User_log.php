<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_log extends CI_Model {
    
    
/**
 * construct method
 * 
 */    
    public function __construct() {
        
        $this->_table = $this->config->item('user_logs_table');
    }
    
/**
 * add_user_log method
 * 
 * @param array $details
 * @return bool
 */    
    function add_user_log($details) {
        
		$this->db->insert($this->_table, $details);
		
        if($this->db->affected_rows() == 1)
			return true;
        
		return false;
    }

/**
 * get_user_log_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_user_log_by_id($id) {

        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');
        
        $this->db->select("$this->_table.*, $_users_table.username as username, $_users_table.email as email");
        $this->db->join("$_users_table", "$_users_table.id=$this->_table.user_id");
        $this->db->limit(1);
        $this->db->where("$this->_table.id", $id);
        
        return $this->db->get($this->_table);
    }

/**
 * check_user_log_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */     
    function check_user_log_exist_by_id($id) {
        
        $this->db->where('id', $id);

        $query = $this->db->get($this->_table);
        if($query->num_rows() == 0)
            return false;
            
        return true;    
    }

/**
 * get_all_user_logs_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */     
    function get_all_user_logs_for_pagination($limit, $offset) {

        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');
        
        $this->db->select("$this->_table.*, $_users_table.username as username, $_users_table.email as email");
        $this->db->join("$_users_table", "$_users_table.id=$this->_table.user_id");
        $this->db->order_by("$this->_table.created", 'desc');
        
        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_all_user_logs_by_table_for_pagination method
 * 
 * @param string $table, integer $limit, integer $offset
 * @return object
 */     
    function get_all_user_logs_by_table_for_pagination($table, $limit, $offset) {

        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');
        
        $this->db->select("$this->_table.*, $_users_table.username as username, $_users_table.email as email");
        $this->db->join("$_users_table", "$_users_table.id=$this->_table.user_id");
        $this->db->order_by("$this->_table.created", 'desc');
        $this->db->where("$this->_table.table", $table);
        
        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_all_user_logs_by_user_id_for_pagination method
 * 
 * @param integer $user_id, integer $limit, integer $offset
 * @return object
 */     
    function get_all_user_logs_by_user_id_for_pagination($user_id, $limit, $offset) {

        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');
        
        $this->db->select("$this->_table.*, $_users_table.username as username, $_users_table.email as email");
        $this->db->join("$_users_table", "$_users_table.id=$this->_table.user_id");
        $this->db->order_by("$this->_table.created", 'desc');
        $this->db->where("$this->_table.user_id", $user_id);
        
        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_no_of_user_logs method
 * 
 * @return num_rows
 */     
    function get_no_of_user_logs() {
        
        $this->db->select("$this->_table.id");
        $this->db->distinct();
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * get_no_of_user_logs_by_table method
 * 
 * @param string $table
 * @return object
 */     
    function get_no_of_user_logs_by_table($table) {
        
        $this->db->select("$this->_table.id");
        $this->db->where('table', $table);
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * get_no_of_user_logs_by_user_id method
 * 
 * @param integer $user_id
 * @return object
 */     
    function get_no_of_user_logs_by_user_id($user_id) {
        
        $this->db->select("$this->_table.id");
        $this->db->where('user_id', $user_id);
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * get_all_user_logs_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
    function get_all_user_logs_by_search($search, $limit, $offset) {
        
        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');

        $this->db->select("$this->_table.*, $_users_table.username as name, $_users_table.email as email");
        $this->db->join("$_users_table", "$_users_table.id = $this->_table.user_id");
        
        if($search) {

            $this->db->like("$this->_table.table", $search);
            $this->db->or_like("$this->_table.created", $search);
            $this->db->or_like("$_users_table.username", $search);
            $this->db->or_like("$_users_table.email", $search);
        }

        $this->db->order_by("$this->_table.modified", "desc");
        $this->db->distinct();

        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_no_of_user_logs_by_search method
 * 
 * @param string $search
 * @return object
 */
    function get_no_of_user_logs_by_search($search) {

        $_users_table = $this->config->item('DX_table_prefix').$this->config->item('DX_users_table');

        $this->db->join("$_users_table", "$_users_table.id = $this->_table.user_id");
        
        if($search) {

            $this->db->like("$this->_table.table", $search);
            $this->db->or_like("$this->_table.created", $search);
            $this->db->or_like("$_users_table.username", $search);
            $this->db->or_like("$_users_table.email", $search);
        }

        $this->db->distinct();
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * delete_user_log_by_id method
 * 
 * @param integer $id
 * @return bool
 */
    function delete_user_log_by_id($id) {
        
        $this->db->where('id', $id);
        
        $this->db->delete($this->_table);
        
        if($this->db->affected_rows() == 1) {
            return true;
        }
        return false;
    }
}