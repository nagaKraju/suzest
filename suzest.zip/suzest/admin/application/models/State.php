<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class State extends CI_Model {
    
    
/**
 * construct method
 * 
 */    
    public function __construct() {
        
        $this->_table = $this->config->item('states_table');
    }
    
/**
 * add_state method
 * 
 * @param array $details
 * @return integer
 */    
    function add_state($details) {
        
		$this->db->insert($this->_table, $details);
		
        if($this->db->affected_rows() == 1)
			return $this->db->insert_id();
        
		return false;
    }

/**
 * update_state method
 * 
 * @param array $details, integer $id
 * @return bool
 */    
    function update_state($details, $id) {
        
        $this->db->where('id', $id);
        
        return $this->db->update($this->_table, $details);
    }

/**
 * check_state_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */     
    function check_state_exist_by_id($id) {
        
        $this->db->where('id', $id);

        $query = $this->db->get($this->_table);
        if($query->num_rows() == 0)
            return false;
            
        return true;    
    }

/**
 * check_state_exist_by_country_id method
 * 
 * @param integer $id, integer $country_id
 * @return bool
 */
    function check_state_exist_by_country_id($id, $country_id) {
        
        $this->db->where('id', $id);
        $this->db->where('country_id', $country_id);

        $query = $this->db->get($this->_table);
        if($query->num_rows() == 0)
            return false;
            
        return true;    
    }

/**
 * get_state_by_id method
 * 
 * @param integer $id
 * @return object
 */     
    function get_state_by_id($id) {

        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$this->_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id=$this->_table.country_id");
        $this->db->where("$this->_table.id", $id);
        $this->db->limit(1);
        
        return $this->db->get($this->_table);
    }

/**
 * get_all_states_by_country_id method
 *
 * @param integer $country_id, integer $status
 * @return object
 */    
    function get_all_states_by_country_id($country_id, $status = null) {
        
        // Select parameters
        $this->db->select("$this->_table.id, $this->_table.name");
        $this->db->where("$this->_table.country_id", $country_id);

        if($status)
            $this->db->where('status', $status);

        $this->db->order_by("$this->_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($this->_table);
    }

/**
 * get_all_states_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */     
    function get_all_states_for_pagination($limit, $offset) {
        
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$this->_table.*, $_countries_table.name as country");
        $this->db->join("$_countries_table", "$_countries_table.id=$this->_table.country_id");
        
        $this->db->order_by("$this->_table.name", "asc");
        
        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_no_of_states method
 * 
 * @return num_rows
 */     
    function get_no_of_states() {
        
        $this->db->select("$this->_table.id");
        $this->db->distinct();
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * get_all_states_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
    function get_all_states_by_search($search, $limit, $offset) {
        
        $_countries_table = $this->config->item('countries_table');

        $this->db->select("$this->_table.*, $_countries_table.name as country");

        $this->db->join("$_countries_table", "$_countries_table.id=$this->_table.country_id");
        
        if($search) {

            $this->db->like("$this->_table.name", $search);
            $this->db->or_like("$_countries_table.name", $search);
        }

        $this->db->order_by("$this->_table.name", "asc");
        $this->db->distinct();

        return $this->db->get($this->_table, $limit, $offset);
    }

/**
 * get_no_of_states_by_search method
 * 
 * @param string $search
 * @return object
 */
    function get_no_of_states_by_search($search) {

        $_countries_table = $this->config->item('countries_table');

        $this->db->join("$_countries_table", "$_countries_table.id=$this->_table.country_id");
        
        if($search) {

            $this->db->like("$this->_table.name", $search);
            $this->db->or_like("$_countries_table.name", $search);
        }

        $this->db->distinct();
        
        return $this->db->get($this->_table)->num_rows();
    }

/**
 * delete_state_by_id method
 * 
 * @param integer $id
 * @return bool
 */
    function delete_state_by_id($id) {
        
        $this->db->where('id', $id);
        
        $this->db->delete($this->_table);
        
        if($this->db->affected_rows() == 1)
            return true;
        
        return false;
    }

/**
 * get_all_districts_by_state_id method
 *
 * @param integer $state_id
 * @return object
 */
    function get_all_districts_by_state_id($state_id) {

        // Load states config
        $this->load->config('admin/districts');

        $_districts_table = $this->config->item('districts_table');

        // Select parameters
        $this->db->select("$_districts_table.*");

        $this->db->join("$this->_table", "$this->_table.id = $_districts_table.state_id");

        $this->db->where("$_districts_table.state_id", $state_id);
        $this->db->order_by("$_districts_table.name", "asc");
        $this->db->distinct();

        return  $this->db->get($_districts_table);
    }
}