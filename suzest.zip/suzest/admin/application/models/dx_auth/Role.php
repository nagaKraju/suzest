<?php

class Role extends CI_Model 
{
	function __construct()
	{
		parent::__construct();
		
		// Other stuff
		$this->_prefix = $this->config->item('DX_table_prefix');
		$this->_table = $this->_prefix.$this->config->item('DX_roles_table');
	}
	
	function get_all()
	{
		$this->db->order_by('id', 'asc');
		return $this->db->get($this->_table);
	}
	
	function get_role_by_id($role_id)
	{
		$this->db->where('id', $role_id);
		return $this->db->get($this->_table);
	}
	
	function create_role($name, $parent_id = 0)
	{
		$data = array(
			'name' => $name,
			'parent_id' => $parent_id
		);
            
		$this->db->insert($this->_table, $data);
	}
	
	function delete_role($role_id)
	{
		$this->db->where('id', $role_id);
		$this->db->delete($this->_table);		
	}

/**
 * add_role method
 * 
 * @param array $details
 * @return $slug
 */    
    function add_role($details) {
        
		$this->db->insert($this->_table, $details);
		
        if($this->db->affected_rows() == 1)
			return $this->db->insert_id();
        
		return false;
    }

/**
 * update_role method
 * 
 * @param array $details, integer $id
 * @return $slug
 */    
    function update_role($details, $id) {
        
        $this->db->where('id', $id);
        
        return $this->db->update($this->_table, $details);
    }

/**
 * get_role_by_name method
 * 
 * @param string $name
 * @return object
 */     
    function get_role_by_name($name) {
        
        $this->db->select('*');
        $this->db->limit(1);
        $this->db->where('name', $name);
        
        return $this->db->get($this->_table);
    }

/**
 * get_all_roles method
 * 
 * @return object
 */     
    function get_all_roles() {
        
        $this->db->select('*');
        $this->db->order_by('modified', 'desc');
        
        return $this->db->get($this->_table);
    }

/**
 * check_role_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */     
    function check_role_exist_by_id($id) {
        
        $this->db->where('id', $id);

        $query = $this->db->get($this->_table);
        if($query->num_rows() == 0)
            return false;
            
        return true;    
    }

/**
 * check_role_exist_by_name method
 * 
 * @param string $name
 * @return bool
 */     
    function check_role_exist_by_name($name) {
        
        $this->db->where('name', $name);

        $query = $this->db->get($this->_table);
        if($query->num_rows() == 0)
            return false;
            
        return true;    
    }

/**
 * delete_role_by_id method
 * 
 * @param integer $id
 * @return bool
 */
    function delete_role_by_id($id) {
        
        $this->db->where('id', $id);
        
        $this->db->delete($this->_table);
        
        if($this->db->affected_rows() == 1) {
            return true;
        }
        return false;
    }
}

?>