<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Countries extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		parent::__construct();

		// Load Admin_Countries
		$this->load->library(array('Admin_Countries'));

        // Protect entire controller so only admin, 
        // and users that have granted role in permissions table can access it.
        $this->dx_auth->check_uri_permissions();
	}

/**
 * index method
 *
 * @param integer $offset
 * @return void
 */	
	public function index($offset = 1) {

		// Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('countries_index_uri'));
        $total_rows = $this->admin_countries->get_no_of_countries();
        $data['no_of_results'] = $total_rows;
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 2);
        
        // Offset
        $offset = $limit * ($offset - 1);

		// Get all countries
		$data['countries'] = $this->admin_countries->get_all_countries_for_pagination($limit, $offset)->result();

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * add method
 *
 * @return void
 */	
	public function add() {

        // Set validation rules
        $this->form_validation->set_rules('name', 'name', 'trim|required');
        $this->form_validation->set_rules('slug', 'slug', 'trim|required|is_unique[countries.slug, 0]');
        $this->form_validation->set_rules('code', 'code', 'trim|required|is_unique[countries.code, 0]');
        $this->form_validation->set_rules('status', 'status', 'trim|required');
        
        // Run validation
        if($this->form_validation->run() == false) {
            
			return $this->load->view($this->config->item('template_view'));
        }

        // country input data
        $country = array(
            'name' => $this->input->post('name'),
            'code' => $this->input->post('code'),
            'slug' => $this->input->post('slug'),
            'created_by' => $this->session->userdata('DX_user_id'),
            'status' => $this->input->post('status')
        );

        // add country
        if($this->admin_countries->add_country($country)) {
            
            $this->session->set_flashdata('flash_success', 'The country has been added successfully.');
	        redirect($this->config->item('countries_index_uri'));
        }
        
        $data['error'] = 'The country could not be saved.';
       
		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * view method
 *
 * @param integer $id
 * @return void
 */ 
    public function view($id = null) {

        // Check country exist by id
        if(!$this->admin_countries->check_country_exist_by_id($id)) {
            
            $this->session->set_flashdata('flash_error', 'The country does not exist.');
            redirect($this->config->item('countries_index_uri'));
        }
        
        // Get country by id
        $data['country'] = $this->admin_countries->get_country_by_id($id)->row();

        $this->load->view($this->config->item('template_view'), $data); 
    }

/**
 * edit method
 *
 * @param integer $id
 * @return void
 */	
	public function edit($id = null) {

		// Check country exist by id
        if(!$this->admin_countries->check_country_exist_by_id($id)) {
            
            $this->session->set_flashdata('flash_error', 'The country does not exist.');
			redirect($this->config->item('countries_index_uri'));
        }
        
        // Get country by id
        $data['country'] = $this->admin_countries->get_country_by_id($id)->row();;

		// Set validation rules
        $this->form_validation->set_rules('name', 'Name', 'trim|required|is_unique[countries.name, '.$this->uri->segment(3).']');
        $this->form_validation->set_rules('slug', 'slug', 'trim|required|is_unique[countries.slug, '.$this->uri->segment(3).']');
        $this->form_validation->set_rules('code', 'code', 'trim|required');
        $this->form_validation->set_rules('status', 'status', 'trim|required');
        
        // Run validation
        if($this->form_validation->run() == false) {
            
			return $this->load->view($this->config->item('template_view'), $data); 
        }

        // country input data
        $country = array(
            'name' => $this->input->post('name'),
            'created_by' => $this->session->userdata('DX_user_id'),
            'slug' => $this->input->post('slug'),
            'code' => $this->input->post('code'),
            'status' => $this->input->post('status')
        );

        // add country
        if($this->admin_countries->update_country($country, $id)) {
            
            $this->session->set_flashdata('flash_success', 'The country has been saved successfully.');
	        redirect($this->config->item('countries_index_uri'));
        }

        $data['error'] = 'The country could not be saved.';

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * ajax_get_countries_by_search method
 *
 * @throws errorcountries_ajax_get_states_by_country_id_uri
 * @return void
 */    
    public function ajax_get_countries_by_search($offset = 1) {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Input
        $search = $this->input->post('search');
        
        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('countries_ajax_get_countries_by_search_uri'));
        $total_rows = $this->admin_countries->get_no_of_countries_by_search($search);
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 3);
        
        // Offset
        $offset = $limit * ($offset - 1);

        // Get all countries by search
        $data['countries'] = $this->admin_countries->get_all_countries_by_search($search, $limit, $offset)->result();

        $result = array(
            'response' => true,
            'data' => $this->load->view($this->config->item('countries_table_view'), $data, true),
            'pagination' => $this->load->view($this->config->item('pagination_view'), $data, true)
        );

        echo json_encode($result);
        return;
    }

/**
 * ajax_get_country_by_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_country_by_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get country by id
        $country = $this->admin_countries->get_country_by_id($this->input->post('id'))->row();

        $result = array(
            'response' => true,
            'country' => $country
        );

        echo json_encode($result);
        return;
    }

/**
 * ajax_get_all_countries_with_cities method
 *
 * @return void
 */
    public function ajax_get_all_countries_with_cities() {

        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get all countries with cities
        $countries = $this->admin_countries->get_all_countries_with_cities_list();

        $result = array(
            'response' => true,
            'countries' => $countries
        );
        echo json_encode($result);
        return;
    }

/**
 * ajax_get_states_by_country_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_states_by_country_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
             return;
        }

        // Get states by country_id
        $states = $this->admin_countries->get_all_states_by_country_id($this->input->post('country_id'))->result();

        $result = array(
            'response' => true,
            'states' => $states
        );
        echo json_encode($result);
        return;
    }

/**
 * ajax_get_districts_by_state_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_districts_by_state_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get districts by state_id
        $districts = $this->admin_countries->get_all_districts_by_state_id($this->input->post('state_id'))->result();

        $result = array(
            'response' => true,
            'districts' => $districts
        );
        echo json_encode($result);
        return;
    }

/**
 * ajax_get_mandals_by_district_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_mandals_by_district_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get mandals by state_id
        $mandals = $this->admin_countries->get_all_mandals_by_district_id($this->input->post('district_id'))->result();

        $result = array(
            'response' => true,
            'mandals' => $mandals
        );
        echo json_encode($result);
        return;
    }
}

/* End of file countries.php */
/* Location: ./application/controllers/countries.php */