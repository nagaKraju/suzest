<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Roles extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		parent::__construct();

		// Load Admin_Roles library
		$this->load->library('Admin_Roles');

        // Protect entire controller so only admin, 
        // and users that have granted role in permissions table can access it.
        $this->dx_auth->check_uri_permissions();
	}


/**
 * index method
 *
 * @return void
 */	
	public function index() {

		// Get all roles
		$data['roles'] = $this->admin_roles->get_all_roles()->result();

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * add method
 *
 * @return void
 */	
	public function add() {

		// Set validation rules
        $this->form_validation->set_rules('name', 'name', 'trim|required|is_unique[roles.name, 0]');

        // Run validation
        if($this->form_validation->run() == false) {
            
			return $this->load->view($this->config->item('template_view'));
        }

        // role input data
        $role = array(
            'name' => $this->input->post('name')
        );

        // add role
        if($this->admin_roles->add_role($role)) {
            
            $this->session->set_flashdata('flash_success', 'The role has been added successfully.');
	        redirect($this->config->item('roles_index_uri'));
        }
        
        $data['error'] = 'The role could not be saved.';
        
		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * edit method
 *
 * @param integer $id
 * @return void
 */	
	public function edit($id = null) {

		// Check role exist by id
        if(!$this->admin_roles->check_role_exist_by_id($id)) {
            
            $this->session->set_flashdata('flash_error', 'The role does not exist.');
			redirect($this->config->item('roles_index_uri'));
        }
        
        // Get role by id
        $data['role'] = $this->admin_roles->get_role_by_id($id)->row();

		// Set validation rules
        $this->form_validation->set_rules('name', 'name', 'trim|required|is_unique[roles.name, '.$this->uri->segment(3).']');

        // Run validation
        if($this->form_validation->run() == false) {
            
			$this->load->view($this->config->item('template_view'), $data);
            return; 
        }

        // role input data
        $continet = array(
            'name' => $this->input->post('name')
        );

        // add role
        if($this->admin_roles->update_role($continet, $id)) {
            
            $this->session->set_flashdata('flash_success', 'The role has been added successfully.');
	        redirect($this->config->item('roles_index_uri'));
        }
        
        $data['error'] = 'The role could not be saved.';

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * ajax_delete method
 *
 * @param integer $id
 * @return void
 */	
	public function ajax_delete($id = null) {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

		// Check role exist by id
        if(!$this->admin_roles->check_role_exist_by_id($id)) {
            
            $result = array(
                'response' => false,
                'message' => 'The role does not exist.'
            );

            echo json_encode($result);
            return;
        }

        // Delete role by id
        if($this->admin_roles->delete_role_by_id($id)) {
            
            $this->session->set_flashdata('flash_success', 'The role has been deleted.');
			$result = array(
                'response' => true
            );

            echo json_encode($result);
            return;
        }
            
        $result = array(
            'response' => true,
            'message' => 'The instructor role not be deleted.'
        );

        echo json_encode($result);
        return;
	}
}

/* End of file roles.php */
/* Location: ./application/controllers/roles.php */