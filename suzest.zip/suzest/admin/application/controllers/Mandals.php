<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mandals extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		parent::__construct();

		// Load Admin_Mandals, Admin_Countries, Admin_States, Admin_Districts and Admin_Zones libraries
		$this->load->library(array('Admin_Mandals', 'Admin_Countries', 'Admin_States', 'Admin_Districts' ,'Admin_Zones'));

        // Protect entire controller so only admin, 
        // and users that have granted role in permissions table can access it.
        $this->dx_auth->check_uri_permissions();
	}

/**
 * index method
 *
 * @param integer $offset
 * @return void
 */	
	public function index($offset = 1) {

		// Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('mandals_index_uri'));
        $total_rows = $this->admin_mandals->get_no_of_mandals();
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 2);
        
        // Offset
        $offset = $limit * ($offset - 1);

		// Get all mandals
		$data['mandals'] = $this->admin_mandals->get_all_mandals_for_pagination($limit, $offset)->result();

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * add method
 *
 * @return void
 */	
	public function add() {

        // Get countries list
        $data['countries'] = $this->admin_countries->get_all_countries_list(1);

        // Get zones list
        $data['zones'] = $this->admin_zones->get_all_zones_list(1);

		// Set validation rules
        $this->form_validation->set_rules('name', 'name', 'trim|required');
        $this->form_validation->set_rules('slug', 'slug', 'trim|required|is_unique[mandals.slug, 0]');
        $this->form_validation->set_rules('code', 'code', 'trim|required|is_unique[mandals.code, 0]');
        $this->form_validation->set_rules('country_id', 'country', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('state_id', 'state', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('district_id', 'district', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('zone_id', 'zone', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('status', 'status', 'trim|required');

        // Run validation
        if($this->form_validation->run() == false) {
            
			return $this->load->view($this->config->item('template_view'), $data);
        }

        // mandal input data
        $mandal = array(
            'name' => $this->input->post('name'),
            'slug' => $this->input->post('slug'),
            'code' => $this->input->post('code'),
            'country_id' => $this->input->post('country_id'),
            'state_id' => $this->input->post('state_id'),
            'district_id' => $this->input->post('district_id'),
            'zone_id' => $this->input->post('zone_id'),
            'created_by' => $this->session->userdata('DX_user_id'),
            'status' => $this->input->post('status')
        );

        // add mandal
        if($this->admin_mandals->add_mandal($mandal)) {
            
            $this->session->set_flashdata('flash_success', 'The mandal has been added successfully.');
	        redirect($this->config->item('mandals_index_uri'));
        }
        
        $data['error'] = 'The mandal could not be saved.';
		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * edit method
 *
 * @param integer $id
 * @return void
 */	
	public function edit($id = null) {

		// Check mandal exist by id
        if(!$this->admin_mandals->check_mandal_exist_by_id($id)) {
            
            $this->session->set_flashdata('flash_error', 'The mandal does not exist.');
			redirect($this->config->item('mandals_index_uri'));
        }
        
        // Get mandal by id
        $data['mandal'] = $this->admin_mandals->get_mandal_by_id($id)->row();

        // Get countries list
        $data['countries'] = $this->admin_countries->get_all_countries_list(1);

        // Get zones list
        $data['zones'] = $this->admin_zones->get_all_zones_list(1);

		// Set validation rules
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('slug', 'slug', 'trim|required|is_unique[mandals.slug, '.$this->uri->segment(3).']');
        $this->form_validation->set_rules('code', 'code', 'trim|required');
        $this->form_validation->set_rules('country_id', 'Country', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('district_id', 'District', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('zone_id', 'Zone', 'trim|required|numeric|greater_than[0]');
        $this->form_validation->set_rules('status', 'status', 'trim|required');

        // Run validation
        if($this->form_validation->run() == false) {
            
            return $this->load->view($this->config->item('template_view'), $data);
        }

        // mandal input data
        $mandal = array(
            'name' => $this->input->post('name'),
            'slug' => $this->input->post('slug'),
            'code' => $this->input->post('code'),
            'country_id' => $this->input->post('country_id'),
            'state_id' => $this->input->post('state_id'),
            'district_id' => $this->input->post('district_id'),
            'zone_id' => $this->input->post('zone_id'),
            'created_by' => $this->session->userdata('DX_user_id'),
            'status' => $this->input->post('status')
        );

        // update mandal
        if($this->admin_mandals->update_mandal($mandal, $id)) {
            
            $this->session->set_flashdata('flash_success', 'The mandal has been saved successfully.');
	        redirect($this->config->item('mandals_index_uri'));
        }

        $data['error'] = 'The mandal could not be saved.';
		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * ajax_get_mandals_by_search method
 *
 * @param integer $offset
 * @throws error
 * @return void
 */    
    public function ajax_get_mandals_by_search($offset = 1) {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Input
        $search = $this->input->post('search');
        
        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('mandals_ajax_get_mandals_by_search_uri'));
        $total_rows = $this->admin_mandals->get_no_of_mandals_by_search($search);
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 3);
        
        // Offset
        $offset = $limit * ($offset - 1);

        // Get all mandals by search
        $data['mandals'] = $this->admin_mandals->get_all_mandals_by_search($search, $limit, $offset)->result();

        $result = array(
            'response' => true,
            'data' => $this->load->view($this->config->item('mandals_table_view'), $data, true),
            'pagination' => $this->load->view($this->config->item('pagination_view'), $data, true)
        );

        echo json_encode($result);
        return;
    }

/**
 * ajax_get_mandal_by_id method
 *
 * @throws error
 * @return void
 */
    public function ajax_get_mandal_by_id() {

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {

            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Get mandal by id
        $mandal = $this->admin_mandals->get_mandal_by_id($this->input->post('id'))->row();
        $result = array(
            'response' => true,
            'mandal' => $mandal
        );
        echo json_encode($result);
    }

/**
 * ajax_get_mandals_by_country_id method
 *
 * @throws error
 * @return void
 */    
    public function ajax_get_mandals_by_country_id() {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }
        
        // Get mandals by country id
        $mandals = $this->admin_mandals->get_all_mandals_by_country_id($this->input->post('country_id'), 1)->result();
        $result = array(
            'response' => true,
            'mandals' => $mandals
        );
        echo json_encode($result);
    }

/**
 * ajax_get_all_mandals_by_country_id method
 *
 * @throws error
 * @return void
 */    
    public function ajax_get_all_mandals_by_country_id() {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }
        
        // Get mandals by country id
        $mandals = $this->admin_mandals->get_all_mandals_by_country_id($this->input->post('country_id'))->result();
        $result = array(
            'response' => true,
            'mandals' => $mandals
        );
        echo json_encode($result);
    }
    
/**
 * ajax_get_mandals_by_countries method
 *
 * @throws error
 * @return void
 */    
    public function ajax_get_mandals_by_countries() {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }
        
        // Countries
        $countries = $this->input->post('countries');
        
        // Get mandals
        $mandals = $this->admin_mandals->get_all_mandals_by_countries($countries, 1);
        $result = array(
            'response' => true,
            'mandals' => $mandals
        );
        echo json_encode($result);
    }
}

/* End of file mandals.php */
/* Location: ./application/controllers/admin/mandals.php */