<?php
class Auth extends CI_Controller
{
	// Used for registering and changing password form validation
	var $min_username = 4;
	var $max_username = 20;
	var $min_password = 4;
	var $max_password = 20;

	function __construct() {

		parent::__construct();
	}

	function index() {

		$this->login();
	}
	
	/* Callback function */
	
	function username_check($username) {

		$result = $this->dx_auth->is_username_available($username);
		if ( ! $result) {

			$this->form_validation->set_message('username_check', 'Username already exist. Please choose another username.');
		}
				
		return $result;
	}

	function email_check($email) {

		// Id
        $id = $this->uri->segment(3);

		$result = $this->dx_auth->is_email_available($email);
		if(!$result) {

			// Get user by email
			$user = $this->dx_auth->get_user_by_email($email)->row();

			$this->form_validation->set_message('email_check', 'Email is already used by another user. Please choose another email address.');
		}
				
		return $result;
	}

	
	function recaptcha_check() {

		$result = $this->dx_auth->is_recaptcha_match();		
		if ( ! $result) {

			$this->form_validation->set_message('recaptcha_check', 'Your confirmation code does not match the one in the image. Try again.');
		}
		
		return $result;
	}
	
	/* End of Callback function */
	
/**
 * login method
 *
 * @return void
 */	
	function login() {

		if($this->dx_auth->is_logged_in()) {

			redirect(base_url(''));
		}

		// Set form validation rules
		$this->form_validation->set_rules('email', 'email', 'trim|required');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
		$this->form_validation->set_rules('remember', 'remember me', 'integer');


		if ($this->form_validation->run() AND $this->dx_auth->login($this->input->post('email'), $this->input->post('password'), $this->input->post('remember'))) {

			redirect(base_url(''));
		}

		// Check if the user is failed logged in because user is banned user or not
		if ($this->dx_auth->is_banned()) {

			// Redirect to banned uri
			return $this->dx_auth->deny_access('banned');
		}						

		$data['error'] = $this->dx_auth->get_auth_error();
		return $this->load->view($this->config->item('template_view'), $data);
	}

/**
 * logout method
 *
 * @return void
 */	
	function logout() {

		$this->dx_auth->logout();
		
		// Redirect to login
		redirect($this->config->item('auth_login_uri'));
	}

/**
 * register method
 *
 * @return void
 */
	function register() {

		// Load Admin_Roles library
		$this->load->library('Admin_Roles');

		// Get roles list
		$data['roles'] = $this->admin_roles->get_roles_list();

		// Set form validation rules
		$this->form_validation->set_rules('username', 'username', 'trim|required');
		$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email|callback_email_check');
		$this->form_validation->set_rules('password', 'password', 'trim|required|min_length[6]|max_length[20]');
		$this->form_validation->set_rules('confirm_password', 'confirm password', 'trim|matches[password]');
		$this->form_validation->set_rules('role_id', 'role', 'trim|required');
		
		// Check validation run
		if($this->form_validation->run() == false) {

			return $this->load->view($this->config->item('template_view'), $data);
		}

		// Input data
		$user = array(
			'username' => $this->input->post('username'),
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password'),
			'role_id' => $this->input->post('role_id'),
		);

		// Register user
		if($this->dx_auth->register($user)) {	

			// Set success message accordingly
			if ($this->dx_auth->email_activation) {

				$this->session->set_flashdata('flash_success', 'The user successfully registered. Check email address to activate account.');
			} else {					

				$this->session->set_flashdata('flash_success', 'The user successfully registered.');
			}
			
			// Redirect to register page
			redirect($this->config->item('auth_users_uri'));
		} 

		$data['error'] = 'The user could not be registered';
		// Load registration page
		$this->load->view($this->config->item('template_view'), $data);
	}
	
	function activate() {

		// Get username and key
		$username = $this->uri->segment(3);
		$key = $this->uri->segment(4);

		// Activate user
		if ($this->dx_auth->activate($username, $key)) {

			$data['auth_message'] = 'Your account have been successfully activated. '.anchor(site_url($this->dx_auth->login_uri), 'Login');
			$this->load->view($this->dx_auth->activate_success_view, $data);
		} else {

			$data['auth_message'] = 'The activation code you entered was incorrect. Please check your email again.';
			$this->load->view($this->dx_auth->activate_failed_view, $data);
		}
	}
	
	function forgot_password() {

		$val = $this->form_validation;
		
		// Set form validation rules
		$val->set_rules('email', 'email', 'trim|required');

		// Validate rules and call forgot password function
		if ($val->run() AND $this->dx_auth->forgot_password($val->set_value('email'))) {

			$data['auth_message'] = 'An email has been sent to your email with instructions with how to activate your new password.';
			$this->load->view($this->config->item('template_view'), $data);
		} else {

			$data['title_for_layout'] = 'Admin - Forgot Password';
			$data['auth_error'] = $this->dx_auth->get_auth_error();
			$this->load->view($this->config->item('template_view'), $data);
		}
	}
	
	function reset_password() {

		// Get username and key
		$username = $this->uri->segment(3);
		$key = $this->uri->segment(4);

		// Reset password
		if ($this->dx_auth->reset_password($username, $key)) {

			$data['auth_message'] = 'You have successfully reset you password, '.anchor(base_url($this->config->item('auth_login_uri')), 'Login');
			$this->load->view($this->config->item('template_view'), $data);
		} else {

			$data['auth_error'] = 'Reset failed. Your username and key are incorrect. Please check your email again and follow the instructions.';
			$this->load->view($this->config->item('template_view'), $data);
		}
	}
	
	function change_password() {

		// Check if user logged in or not
		if(!$this->dx_auth->is_logged_in()) {			

            $this->session->set_flashdata('flash_failure', 'Please login to change the password.');
            redirect($this->config->item('auth_login_uri'));
        }

		// Set form validation
		$this->form_validation->set_rules('old_password', 'old password', 'trim|required|min_length['.$this->min_password.']|max_length['.$this->max_password.']');
		$this->form_validation->set_rules('new_password', 'new password', 'trim|required|min_length['.$this->min_password.']|max_length['.$this->max_password.']|matches[confirm_new_password]');
		$this->form_validation->set_rules('confirm_new_password', 'confirm new password', 'trim|required');

        // Check validation run
        if($this->form_validation->run() == false) {

            return $this->load->view($this->config->item('template_view'));
        }

		// Change password
		if ($this->dx_auth->change_password($this->input->post('old_password'), $this->input->post('new_password'))) {

            $this->session->set_flashdata('flash_success', 'Your password has successfully been changed.');
			redirect($this->config->item('auth_profile_uri'));
		}

        $data['error'] = 'Change password failed.';
		return $this->load->view($this->config->item('template_view'), $data);
	}	
	
	function cancel_account() {

		// Check if user logged in or not
		if ($this->dx_auth->is_logged_in()) {

			$val = $this->form_validation;
			
			// Set form validation rules
			$val->set_rules('password', 'Password', "trim|required");
			
			// Validate rules and change password
			if ($val->run() AND $this->dx_auth->cancel_account($val->set_value('password'))) {

				// Redirect to homepage
				redirect('', 'location');
			} else {

				$this->load->view($this->dx_auth->cancel_account_view);
			}
		} else {

			// Redirect to login page
			$this->dx_auth->deny_access('login');
		}
	}

/**
 * permissions method
 *
 * @return void
 */
	function permissions() {

		// Check if user logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			redirect(base_url($this->config->item('auth_login_uri')));
		}

		function trim_value(&$value) {

			$value = trim($value); 
		}

		// Load Admin_Roles library
		$this->load->library('Admin_Roles');
	
		$this->load->model('dx_auth/permissions', 'permissions');
		
		if($this->input->post('save')) {

			// Convert back text area into array to be stored in permission data
			$allowed_uris = explode("\n", $this->input->post('allowed_uris'));
			
			// Remove white space if available
			array_walk($allowed_uris, 'trim_value');
		
			// Set URI permission data
			// IMPORTANT: uri permission data, is saved using 'uri' as key.
			// So this key name is preserved, if you want to use custom permission use other key.
			$this->permissions->set_permission_value($this->input->post('role'), 'uri', $allowed_uris);
		}
		
		/* Showing page to user */		
		
		// Default role_id that will be showed
		$role_id = $this->input->post('role') ? $this->input->post('role') : 1;
		
		// Get all role list
		$data['roles'] = $this->admin_roles->get_roles_list();
		
		// Get allowed uri permissions
		$data['allowed_uris'] = $this->permissions->get_permission_value($role_id, 'uri');

		if(!empty($data['allowed_uris'])) {

			$data['allowed_uris'] = implode("\n", $data['allowed_uris']);
		}
		
		// Load view
		return $this->load->view($this->config->item('template_view'), $data);
	}

	// Example how to get permissions you set permission in /backend/custom_permissions/
	function custom_permissions() {

		if ($this->dx_auth->is_logged_in()) {

			echo 'My role: '.$this->dx_auth->get_role_name().'<br/>';
			echo 'My permission: <br/>';
			
			if ($this->dx_auth->get_permission_value('edit') != NULL AND $this->dx_auth->get_permission_value('edit')) {

				echo 'Edit is allowed';
			} else {

				echo 'Edit is not allowed';
			}
			
			echo '<br/>';
			
			if ($this->dx_auth->get_permission_value('delete') != NULL AND $this->dx_auth->get_permission_value('delete')) {

				echo 'Delete is allowed';
			} else {

				echo 'Delete is not allowed';
			}
		}
	}

/**
 * users method
 *
 * @param integer $offset
 * @return void
 */ 
    public function users($offset = 1) {

    	// Check if user logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			redirect(base_url($this->config->item('auth_login_uri')));
		}

    	// Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('auth_users_uri'));

        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

        	$total_rows = $this->dx_auth->get_no_of_users();
        } else {

        	$total_rows = $this->dx_auth->get_no_of_users_by_role_id($this->dx_auth->get_role_id());
        }
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 3);
        
        // Offset
        $offset = $limit * ($offset - 1);

        // Get all users
        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

        	$data['users'] = $this->dx_auth->get_all_users_for_pagination($limit, $offset)->result();
        } else {

        	$data['users'] = $this->dx_auth->get_all_users_by_role_id_for_pagination($this->dx_auth->get_role_id(), $limit, $offset)->result();
        }

        $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * edit method
 *
 * @param integer $id
 * @return void
 */
	function edit($id) {

		// Check user is logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			redirect(base_url($this->config->item('auth_login_uri')));
		}

        // Check user exist by id
        if(!$this->dx_auth->check_user_exist_by_id($id)) {

            redirect(base_url($this->config->item('auth_users_uri')));
        }

        // Load Admin_Roles library
        $this->load->library('Admin_Roles');

        // Get all role list
        $data['roles'] = $this->admin_roles->get_roles_list();

		// Get user by id
		$data['user'] = $this->dx_auth->get_user_by_id($this->dx_auth->get_user_id())->row();

		// Set form validation rules
        $this->form_validation->set_rules('role_id', 'role', 'trim|required');
        
		// Check validation run
		if($this->form_validation->run() == false) {

			return $this->load->view($this->config->item('template_view'), $data);
		}

		// Input data
		$user = array(
			'role_id' => $this->input->post('role_id')
		);

		// Register user
		if($this->dx_auth->set_user($this->dx_auth->get_user_id(), $user)) {	

			$this->session->set_flashdata('flash_success', 'The user has been saved successfully.');
			redirect($this->config->item('auth_users_uri'));
		} 

		$data['error'] = 'The user could not be saved';
		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * profile method
 *
 * @return void
 */	
	function profile() {

		// Check user logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			redirect(base_url($this->config->item('auth_login_uri')));
		}

        // Get logged user
		$data['user'] = $this->dx_auth->get_user_by_id($this->dx_auth->get_user_id())->row();

		return $this->load->view($this->config->item('template_view'), $data);
	}

/**
 * ajax_delete method
 *
 * @param integer $id
 * @return void
 */	
	public function ajax_delete($id = null) {

		// Check if user logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			$result = array(
                'response' => false,
                'message' => 'Login to delete the record.'
            );
            echo json_encode($result);
            return;
		}

        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

		// Check user exist by id
        if(!$this->dx_auth->check_user_exist_by_id($id)) {
            
            $result = array(
                'response' => false,
                'message' => 'The user does not exist.'
            );

            echo json_encode($result);
            return;
        }

        // Delete user by id
        if($this->dx_auth->delete_user_by_id($id)) {
            
            $this->session->set_flashdata('flash_success', 'The user has been deleted.');
            $result = array(
                'response' => true
            );

            echo json_encode($result);
            return;
			
        } else {
            
            $result = array(
                'response' => true,
                'message' => 'The user could not be deleted.'
            );

            echo json_encode($result);
            return;
        }
	}

/**
 * ajax_get_users_by_search method
 *
 * @param integer $offset
 * @throws error
 * @return void
 */    
    public function ajax_get_users_by_search($offset = 1) {

    	// Check if user logged in or not
		if(!$this->dx_auth->is_logged_in()) {

			$result = array(
                'response' => false,
                'message' => 'Login to delete the record.'
            );
            echo json_encode($result);
            return;
		}
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Input
        $search = $this->input->post('search');
        
        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('users_ajax_get_users_by_search_uri'));

        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

        	$total_rows = $this->dx_auth->get_no_of_users_by_search($search);
        } else {

        	$total_rows = $this->dx_auth->get_no_of_users_by_role_id_by_search($this->dx_auth->get_role_id(), $search);
        }
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 3);
        
        // Offset
        $offset = $limit * ($offset - 1);

        // Get all users by search
        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

        	$data['users'] = $this->dx_auth->get_all_users_by_search($search, $limit, $offset)->result();
        } else {

        	$data['users'] = $this->dx_auth->get_all_users_by_role_id_by_search($this->dx_auth->get_role_id(), $search, $limit, $offset)->result();
        }

        $result = array(
            'response' => true,
            'data' => $this->load->view($this->config->item('auth_table_view'), $data, true),
            'pagination' => $this->load->view($this->config->item('pagination_view'), $data, true)
        );
        echo json_encode($result);
        return;
    }

	function deny() {
		
		$data['message'] = 'Oops! Sorry, an error has occured. Requested page not found!';

		$this->load->view($this->config->item('template_view'), $data);
	}

/**
 * _image_upload method
 * 
 * @return void
 */    
    public function _image_upload() {
        
        if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
            
            $config['upload_path']   = APPPATH.'../../'.$this->config->item('images_path').$this->config->item('auth_images_path');
            $config['allowed_types'] = 'gif|jpg|png';
            $config['overwrite'] = false;
            
            // Check file exists
            if(!file_exists($config['upload_path']) && !is_dir($config['upload_path'])) {
                
                // create dir
                mkdir($config['upload_path'], 0777, true);
            }
            
            // Load upload library
            $this->load->library('upload', $config);
           
            if ($this->upload->do_upload('image')) {
                
                // set a $_POST value for 'image' that we can use later
                $upload_data = $this->upload->data();
                
                $_POST['image'] = $upload_data['file_name'];
                
                $this->_cleanup[] = $upload_data['full_path'];
                
                return true;
                
            } else {
                
                // possibly do some clean up ... then throw an error
                $this->form_validation->set_message('_image_upload', $this->upload->display_errors());
                return false;
            }
        } else {
            
            // throw an error because nothing was uploaded
            $this->form_validation->set_message('_image_upload', "The image is required.");
            return false;
        }
    }
    
/**
 * _delete_files method
 * 
 * @return void
 */    
    public function _delete_files() {
        
        if(isset($this->_cleanup) && !empty($this->_cleanup)) {
            
            foreach($this->_cleanup as $path) {
                unlink($path);   
            }
        }
    }
}