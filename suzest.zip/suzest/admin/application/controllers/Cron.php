<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cron extends CI_Controller {

/**
 * Constructor
 *
 * @var array
 */
    function __construct() {

        parent::__construct();
    }

/**
 * update_sessions_status method
 * 
 * @return void
 */
    public function update_sessions_status() {
        
        // Load Admin_Sessions library
        $this->load->library('Admin_Sessions');

        return $this->admin_sessions->update_sessions_status();
    }

/**
 * update_currency_conversion method
 *
 * @return void
 */ 
    public function update_currency_conversion() {

        // Load Admin_Currencies library
        $this->load->library('Admin_Currencies');

        return $this->admin_currencies->update_currency_conversion();
    }

/**
 * update_sitemap method
 *
 * @return void
 */ 
    public function update_sitemap() {

        // Load Admin_Sitemap library
        $this->load->library('Admin_Sitemap');

        return $this->admin_sitemap->update_sitemap();
    }

/**
 * read_countries_timezones_html method
 *
 * @return void
 */ 
    public function read_countries_timezones_html() {

        // Countries
        $countries = array();
        $alphabets = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 
            'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'y', 'z'
        );

        // Loop alphabets
        foreach($alphabets as $alphabet) {

            $data = file_get_contents('http://www.geoips.com/en/resources/timezones/by-country/letter/'.$alphabet);

            $dom = new domDocument;

            @$dom->loadHTML($data);
            $dom->preserveWhiteSpace = false;
            $tables = $dom->getElementsByTagName('table');

            $tbody = $tables->item(0)->getElementsByTagName('tbody');
            $rows = $tbody->item(0)->getElementsByTagName('tr');

            foreach ($rows as $row) {

                // Cols
                $cols = $row->getElementsByTagName('td');

                $country = $cols->item(0)->nodeValue;

                // Timezones
                $timezone_lists = $cols->item(1)->getElementsByTagName('li');
                
                // Loop
                $timezones = array();
                foreach($timezone_lists as $list) {

                    $timezone = array();
                    $timezone['timezone'] = $list->nodeValue;

                    $timezones[] = $timezone;
                }

                // Offsets
                $offset_lists = $cols->item(2)->getElementsByTagName('li');

                // Loop
                $new_timezones = array();
                foreach($offset_lists as $key => $list) {

                    $offset = str_replace('UTC/GMT ', '', $list->nodeValue);
                    $new_timezones[$timezones[$key]['timezone']] = ($offset == '') ? '+00:00' : $offset;
                }

                $countries[$country] = $new_timezones;
            }
        }

        $exist_countries = $non_exist_countries = array();

        // Load Admin_Countries Library
        $this->load->library('Admin_Countries');

        // Query
        $queries = '';
        foreach($countries as $key => $timezones) {

            $country_data = $this->admin_countries->get_country_by_name($key)->row();
            if(!empty($country_data)) {

                foreach($timezones as $key => $timezone) {

                    $query = "SELECT * FROM new_timezones WHERE name = '".$key."'";
                    $new_timezone = $this->db->query($query)->row();
                    
                    $queries .= "insert into new_countries_timezones values('', $country_data->id, $new_timezone->id); \n";
                }
            }
        }
    }

/**
 * minify_css_and_js method
 *
 * @return void
 */ 
    public function minify_css_and_js() {

        // CSS and JS Files
        $files = array(
            'css' => array(
                'styles1.min.css' => 'styles.min.css'
            ),
            'js' => array(
                'form1.min.js' => 'form.min.js'
            )
        );

        // CSS

        // Directory
        $dir = FCPATH.'/../assets/css/';

        // Minify
        $this->_minify('http://cssminifier.com/raw', $files['css'], $dir);

        // JS

        // Directory
        $dir = FCPATH.'/../assets/js/';

        // Minify
        $this->_minify('http://javascript-minifier.com/raw', $files['js'], $dir);
    }

/**
 * combine_css_and_js method
 *
 * @return void
 */ 
    public function combine_css_and_js() {

        // CSS and JS Files
        $files = array(
            'css' => array('bootstrap.min.css', 'font-awesome.min.css', 'styles1.min.css'),
            'js' => array('jquery.min.js', 'bootstrap.min.js', 'jquery.sticky.min.js', 'jquery.easing.min.js', 
                        'jquery.smoothscroll.min.js', 'jquery.owl.carousel.min.js', 'jquery.growl.min.js', 'validate.min.js',
                        'arrow79.js', 'form1.min.js')
        );

        // Directory
        $dir = FCPATH.'/../assets/css/';
        
        // Combine into one
        $this->_combine('main.min.css', $files['css'], $dir);

        // JS

        // Directory
        $dir = FCPATH.'/../assets/js/';

        // Combine into one
        $this->_combine('scripts.min.js', $files['js'], $dir);
    }

/**
 * _combine method
 *
 * @param string $combine_file, array $files, string $dir
 * @return void
 */
    public function _combine($combine_file, $files, $dir) {

        // Check empty
        if(!empty($files)) {

            // Content
            $content = '';

            foreach($files as $file) {

                // File
                $file_name = $file;
                $file = $dir.'/'.$file;

                // File Start
                $content .= '/*'.$file_name.'*/'."\n";

                // Minify and save
                $content .= file_get_contents($file)."\n";
            }

            // Combine File
            $combine_file = $dir.'/'.$combine_file;

            // Delete file
            if(file_exists($combine_file)) {

                unlink($combine_file);
            }

            // Create new file
            $handler = fopen($combine_file, 'w');
            fwrite($handler, $content);
            fclose($handler);
        }
    }

/**
 * _minify method
 *
 * @param string $url, array $files, string $dir
 * @return void
 */
    public function _minify($url, $files, $dir) {

        // Check empty
        if(!empty($files)) {

            foreach($files as $new_file => $file) {

                // File
                $file = $dir.'/'.$file;

                // Create new file
                $new_file = $dir.'/'.$new_file;
                $handler = fopen($new_file, 'w');
                fwrite($handler, file_get_contents($file));
                fclose($handler);

                // Minify and save
                $content = $this->_get_minified($url, file_get_contents($new_file));
                $handler = fopen($new_file, 'w');
                fwrite($handler, $content);
                fclose($handler);
            }  
        }
    }

/**
 * _get_minified method
 *
 * @param string $url, string $content
 * @return void
 */
    function _get_minified($url, $content) {
        
        $postdata = array(
            'http' => array(
                'method'  => 'POST',
                'header'  => 'Content-type: application/x-www-form-urlencoded',
                'content' => http_build_query(array('input' => $content))
            ) 
        );

        return file_get_contents($url, false, stream_context_create($postdata));
    }
}