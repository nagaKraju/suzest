<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_logs extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		parent::__construct();

		// Load Admin_User_Logs library
		$this->load->library('Admin_User_Logs');

        // Protect entire controller so only admin, 
        // and users that have granted role in permissions table can access it.
        $this->dx_auth->check_uri_permissions();
	}

/**
 * index method
 *
 * @param integer $offset
 * @return void
 */ 
    public function index($offset = 1) {

        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('user_logs_index_uri'));

        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

            $total_rows = $this->admin_user_logs->get_no_of_user_logs();
        } else {

            $total_rows = $this->admin_user_logs->get_no_of_user_logs_by_user_id($this->dx_auth->get_user_id());
        }
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 2);
        
        // Offset
        $offset = $limit * ($offset - 1);

        if(strtolower($this->dx_auth->get_role_name()) == 'admin') {

            // Get all user_logs
            $data['user_logs'] = $this->admin_user_logs->get_all_user_logs_for_pagination($limit, $offset)->result();
        } else {

            // Get all user_logs
            $data['user_logs'] = $this->admin_user_logs->get_all_user_logs_by_user_id_for_pagination($this->dx_auth->get_user_id(), $limit, $offset)->result();
        }

        $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * filter method
 *
 * @param integer $offset
 * @return void
 */ 
    public function filter($type, $value = null, $offset = 1) {

        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('user_logs_filter_uri').$type.'/'.$value);
        
        // Limit
        $data['limit'] = $limit = 20;
        $data['offset'] = $offset;
        
        // Offset
        $offset = $limit * ($offset - 1);

        switch($type) {

            case 1:
                    $table = $this->config->item('admin_tables')[$value];
                    $total_rows = $this->admin_user_logs->get_no_of_user_logs_by_table($table);
                    
                    // Get all user_logs
                    $data['user_logs'] = $this->admin_user_logs->get_all_user_logs_by_table_for_pagination($table, $limit, $offset)->result();
                    break;

            case 2:
                    $total_rows = $this->admin_user_logs->get_no_of_user_logs_by_user_id($value);
                    
                    // Get all user_logs
                    $data['user_logs'] = $this->admin_user_logs->get_all_user_logs_by_user_id_for_pagination($value, $limit, $offset)->result();

        }

        $data['pagination'] = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 5);

        $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * view method
 *
 * @param integer $id
 * @return void
 */ 
    public function view($id = null) {

        // Check user log exist by id
        if(!$this->admin_user_logs->check_user_log_exist_by_id($id)) {
            
            $this->session->set_flashdata('flash_error', 'The user log does not exist.');
            redirect($this->config->item('admin_user_logs_index_uri'));
        }
        
        // Get user log by id
        $data['user_log'] = $this->admin_user_logs->get_user_log_by_id($id)->row();

        $this->load->view($this->config->item('template_view'), $data);
    }

/**
 * ajax_get_user_logs_by_search method
 *
 * @param integer $offset
 * @throws error
 * @return void
 */    
    public function ajax_get_user_logs_by_search($offset = 1) {
        
        // Check the ajax request
        if (!$this->input->is_ajax_request()) {
           
            $result = array(
                'response' => false,
                'message' => 'This method not allowed.'
            );
            echo json_encode($result);
            return;
        }

        // Input
        $search = $this->input->post('search');
        
        // Load Admin_Pagination library
        $this->load->library('Admin_Pagination');

        // Pagination
        $base_url = base_url($this->config->item('user_logs_ajax_get_user_logs_by_search_uri'));
        $total_rows = $this->admin_user_logs->get_no_of_user_logs_by_search($search);
        
        // Limit
        $limit = 20;
        $off = $offset;
        
        $pagination = $this->admin_pagination->pagination($base_url, $total_rows, $limit, 3);
        
        // Offset
        $offset = $limit * ($offset - 1);

        // Get all user logs by search
        $user_logs = $this->admin_user_logs->get_all_user_logs_by_search($search, $limit, $offset)->result();

        $result = array(
            'response' => true,
            'user_logs' => $user_logs,
            'pagination' => $pagination,
            'limit' => $limit,
            'offset' => $off - 1
        );
        echo json_encode($result);
        return;
    }

}

/* End of file user_logs.php */
/* Location: ./application/controllers/user_logs.php */