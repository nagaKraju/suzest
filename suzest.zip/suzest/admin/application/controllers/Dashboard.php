<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

/**
 * construct method
 *
 * @return void
 */
	function __construct() {

		parent::__construct();


		// Load Admin_Countries, Admin_Dashboard libraries
		$this->load->library(array('Admin_Countries', 'Admin_Dashboard'));


        // Protect entire controller so only admin, 
        // and users that have granted role in permissions table can access it.
        $this->dx_auth->check_uri_permissions();
	}


/**
 * index method
 *
 * @return void
 */	
	public function index() {

		// Get all countires
		$data['countires'] = $this->admin_countries->get_all_countries_for_pagination(5, 0)->result();

		$this->load->view($this->config->item('template_view'), $data);
	}
}

/* End of file dashboard.php */
/* Location: ./application/controllers/dashboard.php */