<?php $this->ci = &get_instance(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
    	<title><?php echo $heading; ?></title>
        <!-- styles -->
        <?php $this->ci->load->view($this->ci->config->item('styles_view')); ?>
        <!-- /styles -->
    </head>

    <body>

    	<!-- Navbar -->
        <?php $this->ci->load->view($this->ci->config->item('navbar_view')); ?>
        <!-- /navbar -->

        <!-- Page header -->
        <?php $this->ci->load->view($this->ci->config->item('page_header_view')); ?>
        <!-- /page header -->

        <!-- Page container -->
		<div class="page-container container">

			<!-- Sidebar -->
		    <?php $this->ci->load->view($this->ci->config->item('sidebar_view')) ?>
		    <!-- /sidebar -->

            <div class="page-content">

                <!-- Page title -->
            	<div class="page-title">
                    <h5><i class="fa fa-warning"></i><?php echo $heading; ?></h5>
                </div>
                <!-- /page title -->


                <!-- Error wrapper -->
                <div class="error-wrapper text-center">
                    <h1>404</h1>
                    <h5><?php echo $message; ?></h5>
                </div>  
                <!-- /error wrapper -->

            
            </div>

	        <!-- Footer -->
	        <?php $this->ci->load->view($this->ci->config->item('footer_view')); ?>
	        <!-- /footer -->

		</div>
		<!-- page container -->

		<!-- Scripts -->
		<?php $this->ci->load->view($this->ci->config->item('scripts_view')); ?>
		<!-- Scripts -->
    </body>
</html>
