<?php $this->ci = &get_instance(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
    	<title><?php echo $heading; ?></title>
        <!-- styles -->
        <?php $this->ci->load->view($this->ci->config->item('styles_view')); ?>
        <!-- /styles -->
    </head>

    <body>

        <!-- Page container -->
		<div class="page-container container">
		        
		    <!-- Page content -->
		    <div class="col-md-6 col-md-offset-3">

	            <div class="page-content" style="margin-left: 0px;">

	                <!-- Page title -->
	            	<div class="page-title">
	                    <h5><i class="fa fa-warning"></i><?php echo $heading; ?></h5>
	                </div>
	                <!-- /page title -->


	                <!-- Error wrapper -->
	                <div class="error-wrapper text-center">
	                    <h1>500</h1>
	                    <h5><?php echo $message; ?></h5>

	                    <!-- Error content -->
	                    <div class="error-content">
	                        <div class="row">
	                            <div class="col-md-6 col-md-offset-3">
	                            	<?php echo anchor(base_url(''), 'Back to the website', 'class="btn btn-success btn-block"'); ?>
	                            </div>
	                        </div>
	                    </div>
	                    <!-- /error content -->

	                </div>  
	                <!-- /error wrapper -->

	            
	            </div>

		        <!-- Footer -->
		        <?php $this->ci->load->view($this->ci->config->item('footer_view')); ?>
		        <!-- /footer -->

		    </div>
		    <!-- /page content -->

		</div>
		<!-- page container -->

		<!-- Scripts -->
		<?php $this->ci->load->view($this->ci->config->item('scripts_view')); ?>
		<!-- Scripts -->
    </body>
</html>
