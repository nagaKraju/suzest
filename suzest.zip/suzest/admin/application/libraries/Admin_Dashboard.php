<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Dashboard {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load dashboard config
		$this->ci->load->config('admin/dashboard');
	}


/**
 * get_continent_wise_chart_data method
 * 
 * @param integer $status
 * @return object
 */
	function get_continent_wise_chart_data($status) {

		// Load Admin_Orders Library
		$this->ci->load->library('Admin_Orders');

		$continents = $this->ci->admin_orders->get_continent_wise_chart_data($status);
		
		if(!empty($continents)) {

			$total = 0;
			foreach($continents as $continent) {

				$total += $continent->count;
			}

			foreach ($continents as $key => $continent) {
				
				if($total == 0) {

					$continent->percent = 0;
				} else {

					$continent->percent = round(($continent->count / $total) * 100, 2);
				}
			}
		}

		return $continents;
	}
}

/* End of file Admin_Dashboard.php */
/* Location: ./application/controllers/libraries/Admin_Dashboard.php */