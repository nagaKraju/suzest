<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Countries {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load countries config
		$this->ci->load->config('admin/countries');

		// Load user_logs config
		$this->ci->load->config('admin/user_logs');

		// Load country model
		$this->ci->load->model('country');

		// Load user_log model
		$this->ci->load->model('user_log');
	}

/**
 * add_country method
 * 
 * @param array $details
 * @return bool
 */
	function add_country($details) {

		if($this->ci->country->add_country($details)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('countries_table');
			$user_log['new_content'] = json_encode($details);
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * update_country method
 * 
 * @param array $details, integer $id
 * @return bool
 */
	function update_country($details, $id) {

		$user_log['old_content'] = json_encode($this->get_country_by_id($id)->row());

		if($this->ci->country->update_country($details, $id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('countries_table');	
			$user_log['new_content'] = json_encode($details);
			$user_log['operation'] = 2;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}


/**
 * check_country_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function check_country_exist_by_id($id) {
		
		return $this->ci->country->check_country_exist_by_id($id);
	}

/**
 * get_country_by_id method
 * 
 * @param integer $id
 * @return object
 */
	function get_country_by_id($id) {
		
		return $this->ci->country->get_country_by_id($id);
	}

/**
 * get_country_by_name method
 * 
 * @param string $name
 * @return object
 */
	function get_country_by_name($name) {
		
		return $this->ci->country->get_country_by_name($name);
	}

/**
 * get_country_id_by_name method
 * 
 * @param string $name
 * @return integer
 */
	function get_country_id_by_name($name) {
		
		return $this->ci->country->get_country_by_name($name)->row()->id;
	}

/**
 * get_all_countries method
 * 
 * @param integer $status
 * @return object
 */
	function get_all_countries($status = null) {
		
		return $this->ci->country->get_all_countries($status);
	}

/**
 * get_all_countries_list method
 * 
 * @param integer $status
 * @return object
 */
	function get_all_countries_list($status = null) {
		
		$countries = $this->get_all_countries($status)->result();

		$new_countries = array();

		foreach ($countries as $key => $country) {
			
			$new_countries[$country->id] = $country->name;
		}

		return $new_countries;
	}

/**
 * get_all_countries_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */
	function get_all_countries_for_pagination($limit, $offset) {
		
		return $this->ci->country->get_all_countries_for_pagination($limit, $offset);
	}

/**
 * get_no_of_countries method
 * 
 * @return object
 */
	function get_no_of_countries() {
		
		return $this->ci->country->get_no_of_countries();
	}

/**
 * get_all_countries_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
	function get_all_countries_by_search($search, $limit, $offset) {
		
		return $this->ci->country->get_all_countries_by_search($search, $limit, $offset);
	}

/**
 * get_no_of_countries_by_search method
 * 
 * @param string $search
 * @return object
 */
	function get_no_of_countries_by_search($search) {
		
		return $this->ci->country->get_no_of_countries_by_search($search);
	}

/**
 * get_all_countries_with_cities_list method
 *
 * @return object
 */
	function get_all_countries_with_cities_list() {

		$cities = $this->ci->country->get_all_countries_with_cities()->result();
		$new_cities = array();

		foreach($cities as $city) {

			if(array_key_exists($city->country_id, $new_cities)) {

				array_push($new_cities[$city->country_id]['cities'], $city);
			} else {

				$new_city['name'] = $city->country;
				$new_city['cities'] = array();
				array_push($new_city['cities'], $city);

				$new_cities[$city->country_id] = $new_city;
			}
		}

		return $new_cities;
	}

/**
 * delete_country_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function delete_country_by_id($id) {

		$user_log['old_content'] = json_encode($this->get_country_by_id($id)->row());
		
		if($this->ci->country->delete_country_by_id($id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('countries_table');
			$user_log['new_content'] = 'deleted';
			$user_log['operation'] = 3;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}

		return false;
	}

/**
 * get_all_states_by_country_id method
 * 
 * @param integer $country_id
 * @return object
 */
	function get_all_states_by_country_id($country_id) {
		
		return $this->ci->country->get_all_states_by_country_id($country_id);
	}

/**
 * get_all_states_list_by_country_id method
 * 
 * @param integer $country_id
 * @return object
 */
	function get_all_states_list_by_country_id($country_id) {
		
		$states = $this->ci->country->get_all_states_by_country_id($country_id)->result();
		$new_states = array();

		foreach($states as $state) {

			$new_states[] = $state->id;
		}

		return $new_states;
	}
}

/* End of file Admin_Countries.php */
/* Location: ./application/controllers/libraries/Admin_Countries.php */