<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_User_Logs {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load user_logs config
		$this->ci->load->config('admin/user_logs');

		// Load user_log model
		$this->ci->load->model('user_log');
	}

/**
 * add_user_log method
 * 
 * @param array $details
 * @return bool
 */
	function add_user_log($details) {
		
		return $this->ci->user_log->add_user_log($details);
	}

/**
 * get_user_log_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function get_user_log_by_id($id) {
		
		return $this->ci->user_log->get_user_log_by_id($id);
	}

/**
 * check_user_log_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function check_user_log_exist_by_id($id) {
		
		return $this->ci->user_log->check_user_log_exist_by_id($id);
	}

/**
 * get_all_user_logs_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */
	function get_all_user_logs_for_pagination($limit, $offset) {
		
		return $this->ci->user_log->get_all_user_logs_for_pagination($limit, $offset);
	}

/**
 * get_all_user_logs_by_table_for_pagination method
 * 
 * @param string $table, integer $limit, integer $offset
 * @return object
 */
	function get_all_user_logs_by_table_for_pagination($table, $limit, $offset) {
		
		return $this->ci->user_log->get_all_user_logs_by_table_for_pagination($table, $limit, $offset);
	}

/**
 * get_all_user_logs_by_user_id_for_pagination method
 * 
 * @param integer $user_id, integer $limit, integer $offset
 * @return object
 */
	function get_all_user_logs_by_user_id_for_pagination($user_id, $limit, $offset) {
		
		return $this->ci->user_log->get_all_user_logs_by_user_id_for_pagination($user_id, $limit, $offset);
	}

/**
 * get_no_of_user_logs method
 * 
 * @return object
 */
	function get_no_of_user_logs() {
		
		return $this->ci->user_log->get_no_of_user_logs();
	}

/**
 * get_no_of_user_logs_by_table method
 * 
 * @param string $table
 * @return object
 */
	function get_no_of_user_logs_by_table($table) {
		
		return $this->ci->user_log->get_no_of_user_logs_by_table($table);
	}

/**
 * get_no_of_user_logs_by_user_id method
 * 
 * @param integer $user_id
 * @return object
 */
	function get_no_of_user_logs_by_user_id($user_id) {
		
		return $this->ci->user_log->get_no_of_user_logs_by_user_id($user_id);
	}

/**
 * get_all_user_logs_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
	function get_all_user_logs_by_search($search, $limit, $offset) {
		
		return $this->ci->user_log->get_all_user_logs_by_search($search, $limit, $offset);
	}

/**
 * get_no_of_user_logs_by_search method
 * 
 * @param string $search
 * @return object
 */
	function get_no_of_user_logs_by_search($search) {
		
		return $this->ci->user_log->get_no_of_user_logs_by_search($search);
	}

/**
 * delete_user_log_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function delete_user_log_by_id($id) {
		
		return $this->ci->user_log->delete_user_log_by_id($id);
	}

}

/* End of file Admin_User_Logs.php */
/* Location: ./application/controllers/libraries/Admin_User_Logs.php */