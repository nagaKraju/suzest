<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Common {

    public $classroom_id, $virtual_id, $elearning_id, $corporate_id;

/**
 * Constructor
 *
 * @return void
 */
    function __construct() {

        $this->ci = &get_instance();

        // Set default learning types ids
        $this->classroom_id = 1;
    }

/**
 * send_mail method
 *
 * @param array $details, string $form, integer $type
 * @return void
 */
    public function send_mail($details, $form, $type) {

        $this->ci->load->library('email');
        $email = $this->ci->email;
        $email->initialize($this->ci->config->item('email'));
        $email->set_newline("\r\n");

        switch($type) {

            case 1:
                $from = $this->ci->config->item('noreply_email');
                $to = $details['email'];
                $subject = $this->ci->config->item($form.'_user_subject');
                $view = $this->ci->config->item($form.'_user_email_view');
                break;

            case 2:
                $from = $this->ci->config->item('noreply_email');
                $to = $this->ci->config->item($form.'_email');
                $subject = $this->ci->config->item($form.'_support_subject');
                $view = $this->ci->config->item($form.'_support_email_view');
                break;
        }

        $email->from($from);
        $email->to($to);
        $email->subject($subject);

        // Message
        $message = $this->ci->load->view($view, $details, true);

        $email->message($message);

        return $email->send();
    }       
}

/* End of file Admin_Common.php */
/* Location: ./application/controllers/libraries/Admin_Common.php */