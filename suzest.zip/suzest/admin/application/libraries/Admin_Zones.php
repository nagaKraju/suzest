<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Zones {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load zones config
		$this->ci->load->config('admin/zones');

		// Load user_logs config
		$this->ci->load->config('admin/user_logs');

		// Load zone model
		$this->ci->load->model('zone');

		// Load user_log model
		$this->ci->load->model('user_log');
	}

/**
 * add_zone method
 * 
 * @param array $details
 * @return bool
 */
	function add_zone($details) {

		if($this->ci->zone->add_zone($details)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('zones_table');
			$user_log['new_content'] = json_encode($details);
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * update_zone method
 * 
 * @param array $details, integer $id
 * @return bool
 */
	function update_zone($details, $id) {

		$user_log['old_content'] = json_encode($this->get_zone_by_id($id)->row());

		if($this->ci->zone->update_zone($details, $id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('zones_table');	
			$user_log['new_content'] = json_encode($details);
			$user_log['operation'] = 2;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * check_zone_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function check_zone_exist_by_id($id) {
		
		return $this->ci->zone->check_zone_exist_by_id($id);
	}

/**
 * check_zone_exist_by_country_id method
 * 
 * @param integer $zone_id, integer $country_id
 * @return bool
 */
	function check_zone_exist_by_country_id($zone_id, $country_id) {
		
		return $this->ci->zone->check_zone_exist_by_country_id($zone_id, $country_id);
	}

/**
 * get_zone_by_id method
 * 
 * @param integer $id
 * @return object
 */
	function get_zone_by_id($id) {
		
		return $this->ci->zone->get_zone_by_id($id);
	}

/**
 * get_all_zones_by_country_id method
 *
 * @param integer $country_id, integer $status
 * @return object
 */
	function get_all_zones_by_country_id($country_id, $status = null) {

		return $this->ci->zone->get_all_zones_by_country_id($country_id, $status);
	}

/**
 * get_all_zones_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */
	function get_all_zones_for_pagination($limit, $offset) {
		
		return $this->ci->zone->get_all_zones_for_pagination($limit, $offset);
	}

/**
 * get_no_of_zones method
 * 
 * @return object
 */
	function get_no_of_zones() {
		
		return $this->ci->zone->get_no_of_zones();
	}

/**
 * get_all_zones_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
	function get_all_zones_by_search($search, $limit, $offset) {
		
		return $this->ci->zone->get_all_zones_by_search($search, $limit, $offset);
	}

/**
 * get_no_of_zones_by_search method
 * 
 * @param string $search
 * @return object
 */
	function get_no_of_zones_by_search($search) {
		
		return $this->ci->zone->get_no_of_zones_by_search($search);
	}

/**
 * get_timezone_by_zone_id method
 *
 * @param integer $id
 * @return object
 */
	function get_timezone_by_zone_id($id) {

		return $this->ci->zone->get_timezone_by_zone_id($id);
	}

/**
 * delete_zone_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function delete_zone_by_id($id) {

		$user_log['old_content'] = json_encode($this->get_zone_by_id($id)->row());

		if($this->ci->zone->delete_zone_by_id($id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('zones_table');	
			$user_log['new_content'] = 'deleted';
			$user_log['operation'] = 3;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * get_all_zones method
 *
 * @param integer $status
 * @return object
 */
	function get_all_zones($status = null) {

		return $this->ci->zone->get_all_zones($status);
	}

/**
 * get_all_zones_list method
 *
 * @param integer $status
 * @return object
 */
	function get_all_zones_list($status = null) {

		$zones = $this->get_all_zones($status)->result();

		$new_zones = array();

		foreach ($zones as $key => $zone) {

			$new_zones[$zone->id] = $zone->name;
		}

		return $new_zones;
	}

}

/* End of file Admin_Zones.php */
/* Location: ./application/controllers/libraries/Admin_Zones.php */