<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Roles {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load roles config
		$this->ci->load->config('admin/roles');

		// Load user_logs config
		$this->ci->load->config('admin/user_logs');

		// Load role model
		$this->ci->load->model('dx_auth/role');

		// Load user_log model
		$this->ci->load->model('user_log');
	}

/**
 * add_role method
 * 
 * @param array $details
 * @return bool
 */
	function add_role($details) {

		// Time
		$details['created'] = $details['modified'] = date('Y-m-d H:i:s', time());
		
		if($this->ci->role->add_role($details)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('roles_table');
			$user_log['new_content'] = json_encode($details);
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}

		return false;
	}

/**
 * update_role method
 * 
 * @param array $details, integer $id
 * @return bool
 */
	function update_role($details, $id) {

		// Time
		$details['modified'] = date('Y-m-d H:i:s', time());

		$user_log['old_content'] = json_encode($this->get_role_by_id($id)->row());

		if($this->ci->role->update_role($details, $id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('roles_table');	
			$user_log['new_content'] = json_encode($details);
			$user_log['operation'] = 2;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * check_role_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function check_role_exist_by_id($id) {
		
		return $this->ci->role->check_role_exist_by_id($id);
	}

/**
 * get_role_by_id method
 * 
 * @param integer $id
 * @return object
 */
	function get_role_by_id($id) {
		
		return $this->ci->role->get_role_by_id($id);
	}

/**
 * get_all_roles method
 * 
 * @return object
 */
	function get_all_roles() {
		
		return $this->ci->role->get_all_roles();
	}

/**
 * get_roles_list method
 * 
 * @return object
 */
	function get_roles_list() {
		
		$roles = $this->get_all_roles()->result();

		$new_roles = array();

		foreach ($roles as $key => $role) {
			
			$new_roles[$role->id] = $role->name;
		}

		return $new_roles;
	}

/**
 * delete_role_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function delete_role_by_id($id) {

		$user_log['old_content'] = json_encode($this->get_role_by_id($id)->row());
		
		if($this->ci->role->delete_role_by_id($id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('roles_table');
			$user_log['new_content'] = 'deleted';
			$user_log['operation'] = 3;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}

		return false;
	}

}

/* End of file Admin_Roles.php */
/* Location: ./application/controllers/libraries/Admin_Roles.php */