<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_Districts {

/**
 * Constructor
 *
 * @return void
 */
	function __construct() {

		$this->ci = &get_instance();

		// Load districts config
		$this->ci->load->config('admin/districts');

		// Load user_logs config
		$this->ci->load->config('admin/user_logs');

		// Load district model
		$this->ci->load->model('district');

		// Load user_log model
		$this->ci->load->model('user_log');
	}

/**
 * add_district method
 * 
 * @param array $details
 * @return bool
 */
	function add_district($details) {

		if($this->ci->district->add_district($details)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('districts_table');
			$user_log['new_content'] = json_encode($details);
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * update_district method
 * 
 * @param array $details, integer $id
 * @return bool
 */
	function update_district($details, $id) {

		$user_log['old_content'] = json_encode($this->get_district_by_id($id)->row());

		if($this->ci->district->update_district($details, $id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('districts_table');	
			$user_log['new_content'] = json_encode($details);
			$user_log['operation'] = 2;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

/**
 * check_district_exist_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function check_district_exist_by_id($id) {
		
		return $this->ci->district->check_district_exist_by_id($id);
	}

/**
 * check_district_exist_by_country_id method
 * 
 * @param integer $district_id, integer $country_id
 * @return bool
 */
	function check_district_exist_by_country_id($district_id, $country_id) {
		
		return $this->ci->district->check_district_exist_by_country_id($district_id, $country_id);
	}

/**
 * get_district_by_id method
 * 
 * @param integer $id
 * @return object
 */
	function get_district_by_id($id) {
		
		return $this->ci->district->get_district_by_id($id);
	}

/**
 * get_all_districts_by_country_id method
 *
 * @param integer $country_id, integer $status
 * @return object
 */
	function get_all_districts_by_country_id($country_id, $status = null) {

		return $this->ci->district->get_all_districts_by_country_id($country_id, $status);
	}

/**
 * get_all_districts_by_countries method
 * 
 * @param array $countries, integer $status
 * @return object
 */
	function get_all_districts_by_countries($countries, $status = null) {

		$new_countries = array();
		
		if(is_array($countries)) {

			foreach($countries as $country_id) {

				$country = $this->ci->admin_countries->get_country_by_id($country_id)->row();
				
				$districts = $this->ci->district->get_all_districts_by_country_id($country_id, $status)->result();

				$new_districts = array();

				foreach($districts as $key => $district) {

					$new_districts[$district->id] = $district->name; 
				}

				$new_countries[$country->name] = $new_districts;
			}
		}
		
		return $new_countries;
	}

/**
 * get_all_districts_list_by_country_id method
 * 
 * @param integer $country_id, integer $status
 * @return object
 */
	function get_all_districts_list_by_country_id($country_id, $status = null) {

		$districts = $this->get_all_districts_by_country_id($country_id, $status)->result();

		$new_districts = array();

		foreach($districts as $district) {

			$new_districts[$district->id] = $district->name;
		}
		
		return $new_districts;
	}

/**
 * get_all_districts_for_pagination method
 * 
 * @param integer $limit, integer $offset
 * @return object
 */
	function get_all_districts_for_pagination($limit, $offset) {
		
		return $this->ci->district->get_all_districts_for_pagination($limit, $offset);
	}

/**
 * get_no_of_districts method
 * 
 * @return object
 */
	function get_no_of_districts() {
		
		return $this->ci->district->get_no_of_districts();
	}

/**
 * get_all_districts_by_search method
 * 
 * @param string $search, integer $limit, integer $offset
 * @return object
 */
	function get_all_districts_by_search($search, $limit, $offset) {
		
		return $this->ci->district->get_all_districts_by_search($search, $limit, $offset);
	}

/**
 * get_no_of_districts_by_search method
 * 
 * @param string $search
 * @return object
 */
	function get_no_of_districts_by_search($search) {
		
		return $this->ci->district->get_no_of_districts_by_search($search);
	}

/**
 * get_timezone_by_district method
 *
 * @param string $name
 * @return object
 */
	function get_timezone_by_district($name) {

		return $this->ci->district->get_timezone_by_district($name);
	}

/**
 * get_timezone_by_district_id method
 *
 * @param integer $id
 * @return object
 */
	function get_timezone_by_district_id($id) {

		return $this->ci->district->get_timezone_by_district_id($id);
	}

/**
 * delete_district_by_id method
 * 
 * @param integer $id
 * @return bool
 */
	function delete_district_by_id($id) {

		$user_log['old_content'] = json_encode($this->get_district_by_id($id)->row());

		if($this->ci->district->delete_district_by_id($id)) {

			// user log data
			$user_log['table'] = $this->ci->config->item('districts_table');	
			$user_log['new_content'] = 'deleted';
			$user_log['operation'] = 3;
			$user_log['user_id'] = $this->ci->dx_auth->get_user_id();
			$user_log['created'] = $user_log['modified'] = date('Y-m-d H:i:s', time());

			return $this->ci->user_log->add_user_log($user_log);
		}
		
		return false;
	}

}

/* End of file Admin_Districts.php */
/* Location: ./application/controllers/libraries/Admin_Districts.php */