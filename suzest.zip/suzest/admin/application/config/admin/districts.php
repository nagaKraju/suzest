<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['districts_table'] = 'districts';

    // URIs
    $config['districts_index_uri'] = 'districts';
    $config['districts_add_uri'] = 'districts/add';
    $config['districts_edit_uri'] = 'districts/edit/';
    $config['districts_ajax_change_status_uri'] = 'districts/ajax_change_status/';
    $config['districts_ajax_get_districts_by_search_uri'] = 'districts/ajax_get_districts_by_search';
    $config['districts_ajax_get_city_by_id_uri'] = 'districts/ajax_get_city_by_id';
    $config['districts_ajax_get_districts_by_country_id_uri'] = 'districts/ajax_get_districts_by_country_id';
    $config['districts_ajax_get_all_districts_by_country_id_uri'] = 'districts/ajax_get_all_districts_by_country_id';
    $config['districts_ajax_get_districts_by_countries_uri'] = 'districts/ajax_get_districts_by_countries';

    // Views
    $config['districts_index_view'] = 'districts/index';
    $config['districts_add_view'] = 'districts/add';
    $config['districts_edit_view'] = 'districts/edit';
    $config['districts_table_view'] = 'districts/table';

    // Titles
    $config['districts_header_title'] = 'Districts';
    $config['districts_index_title'] = 'Districts';
    $config['districts_add_title'] = 'Add District';
    $config['districts_edit_title'] = 'Edit District';

    //  Status
    $config['districts_status'] = array('Inactive', 'Active');