<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['cities_table'] = 'cities';

    // URIs
    $config['cities_index_uri'] = 'cities';
    $config['cities_add_uri'] = 'cities/add';
    $config['cities_edit_uri'] = 'cities/edit/';
    $config['cities_ajax_change_status_uri'] = 'cities/ajax_change_status/';
    $config['cities_ajax_get_cities_by_search_uri'] = 'cities/ajax_get_cities_by_search';
    $config['cities_ajax_get_city_by_id_uri'] = 'cities/ajax_get_city_by_id';
    $config['cities_ajax_get_cities_by_country_id_uri'] = 'cities/ajax_get_cities_by_country_id';
    $config['cities_ajax_get_all_cities_by_country_id_uri'] = 'cities/ajax_get_all_cities_by_country_id';
    $config['cities_ajax_get_cities_by_countries_uri'] = 'cities/ajax_get_cities_by_countries';

    // Views
    $config['cities_index_view'] = 'cities/index';
    $config['cities_add_view'] = 'cities/add';
    $config['cities_edit_view'] = 'cities/edit';
    $config['cities_table_view'] = 'cities/table';

    // Titles
    $config['cities_header_title'] = 'Cities';
    $config['cities_index_title'] = 'Cities';
    $config['cities_add_title'] = 'Add City';
    $config['cities_edit_title'] = 'Edit City';

    //  Status
    $config['cities_status'] = array('Inactive', 'Active');