<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['roles_table'] = 'roles';

    // URIs
    $config['roles_index_uri'] = 'roles';
    $config['roles_add_uri'] = 'roles/add';
    $config['roles_edit_uri'] = 'roles/edit/';
    $config['roles_ajax_delete_uri'] = 'roles/ajax_delete/';

    // Views
    $config['roles_index_view'] = 'roles/index';
    $config['roles_add_view'] = 'roles/add';
    $config['roles_edit_view'] = 'roles/edit';

    // Titles
    $config['roles_header_title'] = 'Roles';
    $config['roles_index_title'] = 'Roles';
    $config['roles_add_title'] = 'Add Roles';
    $config['roles_edit_title'] = 'Edit Roles';