<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['excel_uploads_table'] = 'excel_uploads';

    // File path
    $config['excel_uploads_file_path'] = 'excels/';
    $config['excel_uploads_file_allowed_types'] = 'csv|';

    // URIs
    $config['excel_uploads_index_uri'] = 'excel_uploads/';
    $config['excel_uploads_upload_sessions_uri'] = 'excel_uploads/upload_sessions';
    $config['excel_uploads_view_uri'] = 'excel_uploads/view/';
    $config['excel_uploads_ajax_delete_uri'] = 'excel_uploads/ajax_delete/';
    $config['excel_uploads_ajax_get_excel_uploads_by_search_uri'] = 'excel_uploads/ajax_get_excel_uploads_by_search/';

    $config['excel_uploads_ajax_upload_prices_uri'] = 'excel_uploads/ajax_upload_prices';
    
    // Views
    $config['excel_uploads_index_view'] = 'excel_uploads/index';
    $config['excel_uploads_upload_sessions_view'] = 'excel_uploads/upload_sessions';
    $config['excel_uploads_view_view'] = 'excel_uploads/view';
    $config['excel_uploads_table_view'] = 'excel_uploads/table';

    // Titles
    $config['excel_uploads_header_title'] = 'Excel Uploads';
    $config['excel_uploads_index_title'] = 'Excel Uploads';
    $config['excel_uploads_upload_sessions_title'] = 'Upload Sessions';
    $config['excel_uploads_view_title'] = 'View Excel Uploads';