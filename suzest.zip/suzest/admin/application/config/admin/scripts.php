<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// View 
	$config['scripts_view'] = 'scripts';

	// jquery min
	$config['js_jquery_min'] = 'assets/js/jquery.min.js';

	// jquery ui min
	$config['js_jquery_ui_min'] = 'assets/js/jquery-ui.min.js';

	// jquery bpopup min
	$config['jquery_bpopup_min'] = 'assets/js/jquery.bpopup.min.js';

	// flot
	$config['js_flot'] = 'assets/js/plugins/charts/flot.js';

	// flot orderbars
	$config['js_flot_orderbars'] = 'assets/js/plugins/charts/flot.orderbars.js';

	// flot pie
	$config['js_flot_pie'] = 'assets/js/plugins/charts/flot.pie.js';

	// flot time
	$config['js_flot_time'] = 'assets/js/plugins/charts/flot.time.js';

	// flot animator min
	$config['js_flot_animator_min'] = 'assets/js/plugins/charts/flot.animator.min.js';

	// excanvas min
	$config['js_excanvas_min'] = 'assets/js/plugins/charts/excanvas.min.js';

	// flot resize min
	$config['js_flot_resize_min'] = 'assets/js/plugins/charts/flot.resize.min.js';

	// simple graph
	$config['js_simple_graph'] = 'assets/js/charts/simple_graph.js';

	// vertical bars
	$config['js_vertical_bars'] = 'assets/js/charts/vertical_bars.js';

	// horizontal bars
	$config['js_horizontal_bars'] = 'assets/js/charts/horizontal_bars.js';

	// auto filled
	$config['js_auto_filled'] = 'assets/js/charts/auto_filled.js';

	// auto empty
	$config['js_auto_empty'] = 'assets/js/charts/auto_empty.js';

	// multiple axes
	$config['js_multiple_axes'] = 'assets/js/charts/multiple_axes.js';

	// animated 1
	$config['js_animated_1'] = 'assets/js/charts/animated_1.js';

	// animated 2
	$config['js_animated_2'] = 'assets/js/charts/animated_2.js';

	// animated 3
	$config['js_animated_3'] = 'assets/js/charts/animated_3.js';

	// donut
	$config['js_donut'] = 'assets/js/charts/donut.js';

	// pie
	$config['js_pie'] = 'assets/js/charts/pie.js';

	// pie full
	$config['js_pie_full'] = 'assets/js/charts/pie_full.js';

	// uniform min
	$config['js_uniform_min'] = 'assets/js/plugins/forms/uniform.min.js';

	// select2 min
	$config['js_select2_min'] = 'assets/js/plugins/forms/select2.min.js';

	// inputmask
	$config['js_inputmask'] = 'assets/js/plugins/forms/inputmask.js';

	// autosize
	$config['js_autosize'] = 'assets/js/plugins/forms/autosize.js';

	// inputlimit min
	$config['js_inputlimit_min'] = 'assets/js/plugins/forms/inputlimit.min.js';

	// listbox
	$config['js_listbox'] = 'assets/js/plugins/forms/listbox.js';

	// multiselect
	$config['js_multiselect'] = 'assets/js/plugins/forms/multiselect.js';

	// validate min
	$config['js_validate_min'] = 'assets/js/plugins/forms/validate.min.js';

	// tags min
	$config['js_tags_min'] = 'assets/js/plugins/forms/tags.min.js';

	// plupload full min
	$config['js_plupload_full_min'] = 'assets/js/plugins/forms/uploader/plupload.full.min.js';

	// plupload queue min
	$config['js_plupload_queue_min'] = 'assets/js/plugins/forms/uploader/plupload.queue.min.js';

	// wysihtml5 min
	$config['js_wysihtml5_min'] = 'assets/js/plugins/forms/wysihtml5/wysihtml5.min.js';

	// toolbar
	$config['js_toolbar'] = 'assets/js/plugins/forms/wysihtml5/toolbar.js';

	// jgrowl min
	$config['js_jgrowl_min'] = 'assets/js/plugins/interface/jgrowl.min.js';

	// datatables min
	$config['js_datatables_min'] = 'assets/js/plugins/interface/datatables.min.js';

	// prettify
	$config['js_prettify'] = 'assets/js/plugins/interface/prettify.js';

	// fancybox min
	$config['js_fancybox_min'] = 'assets/js/plugins/interface/fancybox.min.js';

	// colorpicker
	$config['js_colorpicker'] = 'assets/js/plugins/interface/colorpicker.js';

	// timepicker min
	$config['js_timepicker_min'] = 'assets/js/plugins/interface/timepicker.min.js';

	// timepicker min
	$config['js_moment'] = 'assets/js/moment.min.js';

	// bootstrap-datetimepicker
	$config['js_bootstrap_datetimepicker'] = 'assets/js/daterangepicker.js';

	// fullcalendar min
	$config['js_fullcalendar_min'] = 'assets/js/plugins/interface/fullcalendar.min.js';

	// collapsible min
	$config['js_collapsible_min'] = 'assets/js/plugins/interface/collapsible.min.js';

	// bootstrap min
	$config['js_bootstrap_min'] = 'assets/js/bootstrap.min.js';

	// application
	$config['js_application'] = 'assets/js/application.js';

	// search
	$config['js_search'] = 'assets/js/search.js';

	// Autotab
	$config['js_autotab'] = 'assets/js/plugins/forms/autotab.js';

	// Jquery validationEngine-en
	$config['js_jquery_validationEngine_en'] = 'assets/js/plugins/forms/jquery.validationEngine-en.js';

	// Jquery validationEngine
	$config['js_jquery_validationEngine'] = 'assets/js/plugins/forms/jquery.validationEngine.js';

	// Jquery dualListBox
	$config['js_jquery_dualListBox'] = 'assets/js/plugins/forms/jquery.dualListBox.js';

	// Chosen jquery min
	$config['js_chosen_jquery_min'] = 'assets/js/plugins/forms/chosen.jquery.min.js';

	// Jquery maskedinput min
	$config['js_jquery_maskedinput_min'] = 'assets/js/plugins/forms/jquery.maskedinput.min.js';

	// Jquery inputlimiter min
	$config['js_jquery_inputlimiter_min'] = 'assets/js/plugins/forms/jquery.inputlimiter.min.js';

	// Jquery tagsinput min
	$config['js_jquery_tagsinput_min'] = 'assets/js/plugins/forms/jquery.tagsinput.min.js';

	// Calendar min
	$config['js_calendar_min'] = 'assets/js/plugins/other/calendar.min.js';

	// Elfinder min
	$config['js_elfinder_min'] = 'assets/js/plugins/other/elfinder.min.js';

	// plupload
	$config['js_plupload'] = 'assets/js/plugins/uploader/plupload.js';

	// plupload html5
	$config['js_plupload_html5'] = 'assets/js/plugins/uploader/plupload.html5.js';

	// plupload html4
	$config['js_plupload_html4'] = 'assets/js/plugins/uploader/plupload.html4.js';

	// Jquery plupload queue
	$config['js_jquery_plupload_queue'] = 'assets/js/plugins/uploader/jquery.plupload.queue.js';

	// Jquery progress
	$config['js_jquery_progress'] = 'assets/js/plugins/ui/jquery.progress.js';

	// Jquery jgrowl
	$config['js_jquery_jgrowl'] = 'assets/js/plugins/ui/jquery.jgrowl.js';

	// Jquery tipsy
	$config['js_jquery_tipsy'] = 'assets/js/plugins/ui/jquery.tipsy.js';

	// Jquery alerts
	$config['js_jquery_alerts'] = 'assets/js/plugins/ui/jquery.alerts.js';

	// Jquery colorpicker
	$config['js_jquery_colorpicker'] = 'assets/js/plugins/ui/jquery.colorpicker.js';

	// Jquery form wizard
	$config['js_jquery_form_wizard'] = 'assets/js/plugins/wizards/jquery.form.wizard.js';

	// Jquery validate
	$config['js_jquery_validate'] = 'assets/js/plugins/wizards/jquery.validate.js';

	// Jquery breadcrumbs
	$config['js_jquery_breadcrumbs'] = 'assets/js/plugins/ui/jquery.breadcrumbs.js';

	// Jquery collapsible min
	$config['js_jquery_collapsible_min'] = 'assets/js/plugins/ui/jquery.collapsible.min.js';

	// Jquery ToTop
	$config['js_jquery_ToTop'] = 'assets/js/plugins/ui/jquery.ToTop.js';

	// Jquery listnav
	$config['js_jquery_listnav'] = 'assets/js/plugins/ui/jquery.listnav.js';

	// Jquery sourcerer
	$config['js_jquery_sourcerer'] = 'assets/js/plugins/ui/jquery.sourcerer.js';

	// Jquery timeentry min
	$config['js_jquery_timeentry_min'] = 'assets/js/plugins/ui/jquery.timeentry.min.js';

	// Jquery prettyPhoto
	$config['js_jquery_prettyPhoto'] = 'assets/js/plugins/ui/jquery.prettyPhoto.js';

	// Custom
	$config['js_custom'] = 'assets/js/custom.js';

	// tinymce
	$config['js_tinymce_min'] = 'assets/js/tinymce/tinymce.min.js';