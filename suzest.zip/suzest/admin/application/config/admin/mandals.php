<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['mandals_table'] = 'mandals';

    // URIs
    $config['mandals_index_uri'] = 'mandals';
    $config['mandals_add_uri'] = 'mandals/add';
    $config['mandals_edit_uri'] = 'mandals/edit/';
    $config['mandals_ajax_change_status_uri'] = 'mandals/ajax_change_status/';
    $config['mandals_ajax_get_mandals_by_search_uri'] = 'mandals/ajax_get_mandals_by_search';
    $config['mandals_ajax_get_city_by_id_uri'] = 'mandals/ajax_get_city_by_id';
    $config['mandals_ajax_get_mandals_by_country_id_uri'] = 'mandals/ajax_get_mandals_by_country_id';
    $config['mandals_ajax_get_all_mandals_by_country_id_uri'] = 'mandals/ajax_get_all_mandals_by_country_id';
    $config['mandals_ajax_get_mandals_by_countries_uri'] = 'mandals/ajax_get_mandals_by_countries';

    // Views
    $config['mandals_index_view'] = 'mandals/index';
    $config['mandals_add_view'] = 'mandals/add';
    $config['mandals_edit_view'] = 'mandals/edit';
    $config['mandals_table_view'] = 'mandals/table';

    // Titles
    $config['mandals_header_title'] = 'Mandals';
    $config['mandals_index_title'] = 'Mandals';
    $config['mandals_add_title'] = 'Add Mandal';
    $config['mandals_edit_title'] = 'Edit Mandal';

    //  Status
    $config['mandals_status'] = array('Inactive', 'Active');