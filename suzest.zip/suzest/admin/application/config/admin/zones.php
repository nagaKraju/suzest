<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['zones_table'] = 'zones';

    // URIs
    $config['zones_index_uri'] = 'zones';
    $config['zones_add_uri'] = 'zones/add';
    $config['zones_edit_uri'] = 'zones/edit/';
    $config['zones_ajax_change_status_uri'] = 'zones/ajax_change_status/';
    $config['zones_ajax_get_zones_by_search_uri'] = 'zones/ajax_get_zones_by_search';
    $config['zones_ajax_get_city_by_id_uri'] = 'zones/ajax_get_city_by_id';
    $config['zones_ajax_get_zones_by_country_id_uri'] = 'zones/ajax_get_zones_by_country_id';
    $config['zones_ajax_get_all_zones_by_country_id_uri'] = 'zones/ajax_get_all_zones_by_country_id';
    $config['zones_ajax_get_zones_by_countries_uri'] = 'zones/ajax_get_zones_by_countries';

    // Views
    $config['zones_index_view'] = 'zones/index';
    $config['zones_add_view'] = 'zones/add';
    $config['zones_edit_view'] = 'zones/edit';
    $config['zones_table_view'] = 'zones/table';

    // Titles
    $config['zones_header_title'] = 'Zones';
    $config['zones_index_title'] = 'Zones';
    $config['zones_add_title'] = 'Add Zone';
    $config['zones_edit_title'] = 'Edit Zone';

    //  Status
    $config['zones_status'] = array('Inactive', 'Active');