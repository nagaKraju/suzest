<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['countries_table'] = 'countries';

    // URIs
    $config['countries_index_uri'] = 'countries';
    $config['countries_add_uri'] = 'countries/add';
    $config['countries_edit_uri'] = 'countries/edit/';
    $config['countries_view_uri'] = 'countries/view/';
    $config['countries_ajax_get_country_by_id_uri'] = 'countries/ajax_get_country_by_id';
    $config['countries_ajax_get_countries_by_search_uri'] = 'countries/ajax_get_countries_by_search';
    $config['countries_ajax_get_all_countries_with_cities_uri'] = 'countries/ajax_get_all_countries_with_cities';
    $config['countries_ajax_get_states_by_country_id_uri'] = 'countries/ajax_get_states_by_country_id/';

    // Views
    $config['countries_index_view'] = 'countries/index';
    $config['countries_add_view'] = 'countries/add';
    $config['countries_edit_view'] = 'countries/edit';
    $config['countries_view_view'] = 'countries/view';
    $config['countries_table_view'] = 'countries/table';

    // Titles
    $config['countries_header_title'] = 'Countries';
    $config['countries_index_title'] = 'Countries';
    $config['countries_add_title'] = 'Add Country';
    $config['countries_edit_title'] = 'Edit Country';
    $config['countries_view_title'] = 'View Country';

    //  Status
    $config['countries_status'] = array('Inactive', 'Active');