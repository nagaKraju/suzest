<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Template
	$config['template_view'] = 'template';

	// Navbar
	$config['navbar_view'] = 'navbar';

	// Page Header
	$config['page_header_view'] = 'page_header';

	// SideBar
	$config['sidebar_view'] = 'sidebar';

	// Footer
	$config['footer_view'] = 'footer';

	// Success
	$config['success_view'] = 'success';

	// Failure
	$config['failure_view'] = 'failure';

	// Image
	$config['images_path'] = 'assets/images/';

	// Assets
	$config['assets_path'] = 'assets/';

	// Pagination View
	$config['pagination_view'] = 'pagination';

	// Countries
	$config['countries_index_uri'] = 'countries';

	// States
	$config['states_index_uri'] = 'states';

	// Districts
	$config['districts_index_uri'] = 'districts';

	// Mandals
	$config['mandals_index_uri'] = 'mandals';

	// Zones
	$config['zones_index_uri'] = 'zones';

	// Cities
	$config['cities_index_uri'] = 'cities';

	// User Logs
	$config['user_logs_index_uri'] = 'user_logs/';

	// Roles
	$config['roles_index_uri'] = 'roles';

	// User Logs
	$config['user_logs_index_uri'] = 'user_logs';

	// Tables
	$config['admin_tables'] = array(
		'countries',
		'states',
		'admin_users',
		'roles',
	);

	// Website Logo
	$config['website_logo'] = 'logo.jpg';