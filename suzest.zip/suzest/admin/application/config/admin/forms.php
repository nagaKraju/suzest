<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
	$config['quick_enquiries_table'] = 'quick_enquiries';
	$config['become_instructors_table'] = 'become_instructors';
	$config['request_inhouse_trainings_table'] = 'request_inhouse_trainings';
	$config['request_for_quotes_table'] = 'request_for_quotes';
	$config['request_callbacks_table'] = 'request_callbacks';
	$config['contact_us_table'] = 'contact_us';
	$config['subscriptions_table'] = 'subscriptions';

	// CVs
	$config['cvs_path'] = 'assets/cv/';
	$config['become_instructor_cvs_path'] = 'instructors/';

	// Quick Enquiry
	$config['forms_quick_enquiries_uri'] = 'forms/quick_enquiries';
	$config['forms_download_quick_enquiries_uri'] = 'forms/download_quick_enquiries';
	$config['forms_quick_enquiries_view'] = 'forms/quick_enquiries';
	$config['forms_quick_enquiries_table_view'] = 'forms/quick_enquiries_table';
	$config['forms_ajax_get_quick_enquiry_by_id_uri'] = 'forms/ajax_get_quick_enquiry_by_id';
	$config['forms_ajax_get_quick_enquiries_by_search_uri'] = 'forms/ajax_get_quick_enquiries_by_search/';

	// Become Instructors
	$config['forms_become_instructors_uri'] = 'forms/become_instructors';
	$config['forms_download_become_instructors_uri'] = 'forms/download_become_instructors';
	$config['forms_become_instructors_view'] = 'forms/become_instructors';
	$config['forms_become_instructors_table_view'] = 'forms/become_instructors_table';
	$config['forms_ajax_get_become_instructor_by_id_uri'] = 'forms/ajax_get_become_instructor_by_id';
	$config['forms_ajax_get_become_instructors_by_search_uri'] = 'forms/ajax_get_become_instructors_by_search/';

	// Inhouse Trainings
	$config['forms_inhouse_trainings_uri'] = 'forms/inhouse_trainings';
	$config['forms_download_inhouse_trainings_uri'] = 'forms/download_inhouse_trainings';
	$config['forms_inhouse_trainings_view'] = 'forms/inhouse_trainings';
	$config['forms_inhouse_trainings_table_view'] = 'forms/inhouse_trainings_table';
	$config['forms_ajax_get_inhouse_training_by_id_uri'] = 'forms/ajax_get_inhouse_training_by_id';
	$config['forms_ajax_get_inhouse_trainings_by_search_uri'] = 'forms/ajax_get_inhouse_trainings_by_search/';

	// Inhouse Trainings
	$config['forms_request_for_quotes_uri'] = 'forms/request_for_quotes';
	$config['forms_download_request_for_quotes_uri'] = 'forms/download_request_for_quotes';
	$config['forms_request_for_quotes_view'] = 'forms/request_for_quotes';
	$config['forms_request_for_quotes_table_view'] = 'forms/request_for_quotes_table';
	$config['forms_ajax_get_request_for_quote_by_id_uri'] = 'forms/ajax_get_request_for_quote_by_id';
	$config['forms_ajax_get_request_for_quotes_by_search_uri'] = 'forms/ajax_get_request_for_quotes_by_search/';

	// Request Callbacks
	$config['forms_request_callbacks_uri'] = 'forms/request_callbacks';
	$config['forms_download_request_callbacks_uri'] = 'forms/download_request_callbacks';
	$config['forms_request_callbacks_view'] = 'forms/request_callbacks';
	$config['forms_request_callbacks_table_view'] = 'forms/request_callbacks_table';
	$config['forms_ajax_get_request_callback_by_id_uri'] = 'forms/ajax_get_request_callback_by_id';
	$config['forms_ajax_get_request_callbacks_by_search_uri'] = 'forms/ajax_get_request_callbacks_by_search/';

	// Contact Us
	$config['forms_contact_us_uri'] = 'forms/contact_us';
	$config['forms_download_contact_us_uri'] = 'forms/download_contact_us';
	$config['forms_contact_us_view'] = 'forms/contact_us';
	$config['forms_contact_us_table_view'] = 'forms/contact_us_table';
	$config['forms_ajax_get_contact_us_by_id_uri'] = 'forms/ajax_get_contact_us_by_id';
	$config['forms_ajax_get_contact_us_by_search_uri'] = 'forms/ajax_get_contact_us_by_search/';
	$config['forms_ajax_get_contact_us_by_dates_uri'] = 'forms/ajax_get_contact_us_by_dates/';

	// Subscriptions
	$config['forms_subscriptions_uri'] = 'forms/subscriptions';
	$config['forms_download_subscriptions_uri'] = 'forms/download_subscriptions';
	$config['forms_subscriptions_view'] = 'forms/subscriptions';
	$config['forms_subscriptions_table_view'] = 'forms/subscriptions_table';
	$config['forms_ajax_get_subscriptions_by_search_uri'] = 'forms/ajax_get_subscriptions_by_search/';

	// Titles
    $config['forms_header_title'] = 'Forms';
    $config['forms_quick_enquiries_title'] = 'Quick Enquiries';
    $config['forms_become_instructors_title'] = 'Become Instructors';
    $config['forms_inhouse_trainings_title'] = 'Inhouse Trainings';
    $config['forms_request_for_quotes_title'] = 'Request for a Quotes';
    $config['forms_request_callbacks_title'] = 'Request Callbacks';
    $config['forms_contact_us_title'] = 'Contact Us';
    $config['forms_subscriptions_title'] = 'Subscriptions';
