<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// View 
	$config['styles_view'] = 'styles';

	// bootstrap min
	$config['css_bootstrap_min']	= 'assets/css/bootstrap.min.css';

	// brain theme
	$config['css_brain_theme']	= 'assets/css/brain-theme.css';
        
    // wysiwyg-color
	$config['css_wysiwyg_color']	= 'assets/css/wysihtml5/wysiwyg-color.css';

	// styles
	$config['css_styles']	= 'assets/css/styles.css';

	// font-awesome min
	$config['css_font_awesome_min']	= 'assets/css/font-awesome.min.css';

	// cuprum fonts css
	$config['css_font_cuprum'] = 'assets/css/font-cuprum.css';

	// cuprum fonts css
	$config['css_daterangepicker_bs3'] = 'assets/css/daterangepicker-bs3.css';
