<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    // URIs
    $config['dashboard_index_uri'] = 'dashboard';
    
    // Views
    $config['dashboard_index_view'] = 'dashboard/index';

    // Titles
    $config['dashboard_header_title'] = 'Dashboard';
    $config['dashboard_index_title'] = 'Dashboard';
    $config['dashboard_orders_title'] = '1 . Quick links';
    $config['dashboard_forms_title'] = '2 . Recently updated courses';