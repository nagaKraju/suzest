<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['user_logs_table'] = 'user_logs';

    // URIs
    $config['user_logs_index_uri'] = 'user_logs/';
    $config['user_logs_view_uri'] = 'user_logs/view/';
    $config['user_logs_filter_uri'] = 'user_logs/filter/';
    $config['user_logs_ajax_get_user_logs_by_search_uri'] = 'user_logs/ajax_get_user_logs_by_search/';

    // Views
    $config['user_logs_index_view'] = 'user_logs/index';
    $config['user_logs_view_view'] = 'user_logs/view';
    $config['user_logs_filter_view'] = 'user_logs/filter';

    // Titles
    $config['user_logs_header_title'] = 'User Logs';
    $config['user_logs_index_title'] = 'User Logs';
    $config['user_logs_view_title'] = 'View User Log';
    $config['user_logs_filter_title'] = 'View Filter';