<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| DX Auth Config
| -------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Website details
|--------------------------------------------------------------------------
|
| These details are used in email sent by DX Auth library.
|
*/

	$config['DX_website_name'] = 'KH-Landing-Page' ;
	$config['DX_webmaster_email'] = 'support@techpeoplz.com';

/*
|--------------------------------------------------------------------------
| Database table
|--------------------------------------------------------------------------
|
| Determines table that used by DX Auth.
|
| 'DX_table_prefix' allows you to specify table prefix that will be use by the rest of the table. 
|
| For example specifying 'DX_' in 'DX_table_prefix' and 'users' in 'DX_users_table',
| will make DX Auth user 'DX_users' as users table.
|
*/

	$config['DX_table_prefix'] = 'admin_';
	$config['DX_users_table'] = 'users';
	$config['DX_user_profile_table'] = 'user_profile';
	$config['DX_user_temp_table'] = 'user_temp';
	$config['DX_user_autologin'] = 'user_autologin';
	$config['DX_roles_table'] = 'roles';
	$config['DX_permissions_table'] = 'permissions';
	$config['DX_login_attempts_table'] = 'login_attempts';

/*
|--------------------------------------------------------------------------
| Password salt
|--------------------------------------------------------------------------
|
| You can add major salt to be hashed with password. 
| For example, you can get salt from here: https://www.grc.com/passwords.htm
|
| Note: 
|
| Keep in mind that if you change the salt value after user registered, 
| user that previously registered cannot login anymore.
|
*/

	$config['DX_salt'] = '';

/*
|--------------------------------------------------------------------------
| Registration related settings
|--------------------------------------------------------------------------
|
| 'DX_email_activation' = Requires user to activate their account using email after registration.
| 'DX_email_activation_expire' = Time before users who don't activate their account getting deleted from database. Default is 48 Hours (60*60*24*2).
| 'DX_email_account_details' =  Email account details after registration, only if 'DX_email_activation' is FALSE.
|
*/
 
	$config['DX_email_activation'] = FALSE; 
	$config['DX_email_activation_expire'] = 60*60*24*2; 
	$config['DX_email_account_details'] = TRUE; 

/*
|--------------------------------------------------------------------------
| Login settings
|--------------------------------------------------------------------------
|
| 'DX_login_using_username' = Determine if user can use username in username field to login.
| 'DX_login_using_email' = Determine if user can use email in username field to login.
|
| You have to set at least one of settings above to TRUE. 
|
| 'DX_login_record_ip' = Determine if user IP address should be recorded in database when user login.
| 'DX_login_record_time' = Determine if time should be recorded in database when user login.
|
*/

	$config['DX_login_using_username'] = FALSE;
	$config['DX_login_using_email'] = TRUE;
	$config['DX_login_record_ip'] = TRUE;
	$config['DX_login_record_time'] = TRUE;

/*
|--------------------------------------------------------------------------
| Auto login settings
|--------------------------------------------------------------------------
|
| 'DX_autologin_cookie_name' = Determine auto login cookie name.
| 'DX_autologin_cookie_life' = Determine auto login cookie life before expired. Default is 2 months (60*60*24*31*2).
|
*/

	$config['DX_autologin_cookie_name'] = 'autologin';
	$config['DX_autologin_cookie_life'] = 60*60*24*31*2;

/*
|--------------------------------------------------------------------------
| Login attempts
|--------------------------------------------------------------------------
|
| 'DX_count_login_attempts' = Determine if DX Auth should count login attempt when user failed to login.
| 'DX_max_login_attempts' =  Determine max login attempt before function is_login_attempt_exceeded() returning TRUE.
|
*/

	$config['DX_count_login_attempts'] = FALSE;
	$config['DX_max_login_attempts'] = 3; 

/*
|--------------------------------------------------------------------------
| Forgot password settings
|--------------------------------------------------------------------------
|
| 'DX_forgot_password_expire' = Time before forgot password key become invalid. Default is 15 minutes (900 seconds).
|
*/

	$config['DX_forgot_password_expire'] = 900;


/*
|--------------------------------------------------------------------------
| reCAPTCHA
|--------------------------------------------------------------------------
|
| If you are planning to use reCAPTCHA function, you have to set reCAPTCHA key here
| You can get the key by registering at http://recaptcha.net
|
*/

	$config['DX_recaptcha_public_key'] = '6LcNO9ISAAAAAHcRoGVQp1ZG56RDNdnwH3MyuBqU'; 
	$config['DX_recaptcha_private_key'] = '6LcNO9ISAAAAAIMeF9o2YIlAovWwvi2T-qArp0DE';


/*
|--------------------------------------------------------------------------
| URI
|--------------------------------------------------------------------------
|
| Determines URI that used for redirecting in DX Auth library.
| 'DX_deny_uri' = Forbidden access URI.
| 'DX_login_uri' = Login form URI.
| 'DX_activate_uri' = Activate user URI.
| 'DX_reset_password_uri' = Reset user password URI.
|
| These value can be accessed from DX Auth library variable, by removing 'DX_' string.
| For example you can access 'DX_deny_uri' by using $this->dx_auth->deny_uri in controller.
|
*/

	// Images
	$config['auth_images_path'] = 'users/';

	$config['auth_deny_uri'] = 'auth/deny/';
	$config['auth_login_uri'] = 'auth/login/';
	$config['auth_banned_uri'] = 'auth/banned/';
	$config['auth_activate_uri'] = 'auth/activate/';
	$config['auth_reset_password_uri'] = 'auth/reset_password/';

	$config['auth_users_uri'] = 'auth/users/';
	$config['auth_profile_uri'] = 'auth/profile/';
	$config['auth_edit_uri'] = 'auth/edit/';
	$config['auth_ajax_delete_uri'] = 'auth/ajax_delete/';
	$config['auth_ajax_get_users_by_search_uri'] = 'auth/ajax_get_users_by_search';
	$config['auth_permissions_uri'] = 'auth/permissions/';


/*
|--------------------------------------------------------------------------
| Helper configuration
|--------------------------------------------------------------------------
|
| Configuration below is actually not used in function in DX_Auth library.
|	They just used to help you coding more easily in controller.
|	You can set it to blank if you don't need it, or even delete it.
|
| However they can be accessed from DX Auth library variable, by removing 'DX_' string.
| For example you can access 'DX_register_uri' by using $this->dx_auth->register_uri in controller.
|
*/

/*
|--------------------------------------------------------------------------
| Registration
|--------------------------------------------------------------------------
|
*/
	$config['DX_allow_registration'] = TRUE; 
	$config['DX_captcha_registration'] = FALSE;

/*
|--------------------------------------------------------------------------
| Login
|--------------------------------------------------------------------------
|
*/

	$config['DX_captcha_login'] = FALSE;

/*
|--------------------------------------------------------------------------
| URI Locations
|--------------------------------------------------------------------------
|
*/
	$config['auth_logout_uri'] = 'auth/logout/';
	$config['auth_register_uri'] = 'auth/register/';
	$config['auth_forgot_password_uri'] = 'auth/forgot_password/';
	$config['auth_change_password_uri'] = 'auth/change_password/';
	$config['cancel_account_uri'] = 'auth/cancel_account/';

/*
|--------------------------------------------------------------------------
| Forms view
|--------------------------------------------------------------------------
|
*/
	$config['login_template_view'] = 'login';
	$config['auth_login_view'] = 'auth/login';
	$config['auth_register_view'] = 'auth/register';
	$config['auth_forgot_password_view'] = 'auth/forgot_password';
	$config['auth_change_password_view'] = 'auth/change_password';
	$config['cancel_account_view'] = 'auth/cancel_account';

	$config['auth_reset_password_view'] = 'auth/general_message';

	$config['auth_users_view'] = 'auth/users';
	$config['auth_table_view'] = 'auth/table';
	$config['auth_profile_view'] = 'auth/profile';
	$config['auth_edit_view'] = 'auth/edit';
	$config['auth_permissions_view'] = 'auth/permissions';

/*
|--------------------------------------------------------------------------
| Pages view
|--------------------------------------------------------------------------
|
*/
	$config['auth_deny_view'] = 'auth/general_message';
	$config['auth_banned_view'] = 'auth/general_message';
	$config['auth_general_message_view'] = 'auth/general_message';

/*
|--------------------------------------------------------------------------
| Titles
|--------------------------------------------------------------------------
|
*/
	$config['auth_header_title'] = 'Auth';
    $config['auth_login_title'] = 'Login';
    $config['auth_register_title'] = 'Register';
    $config['auth_forgot_password_title'] = 'Forgot Password';
    $config['auth_change_password_title'] = 'Change Password';

    $config['auth_reset_password_title'] = 'Reset Password';
    $config['auth_deny_title'] = '401 Access Denied';

    $config['auth_users_title'] = 'Users';
    $config['auth_regiser_title'] = 'Register';
    $config['auth_profile_title'] = 'Profile';
    $config['auth_edit_title'] = 'Edit';
    $config['auth_permissions_title'] = 'Permissions';