<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	// Table
    $config['states_table'] = 'states';

    // URIs
    $config['states_index_uri'] = 'states';
    $config['states_add_uri'] = 'states/add';
    $config['states_edit_uri'] = 'states/edit/';
    $config['states_ajax_change_status_uri'] = 'states/ajax_change_status/';
    $config['states_ajax_get_states_by_search_uri'] = 'states/ajax_get_states_by_search';
    $config['states_ajax_get_city_by_id_uri'] = 'states/ajax_get_city_by_id';
    $config['states_ajax_get_states_by_country_id_uri'] = 'states/ajax_get_states_by_country_id';
    $config['states_ajax_get_all_states_by_country_id_uri'] = 'states/ajax_get_all_states_by_country_id';
    $config['states_ajax_get_states_by_countries_uri'] = 'states/ajax_get_states_by_countries';
    $config['states_ajax_get_districts_by_state_id_uri'] = 'states/ajax_get_districts_by_state_id/';

    // Views
    $config['states_index_view'] = 'states/index';
    $config['states_add_view'] = 'states/add';
    $config['states_edit_view'] = 'states/edit';
    $config['states_table_view'] = 'states/table';

    // Titles
    $config['states_header_title'] = 'States';
    $config['states_index_title'] = 'States';
    $config['states_add_title'] = 'Add State';
    $config['states_edit_title'] = 'Edit State';

    //  Status
    $config['states_status'] = array('Inactive', 'Active');