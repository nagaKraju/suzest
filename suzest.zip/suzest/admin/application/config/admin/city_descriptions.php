<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    // Table
    $config['city_descriptions_table'] = 'city_descriptions';

    // URIs
    $config['city_descriptions_index_uri'] = 'city_descriptions';
    $config['city_descriptions_add_uri'] = 'city_descriptions/add';
    $config['city_descriptions_edit_uri'] = 'city_descriptions/edit/';
    $config['city_descriptions_ajax_change_status_uri'] = 'city_descriptions/ajax_change_status/';
    $config['city_descriptions_ajax_get_city_descriptions_by_search_uri'] = 'city_descriptions/ajax_get_city_descriptions_by_search';

    // Views
    $config['city_descriptions_index_view'] = 'city_descriptions/index';
    $config['city_descriptions_table_view'] = 'city_descriptions/table';
    $config['city_descriptions_edit_view'] = 'city_descriptions/edit';

    // Titles
    $config['city_descriptions_header_title'] = 'City Descriptions';
    $config['city_descriptions_index_title'] = 'City Descriptions';
    $config['city_descriptions_edit_title'] = 'Edit City Description';
    
    //  Status
    $config['city_descriptions_status'] = array('Inactive', 'Active');