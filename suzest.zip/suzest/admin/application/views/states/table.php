<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Code</th>
            <th>Country</th>
            <th>Slug</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <?php if(!empty($states)): ?>
        <tbody>
            <?php $i = (($offset - 1) * $limit) + 1; ?>
            <?php foreach($states as $state): ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $state->name; ?></td>
                    <td><?php echo $state->code; ?></td>
                    <td><?php echo $state->country; ?></td>
                    <td><?php echo $state->slug; ?></td>
                    <td><span class="label <?php echo ($state->status == 1) ? 'label-success' : 'label-danger'; ?>"><?php echo $this->config->item('states_status')[$state->status]; ?></span></td>
                    <td><?php echo anchor(base_url($this->config->item('states_edit_uri').$state->id), 'Edit', 'class="btn btn-info"'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php endif; ?>
</table>