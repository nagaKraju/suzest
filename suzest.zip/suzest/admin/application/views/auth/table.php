<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <?php if(!empty($users)): ?>
        <tbody>
            <?php $i = (($offset - 1) * $limit) + 1; ?>
            <?php foreach($users as $user): ?>

                <?php if($user->id != $this->dx_auth->get_user_id()): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $user->username; ?></td>
                        <td><?php echo $user->email; ?></td>
                        <td><?php echo $user->role; ?></td>
                        <td>
                            <?php
                                echo anchor(base_url($this->config->item('auth_edit_uri').$user->id), 'Edit', 'class="btn btn-info"');  
                                echo ' ';   
                                echo anchor(base_url($this->config->item('auth_ajax_delete_uri').$user->id), 'Delete', 'class="btn btn-danger delete"');
                            ?>
                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        </tbody>
    <?php endif; ?>
</table>