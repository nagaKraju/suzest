<!-- Page container -->
<div class="page-container container">
        
    <!-- Page content -->
    <div class="col-md-6 col-md-offset-3">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <?php if(isset($auth_error) && !empty($auth_error)): ?>
            <div role="alert" class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo $auth_error; ?>
            </div>
        <?php endif; ?>

        <?php if(isset($auth_message) && !empty($auth_message)): ?>
            <div role="alert" class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo $auth_message; ?>
            </div>
        <?php endif; ?>

        <div class="panel panel-default">
            <div class="panel-heading">
                <h6 class="panel-title"><?php echo $this->config->item($this->router->fetch_class().'_'.$this->router->fetch_method().'_title'); ?></h6>
            </div>

            <div class="panel-body">
                <?php echo anchor(base_url($this->config->item('auth_login_uri')), 'Login'); ?>
            </div>
        </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->