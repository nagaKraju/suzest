<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('auth_users_title'); ?></h6>
                    <?php echo anchor(base_url($this->config->item('auth_register_uri')), 'Register', 'class="btn btn-success pull-right"'); ?>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-sm-12 has-feedback">
                            <?php echo form_input(array('name' => 'search', 'class' => 'form-control', 'placeholder' => 'Search here')); ?>
                            <i class="fa fa-search form-control-feedback"></i>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <?php $this->load->view($this->config->item('auth_table_view')); ?>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php $this->load->view($this->config->item('pagination_view')); ?>
        <!-- /Pagination -->

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->

<script type="text/javascript">

    var timer;
    
    $('input[name="search"]').on('keyup',function() {

        var search = $(this).val();

        clearTimeout(timer);

        timer = setTimeout(function() {

            if(search.length > 2) {

                get_users_list(search, "<?php echo base_url($this->config->item('auth_ajax_get_users_by_search_uri')); ?>"); 
            } else {

                get_users_list('', "<?php echo base_url($this->config->item('auth_ajax_get_users_by_search_uri')); ?>"); 
            }

        }, 800);
    });

    // Get users list
    function get_users_list(search, link) {

        $.ajax({
            type: "POST",
            url: link,
            async: false,
            dataType: 'json',
            data: {"search": search},
            processdata: true,
            success: function (data) {

                // Clear table data
                $('table tbody').empty();

                // Clear pagination
                $('.pagination').empty();

                if(data.response == true) {
                    
                    if(data.users != 'undefined') {
                        
                        var tbody = '';

                        var i = (data.offset * data.limit) + 1;
                        $.each(data.users, function(key, user) {

                            tbody += '<tr>';
                            tbody += '<td>'+(i++)+'</td>';
                            tbody += '<td>'+user.username+'</td>';
                            tbody += '<td>'+user.email+'</td>';
                            tbody += '<td>'+user.role+'</td>';
                            tbody += '<td><a href="<?php echo base_url($this->config->item('auth_edit_uri')); ?>/'+user.id+'" class="btn btn-info">Edit</a>&nbsp;<a href="<?php echo base_url($this->config->item('auth_ajax_delete_uri')); ?>/'+user.id+'" class="btn btn-danger delete">Delete</a></td>';
                            tbody += '</tr>';
                        });

                        $('table tbody').append(tbody);

                        // Pagination
                        if(data.pagination) {

                            $('.pagination').addClass('ajax-paginate');

                            $('.pagination').html(data.pagination);
                        }
                    }
                }
            }
        });
    }

    // Click on ajax page link
    $('.page-content').on('click', '.ajax-paginate a', function() {

        var search = $('input[name="search"]').val();

        if(search.length > 2) {

            get_users_list(search, $(this).attr('href'));
        } else {

            get_users_list('', $(this).attr('href'));
        }
             
        return false;
    });
</script>