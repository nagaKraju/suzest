<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <?php echo form_open_multipart($this->uri->uri_string(), array('class' => 'form-horizontal form-bordered')); ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo $this->config->item('auth_permissions_title'); ?></h6>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Role: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_dropdown('role', $roles, $this->input->post('role'), 'data-placeholder="Choose a Role..." class="select-search" tabindex="2"');
                                echo form_submit(array('value' => 'Show URI permissions', 'class' => 'btn btn-primary pull-right'));
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-10">
                            Allowed URI (One URI per line) :<br/><br/>
                            Input '/' to allow role access all URI.<br/>
                            Input '/controller/' to allow role access controller and it's function.<br/>
                            Input '/controller/function/' to allow role access controller/function only.<br/><br/>
                            These rules only have effect if you use check_uri_permissions() in your controller<br/><br/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">URIs: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_textarea(array('name' => 'allowed_uris', 'class' => 'form-control', 'placeholder' => 'Enter uris here', 'value' => set_value('allowed_uris', $allowed_uris)));
                                echo form_error('allowed_uris', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-actions text-right">
                        <?php echo form_submit(array('name' => 'save', 'value' => 'Save URI Permissions', 'class' => 'btn btn-primary')); ?>
                    </div>
                </div>

            </div>
        <?php echo form_close(); ?>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->