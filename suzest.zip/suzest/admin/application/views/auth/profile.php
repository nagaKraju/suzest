<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('auth_profile_title'); ?></h6>
                    <?php echo anchor(base_url($this->config->item('auth_change_password_uri')), 'Change Password', 'class="btn btn-success pull-right"'); ?>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Username: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user->username; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user->email; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Role: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user->role; ?></p>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->