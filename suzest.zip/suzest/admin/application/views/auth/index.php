<!-- Content -->
<div class="content">
	
    <div class="title"><h5>Admin Users</h5></div>

    <!-- Success Flash Message -->
    <?php $this->load->view($this->config->item('admin_success_view')); ?>
    <!-- Success Flash Message -->

    <!-- Failure Flash Message -->
    <?php $this->load->view($this->config->item('admin_failure_view')); ?>
    <!-- Failure Flash Message -->

    <!-- Static table -->
    <div class="widget first">
    	<div class="head">
            <h5 class="iFrames">Admin Users</h5>
        </div>
        <table cellpadding="0" cellspacing="0" width="100%" class="tableStatic">
        	<thead>
            	<tr>
                    <td>User Name</td>
                    <td>Email</td>
                    <td>Role</td>
                    <td>Actions</td>
                </tr>
            </thead>
            <?php if(!empty($users)): ?>
                <tbody>
                    <?php foreach($users as $user): ?>
                    	<tr>
                            <td align="center"><?php echo $user->username; ?></td>
                            <td align="center"><?php echo $user->email; ?></td>
                            <td align="center"><?php echo $user->role; ?></td>
                            <td align="center">
                                <?php
                                    echo anchor(base_url($this->dx_auth->change_role_uri.$user->id), form_button(array('class' => 'greenBtn', 'content' => 'Change Role')));
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php endif; ?>
        </table>
    </div>
</div>
<div class="fix"></div>