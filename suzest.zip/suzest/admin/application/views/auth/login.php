<!-- Page container -->
<div class="page-container container">
        
    <!-- Page content -->
    <div class="col-md-6 col-md-offset-3">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <?php echo form_open($this->uri->uri_string(), array('class' => 'form-horizontal form-bordered')); ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo $this->config->item('auth_login_title'); ?></h6>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Username: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_input(array('name' => 'email', 'class' => 'form-control', 'placeholder' => 'Enter email here', 'value' => set_value('email')));
                                echo form_error('email', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Password: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_password(array('name' => 'password', 'class' => 'form-control', 'placeholder' => 'Enter password here', 'value' => set_value('password')));
                                echo form_error('password', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-actions text-right clearfix">
                        <?php echo anchor(base_url($this->config->item('auth_forgot_password_uri')), 'Forgot password', 'class="pull-left"'); ?>
                        <?php echo form_submit(array('value' => 'Submit', 'class' => 'btn btn-primary')); ?>
                    </div>
                </div>

            </div>
        <?php echo form_close(); ?>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->