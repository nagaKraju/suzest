<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('auth_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <?php echo form_open_multipart($this->uri->uri_string(), array('class' => 'form-horizontal form-bordered')); ?>
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('auth_change_password_title'); ?></h6>
                    <?php echo anchor(base_url($this->config->item('auth_profile_uri')), 'Profile', 'class="btn btn-info pull-right"'); ?>
                    <?php echo anchor(base_url($this->config->item('auth_settings_uri')), 'Settings', 'class="btn btn-success pull-right"'); ?>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Old Password: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_password(array('name' => 'old_password', 'class' => 'form-control', 'placeholder' => 'Enter old password here', 'value' => set_value('old_password')));
                                echo form_error('old_password', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">New Password: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_password(array('name' => 'new_password', 'class' => 'form-control', 'placeholder' => 'Enter new password here', 'value' => set_value('new_password')));
                                echo form_error('new_password', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Confirm New Password: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_password(array('name' => 'confirm_new_password', 'class' => 'form-control', 'placeholder' => 'Enter confirm new password here', 'value' => set_value('confirm_new_password')));
                                echo form_error('confirm_new_password', '<label class="error">', '</label>'); 
                            ?>
                        </div>
                    </div>

                    <div class="form-actions text-right">
                        <?php echo form_submit(array('value' => 'Submit', 'class' => 'btn btn-primary')); ?>
                    </div>
                </div>

            </div>
        <?php echo form_close(); ?>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->