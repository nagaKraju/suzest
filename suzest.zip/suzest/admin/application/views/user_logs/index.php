<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('user_logs_header_title'); ?></h5>
        </div>
        <!-- /page title -->


        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('user_logs_index_title'); ?></h6>
                </div>

                <?php if(strtolower($this->dx_auth->get_role_name()) == 'admin'): ?>

                    <div class="panel-body">
                        <div class="form-group">
                            <div class="col-sm-4 has-feedback">
                                <?php 
                                    $filter = array(0 => 'Filter', 1 => 'Table', 2 => 'Email');
                                    echo form_dropdown('filter', $filter, $this->input->post('filter'), 'id="filter" class="select-search" tabindex="2"');
                                ?>
                            </div>
                            <div class="col-sm-4 has-feedback hide" id="table-filter">
                                <?php 
                                    $tables = array('' => 'Choose a Table') + $this->config->item('admin_tables');
                                    echo form_dropdown('table', $tables, $this->input->post('table'), 'id="table" class="select-search" tabindex="2"');
                                ?>
                            </div>
                            <div class="col-sm-4 has-feedback hide" id="email-filter">
                                <?php 
                                    $emails = array('' => 'Choose an Email') + $this->dx_auth->get_emails_list();
                                    echo form_dropdown('email', $emails, $this->input->post('email'), 'id="email" class="select-search" tabindex="2"');
                                ?>
                            </div>
                        </div>
                    </div>

                <?php else: ?>

                    <div class="panel-body">
                        <div class="form-group">
                            <div class="col-sm-12 has-feedback">
                                <?php echo form_input(array('name' => 'search', 'class' => 'form-control', 'placeholder' => 'Search here')); ?>
                                <i class="fa fa-search form-control-feedback"></i>
                            </div>
                        </div>
                    </div>

                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Table</th>
                                <th>Operation</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <?php if(!empty($user_logs)): ?>
                            <tbody>
                                <?php $i = (($offset - 1) * $limit) + 1; ?>
                                <?php foreach($user_logs as $user_log): ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo anchor(base_url($this->config->item('user_logs_view_uri').$user_log->id), $user_log->username); ?></td>
                                        <td><?php echo $user_log->email; ?></td>
                                        <td><?php echo $user_log->table; ?></td>
                                        <td>
                                            <?php
                                                switch($user_log->operation) {

                                                    case 1: 
                                                            echo 'Add';
                                                            break;
                                                    case 2: 
                                                            echo 'Update';
                                                            break;
                                                    case 3: 
                                                            echo 'Delete';
                                                            break;
                                                    case 4: 
                                                            echo 'Excel Upload';
                                                            break;
                                                    case 5: 
                                                            echo 'Excel Upload Delete';
                                                            break;
                                                }
                                            ?>
                                        </td>
                                        <td><?php echo date('dS M Y', strtotime($user_log->created)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php $this->load->view($this->config->item('pagination_view')); ?>
        <!-- /Pagination -->

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->

<script type="text/javascript">

    // Filter change
    $('#filter').change(function() {

        if($(this).val() == 1) {

            $('#email-filter').addClass('hide').removeClass('show');

            $('#table-filter').removeClass('hide').addClass('show');
        }

        if($(this).val() == 2) {

            $('#table-filter').addClass('hide').removeClass('show');

            $('#email-filter').removeClass('hide').addClass('show');
        }
    });

    // On change of table filter
    $('.panel-body').on('change', '#table, #email', function() {

        if($('#filter').val() && $(this).val()) {

            window.location.href = "<?php echo base_url($this->config->item('user_logs_filter_uri')); ?>/"+$('#filter').val()+'/'+$(this).val();
        }
    });

</script>

<script type="text/javascript">
    
    $('input[name="search"]').on('keyup',function() {

        var search = $(this).val();

        if(search.length > 2) {

            get_user_log_list(search, "<?php echo base_url($this->config->item('user_logs_ajax_get_user_logs_by_search_uri')); ?>"); 
        } else {

            get_user_log_list('', "<?php echo base_url($this->config->item('user_logs_ajax_get_user_logs_by_search_uri')); ?>"); 
        }
    });

    // Get user_log list
    function get_user_log_list(search, link) {

        $.ajax({
            type: "POST",
            url: link,
            async: false,
            dataType: 'json',
            data: {"search": search},
            processdata: true,
            success: function (data) {

                // Clear table data
                $('table tbody').empty();

                // Clear pagination
                $('.pagination').empty();

                if(data.response == true) {
                    
                    if(data.user_logs != 'undefined') {
                        
                        var tbody = '';

                        var i = (data.offset * data.limit) + 1;
                        $.each(data.user_logs, function(key, user_log) {

                            tbody += '<tr>';
                            tbody += '<td>'+(i++)+'</td>';
                            tbody += '<td><a href="<?php echo base_url($this->config->item('user_logs_view_uri')); ?>/'+user_log.id+'">'+user_log.name+'</a></td>';
                            tbody += '<td>'+user_log.email+'</td>';
                            tbody += '<td>'+user_log.table+'</td>';
                            switch(user_log.operation) {

                                case '1': 
                                        tbody += '<td>Add</td>';
                                        break;
                                case '2': 
                                        tbody += '<td>Update</td>';
                                        break;
                                case '3': 
                                        tbody += '<td>Delete</td>';
                                        break;
                                case '4': 
                                        tbody += '<td>Excel Upload</td>';
                                        break;
                                case '5': 
                                        tbody += '<td>Excel Upload Delete</td>';
                                        break;
                            }
                            tbody += '<td>'+user_log.created+'</td>';
                            tbody += '</tr>';
                        });

                        $('table tbody').append(tbody);

                        // Pagination
                        if(data.pagination) {

                            $('.pagination').addClass('ajax-paginate');

                            $('.pagination').html(data.pagination);
                        }
                    }
                }
            }
        });
    }

    // Click on ajax page link
    $('.page-content').on('click', '.ajax-paginate a', function() {

        var search = $('input[name="search"]').val();

        if(search.length > 2) {

            get_user_log_list(search, $(this).attr('href'));
        } else {

            get_user_log_list('', $(this).attr('href'));
        }

        return false;
    });
</script>