<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('user_logs_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('user_logs_index_title'); ?></h6>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-sm-4 has-feedback">
                            <?php 
                                $filter = array(0 => 'Filter', 1 => 'Table', 2 => 'Email');
                                echo form_dropdown('filter', $filter, set_value('filter', $this->uri->segment(3)), 'id="filter" class="select-search" tabindex="2"');
                            ?>
                        </div>
                        <div class="col-sm-4 has-feedback <?php echo ($this->uri->segment(3) == 1) ? 'show' : 'hide' ?>" id="table-filter">
                            <?php 
                                $tables = array('' => 'Choose a Table') + $this->config->item('admin_tables');
                                if($this->uri->segment(3) == 1):
                                    echo form_dropdown('table', $tables, set_value('table', $this->uri->segment(4)), 'id="table" class="select-search" tabindex="2"');
                                else:
                                    echo form_dropdown('table', $tables, set_value('table', $this->uri->segment(4)), 'id="table" class="select-search" tabindex="2"');
                                endif;
                            ?>
                        </div>
                        <div class="col-sm-4 has-feedback <?php echo ($this->uri->segment(3) == 2) ? 'show' : 'hide' ?>" id="email-filter">
                            <?php 
                                $emails = array('' => 'Choose an Email') + $this->dx_auth->get_emails_list();
                                if($this->uri->segment(3) == 2):
                                    echo form_dropdown('email', $emails,set_value('email', $this->uri->segment(4)), 'id="email" class="select-search" tabindex="2"');
                                else:
                                    echo form_dropdown('email', $emails,set_value('email', $this->uri->segment(4)), 'id="email" class="select-search" tabindex="2"');
                                endif;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Table</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <?php if(!empty($user_logs)): ?>
                            <tbody>
                                <?php $i = (($offset - 1) * $limit) + 1; ?>
                                <?php foreach($user_logs as $user_log): ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo anchor(base_url($this->config->item('user_logs_view_uri').$user_log->id), $user_log->username); ?></td>
                                        <td><?php echo $user_log->email; ?></td>
                                        <td><?php echo $user_log->table; ?></td>
                                        <td><?php echo date("l jS \of F Y h:i:s A", strtotime($user_log->created)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php $this->load->view($this->config->item('pagination_view')); ?>
        <!-- /Pagination -->

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->

<script type="text/javascript">

    // Filter function
    function filter(type, selected = '') {

        if(type == 1) {

            $('#email-filter').addClass('hide').removeClass('show');

            $('#table-filter').removeClass('hide').addClass('show');
        }

        if(type == 2) {

            $('#table-filter').addClass('hide').removeClass('show');

            $('#email-filter').removeClass('hide').addClass('show');
        }
    }

    // Filter change
    $('#filter').change(function() {

        filter($('#filter').val());
    });

    $('.panel-body').on('change', '#table, #email', function() {

        if($('#filter').val() >= 1 && $(this).val()) {

            window.location.href = "<?php echo base_url($this->config->item('user_logs_filter_uri')); ?>/"+$('#filter').val()+'/'+$(this).val();
        }
    });

</script>