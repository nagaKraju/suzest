<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('user_logs_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('user_logs_view_title'); ?></h6>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">User Name:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user_log->username; ?></p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user_log->email; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Table:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user_log->table; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Table:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static">
                                <?php 
                                    switch($user_log->operation) {

                                        case 1: 
                                                echo 'Add';
                                                break;
                                        case 2: 
                                                echo 'Update';
                                                break;
                                        case 3: 
                                                echo 'Delete';
                                                break;
                                    }
                                ?>
                            </p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Old Content:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user_log->old_content; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">New Content:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $user_log->new_content; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Created:</label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo date("l jS \of F Y h:i:s A", strtotime($user_log->created)); ?></p>
                        </div>
                    </div>

                </div>

            </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->