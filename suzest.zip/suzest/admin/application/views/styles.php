<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php header("Cache-Control: no-store, no-cache, must-revalidate"); ?>
<title><?php echo $this->config->item($this->router->fetch_class().'_'.$this->router->fetch_method().'_title'); ?></title>
<link rel="shortcut icon" href="<?php echo $this->config->item('main_url').$this->config->item('images_path').'favicon.ico?v=1'; ?>" type="image/x-icon">
<link href="<?php echo base_url($this->config->item('css_bootstrap_min')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url($this->config->item('css_brain_theme')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url($this->config->item('css_font_awesome_min')); ?>" rel="stylesheet" type="text/css">
<link href='<?php echo base_url($this->config->item('css_font_cuprum')); ?>' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url($this->config->item('css_styles')); ?>" rel="stylesheet" type="text/css">