<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('districts_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('districts_index_title'); ?></h6>
                    <?php echo anchor(base_url($this->config->item('districts_add_uri')), 'Add', 'class="btn btn-success pull-right"'); ?>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-sm-12 has-feedback">
                            <?php echo form_input(array('name' => 'search', 'class' => 'form-control', 'placeholder' => 'Search here')); ?>
                            <i class="fa fa-search form-control-feedback"></i>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <?php $this->load->view($this->config->item('districts_table_view')); ?>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php $this->load->view($this->config->item('pagination_view')); ?>
        <!-- /Pagination -->

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->

<script type="text/javascript">
    
    // Search
    $('input[name="search"]').search("<?php echo base_url($this->config->item('districts_ajax_get_districts_by_search_uri')); ?>");
</script>