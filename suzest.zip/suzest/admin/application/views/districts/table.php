<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Code</th>
            <th>State</th>
            <th>Country</th>
            <th>Slug</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <?php if(!empty($districts)): ?>
        <tbody>
            <?php $i = (($offset - 1) * $limit) + 1; ?>
            <?php foreach($districts as $district): ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $district->name; ?></td>
                    <td><?php echo $district->code; ?></td>
                    <td><?php echo $district->state; ?></td>
                    <td><?php echo $district->country; ?></td>
                    <td><?php echo $district->slug; ?></td>
                    <td><span class="label <?php echo ($district->status == 1) ? 'label-success' : 'label-danger'; ?>"><?php echo $this->config->item('districts_status')[$district->status]; ?></span></td>
                    <td><?php echo anchor(base_url($this->config->item('districts_edit_uri').$district->id), 'Edit', 'class="btn btn-info"'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php endif; ?>
</table>