<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Code</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <?php if(!empty($countries)): ?>
        <tbody>
            <?php $i = (($offset - 1) * $limit) + 1; ?>
            <?php foreach($countries as $country): ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo anchor(base_url($this->config->item('countries_view_uri').$country->id), $country->name); ?></td>
                    <td><?php echo $country->code; ?></td>
                    <td><span class="label <?php echo ($country->status == 1) ? 'label-success' : 'label-danger'; ?>"><?php echo $this->config->item('countries_status')[$country->status]; ?></span></td>
                    <td><?php echo anchor(base_url($this->config->item('countries_edit_uri').$country->id), 'Edit', 'class="btn btn-info"'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php endif; ?>
</table>