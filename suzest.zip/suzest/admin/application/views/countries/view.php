<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('countries_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="form-horizontal form-bordered">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <h6 class="panel-title"><?php echo $this->config->item('countries_view_title'); ?></h6>
                    <?php echo anchor(base_url($this->config->item('countries_edit_uri').$country->id), 'Edit', 'class="btn btn-info pull-right"'); ?>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Name: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $country->name; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Code: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $country->code; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Slug: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $country->slug; ?></p>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Code: </label>
                        <div class="col-sm-10">
                            <p class="form-control-static"><?php echo $country->code; ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Status: </label>
                        <div class="col-sm-10">
                            <span class="label <?php echo ($country->status == 1) ? 'label-success' : 'label-danger'; ?>"><?php echo $this->config->item('countries_status')[$country->status]; ?></span>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- timezone modal -->
<div id="timezone" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h5 class="modal-title"><?php echo $this->config->item('countries_add_timezones_title'); ?></h5>
            </div>

            <!-- Form inside modal -->
            <?php echo form_open('#', array('role' => 'form')); ?>

                <?php echo form_hidden('country_id', $country->id); ?>
                <div class="modal-body has-padding">
                    <div class="form-group">
                        <label>Timezones: </label>
                        <?php
                            $timezones = array('' => '') + $timezones;
                            echo form_dropdown('timezone_ids[]', $timezones, set_value('timezone_ids', $countries_timezones_list), 'multiple="multiple" data-placeholder="Choose a Timezone..." class="select-multiple" tabindex="2"');
                            echo form_error('timezone_ids', '<label class="error">', '</label>');
                        ?>
                    </div>
                </div>

                <div class="modal-footer">
                    <?php echo form_button(array('content' => 'Close', 'class' => 'btn btn-warning', 'data-dismiss' => 'modal')); ?>
                    <?php echo form_submit(array('value' => 'Submit', 'class' => 'btn btn-primary')); ?>
                </div>

            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<!-- /timezone modal -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->

<script type="text/javascript" src="<?php echo base_url($this->config->item('js_multiselect')); ?>"></script>

<script type="text/javascript">

    $(".select-multiple").select2({
        width: "100%"
    });

    // On click of add timezone
    $('#add-timezone').click(function(e) {

        e.preventDefault();

        // Show modal
        $('#timezone').modal('show');
    });

    // On Submit of form
    $('#timezone form').submit(function(e) {

        e.preventDefault();

        var obj = $(this);

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('countries_ajax_add_timezones_uri')); ?>",
            async: false,
            dataType: 'json',
            data: obj.serialize(),
            success: function (data) {

                // Remove validation errors
                obj.find('.error').remove();

                if(data.response == false) {
                    
                    if(data.validations != 'undefined') {
                        
                        $.each(data.validations, function(key, value) {

                            obj.find('select[name="'+key+'[]"]').after(value);
                        });
                    }
                }

                if(data.response == true) {

                    location.reload();
                }
            }
        });
    });
</script>
