<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">

        <?php if($this->dx_auth->is_logged_in()): ?>
            <div class="navbar-header">
                <div class="hidden-lg pull-right">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-right">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-chevron-down"></i>
                    </button>

                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar">
                        <span class="sr-only">Toggle sidebar</span>
                        <i class="fa fa-bars"></i>
                    </button>
                </div>

                <ul class="nav navbar-nav navbar-left-custom">
                    <li class="user dropdown">
                        <?php if($this->dx_auth->is_logged_in()): ?>
                            <a class="dropdown-toggle" data-toggle="dropdown">
                                <span><?php echo $this->dx_auth->get_role_name().' - '.$this->dx_auth->get_username(); ?></span>
                                <i class="caret"></i>
                            </a>
                            <ul class="dropdown-menu">
                                <li><?php echo anchor(base_url($this->config->item('auth_profile_uri')), '<i class="fa fa-user"></i> Profile'); ?></li>
                                <li><?php echo anchor(base_url($this->config->item('auth_change_password_uri')), '<i class="fa fa-cog"></i> Change Password'); ?></li>
                                <li><?php echo anchor(base_url($this->config->item('auth_logout_uri')), '<i class="fa fa-mail-forward"></i> Logout'); ?></li>
                            </ul>
                        <?php endif; ?>
                    </li>
                    <li><a class="nav-icon sidebar-toggle"><i class="fa fa-bars"></i></a></li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>