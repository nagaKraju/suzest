<div class="container">
    <div class="page-header">
        <div class="logo">
            <?php echo anchor($this->config->item('main_url'), img(array('src' => $this->config->item('main_url').$this->config->item('images_path').$this->config->item('website_logo')))); ?>
        </div>
    </div>
</div>
