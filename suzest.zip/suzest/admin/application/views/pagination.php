<?php if(!empty($pagination)): ?>
    <div class="well">
        <ul class="pagination">
            <?php 
                echo $pagination;
            ?>
        </ul>
    </div>
<?php endif; ?>