<?php if($this->session->flashdata('flash_failure')): ?>
<script type="text/javascript">
	$.jGrowl(
		"<?php echo $this->session->flashdata('flash_failure'); ?>", 
		{	
			sticky: false, 
			theme: 'growl-error', 
			header: 'Error!' 
		}
	);
</script>
<?php endif; ?>
<?php if(isset($error) && !empty($error)): ?>
<script type="text/javascript">
	$.jGrowl(
		"<?php echo $error; ?>", 
		{	
			sticky: true, 
			theme: 'growl-error', 
			header: 'Error!' 
		}
	);
</script>
<?php endif; ?>