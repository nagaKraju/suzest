<?php if($this->session->flashdata('flash_success')): ?>
<script type="text/javascript">
	$.jGrowl(
		"<?php echo $this->session->flashdata('flash_success'); ?>", 
		{	
			sticky: false, 
			theme: 'growl-success', 
			header: '' 
		}
	);
</script>
<?php endif; ?>