<?php
    $class_name = $this->router->fetch_class();
    $method_name = $this->router->fetch_method();
?>
<div class="sidebar collapse">
    <ul class="navigation">
        <li <?php echo ($class_name == 'dashboard') ? 'class="active"' : ''; ?>>
            <?php echo anchor(base_url($this->config->item('dashboard_index_uri')), '<i class="fa fa-laptop"></i> Dashboard'); ?>
        </li>
        <?php 
            $class = '';
            $id = '';
            if($class_name == 'countries' || $class_name == 'states' || $class_name == 'districts' || $class_name == 'mandals' || $class_name == 'zones'):
                $class = 'class="active"';
                $id = 'id="second-level"';
            endif;
        ?>
        <li <?php echo $class; ?>>
            <?php echo anchor(base_url('#'), '<i class="fa fa-table"></i> Master Tables', 'class="expand" '.$id); ?>
            <ul>
                <li <?php echo ($class_name == 'countries') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('countries_index_uri')), 'Countries'); ?>
                </li>
                <li <?php echo ($class_name == 'states') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('states_index_uri')), 'States'); ?>
                </li>
                <li <?php echo ($class_name == 'zones') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('zones_index_uri')), 'Zones'); ?>
                </li>
                <li <?php echo ($class_name == 'districts') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('districts_index_uri')), 'Districts'); ?>
                </li>
                <li <?php echo ($class_name == 'mandals') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('mandals_index_uri')), 'Mandals'); ?>
                </li>
            </ul>
        </li>
        <?php
            $class = '';
            $id = '';
            if($class_name == 'auth' || $class_name == 'roles'):
                $class = 'class="active"';
                $id = 'id="second-level"';
            endif;
        ?>
        <li <?php echo $class; ?>>
            <?php echo anchor(base_url($this->config->item('auth_index_uri')), '<i class="fa fa-table"></i> Users and Access Control', 'class="expand" '.$id);  ?>
            <ul>
                <li <?php echo ($class_name == 'auth' && ($method_name == 'users' || $method_name == 'edit')) ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('auth_users_uri')), 'Users'); ?>
                </li>
                <li <?php echo ($class_name == 'roles') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('roles_index_uri')), 'Roles'); ?>
                </li>
                <li <?php echo ($class_name == 'auth' && $method_name == 'permissions') ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('auth_permissions_uri')), 'Permissions'); ?>
                </li>
            </ul>
        </li>
        <li <?php echo ($class_name == 'user_logs') ? 'class="active"' : ''; ?>>
            <?php echo anchor(base_url($this->config->item('user_logs_index_uri')), '<i class="fa fa-table"></i> User Logs'); ?>
        </li>
        <li <?php echo $class; ?>>
            <?php echo anchor(base_url($this->config->item('forms_index_uri')), '<i class="fa fa-table"></i> Forms', 'class="expand" '.$id);  ?>
            <ul>
                <li <?php echo ($this->router->fetch_class() == 'forms' && ($this->router->fetch_method() == 'contact_us' )) ? 'class="active"' : ''; ?>>
                    <?php echo anchor(base_url($this->config->item('forms_contact_us_uri')), 'Contact Us'); ?>
                </li>

            </ul>
        </li>
    </ul>
</div>