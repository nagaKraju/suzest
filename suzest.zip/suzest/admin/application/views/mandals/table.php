<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Code</th>
            <th>District</th>
            <th>Zone</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <?php if(!empty($mandals)): ?>
        <tbody>
            <?php $i = (($offset - 1) * $limit) + 1; ?>
            <?php foreach($mandals as $mandal): ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $mandal->name; ?></td>
                    <td><?php echo $mandal->code; ?></td>
                    <td><?php echo $mandal->district; ?></td>
                    <td><?php echo $mandal->zone; ?></td>
                    <td><?php echo $mandal->slug; ?></td>
                    <td><span class="label <?php echo ($mandal->status == 1) ? 'label-success' : 'label-danger'; ?>"><?php echo $this->config->item('mandals_status')[$mandal->status]; ?></span></td>
                    <td><?php echo anchor(base_url($this->config->item('mandals_edit_uri').$mandal->id), 'Edit', 'class="btn btn-info"'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php endif; ?>
</table>