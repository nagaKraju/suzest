<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('mandals_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <?php echo form_open($this->uri->uri_string(), array('class' => 'form-horizontal form-bordered')); ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo $this->config->item('mandals_add_title'); ?></h6>
                </div>

                <div class="panel-body">

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Country: </label>
                        <div class="col-sm-10">
                            <?php
                                $countries = array('' => '') + $countries;
                                echo form_dropdown('country_id', $countries, $this->input->post('country_id'), 'data-placeholder="Choose a Country..." class="select-search" tabindex="2"');
                                echo form_error('country_id', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">State: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_dropdown('state_id', array('' => ''), $this->input->post('state_id'), 'data-placeholder="Choose a State..." class="select-search" tabindex="2"');
                                echo form_error('state_id', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">District: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_dropdown('district_id', array('' => ''), $this->input->post('district_id'), 'data-placeholder="Choose a District..." class="select-search" tabindex="2"');
                                echo form_error('district_id', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Zone: </label>
                        <div class="col-sm-10">
                            <?php
                                $zones = array('' => '') + $zones;
                                echo form_dropdown('zone_id', $zones, $this->input->post('zone_id'), 'data-placeholder="Choose a Zone..." class="select-search" tabindex="2"');
                                echo form_error('zone_id', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Name: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_input(array('name' => 'name', 'class' => 'form-control', 'placeholder' => 'Enter name here', 'value' => set_value('name')));
                                echo form_error('name', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">code: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_input(array('name' => 'code', 'class' => 'form-control', 'placeholder' => 'Enter code here', 'value' => set_value('code')));
                                echo form_error('code', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Slug: </label>
                        <div class="col-sm-10">
                            <?php
                                echo form_input(array('name' => 'slug', 'class' => 'form-control', 'placeholder' => 'Enter slug here', 'value' => set_value('slug')));
                                echo form_error('slug', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Status: </label>
                        <div class="col-sm-10">
                            <?php
                            $statuses = $this->config->item('mandals_status');
                                echo form_dropdown('status', $statuses, set_value('status', 1), 'data-placeholder="Choose a Status..." class="select-search" tabindex="2"');
                                echo form_error('status', '<label class="error">', '</label>');
                            ?>
                        </div>
                    </div>

                    <div class="form-actions text-right">
                        <?php echo form_submit(array('value' => 'Submit', 'class' => 'btn btn-primary')); ?>
                    </div>
                </div>

            </div>
        <?php echo form_close(); ?>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->
<!-- Scripts -->
<script type="text/javascript">

    // On load of body
    $(function() {

        // Check country selected
        if($('select[name="country_id"]').val()) {

            // Get states
            get_states($('select[name="country_id"]').val(), "<?php echo $this->input->post('state_id'); ?>");
        }

    });

    // On load of body
    $(function() {

        // Check state selected
        if($('select[name="state_id"]').val()) {

            // Get Districts
            get_districts($('select[name="state_id"]').val(), "<?php echo $this->input->post('district_id'); ?>");
        }
    });

    // On change of country
    $('select[name="country_id"]').change(function () {

        // Empty the country and state dropdown
        $('select[name="state_id"]').empty();

        // Check value exist
        if ($(this).val()) {

            get_states($(this).val(), 0);
        }
    });

    // On change of state
    $('select[name="state_id"]').change(function () {

        // Empty the country and District dropdown
        $('select[name="district_id"]').empty();

        // Check value exist
        if ($(this).val()) {

            get_districts($(this).val(), 0);
        }
    });

    // Get states
    function get_states(country_id, state_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('countries_ajax_get_states_by_country_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"country_id": country_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.states != 'undefined') {

                        var options = '<option value=""></option>';

                        $.each(data.states, function (key, value) {

                            if (state_id == value.id) {

                                options += '<option value="' + value.id + '" selected="selected">' + value.name + '</option>';
                            } else {

                                options += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        });

                        $('select[name="state_id"]').html(options);

                        $('select[name="state_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }

    // Get Districts
    function get_districts(state_id, district_id) {

        $.ajax({
            type: "POST",
            url: "<?php echo base_url($this->config->item('states_ajax_get_districts_by_state_id_uri')); ?>",
            dataType: "json",
            async: false,
            data: {"state_id": state_id},
            success: function (data) {

                if (data.response == true) {

                    if (data.districts != 'undefined') {

                        var options = '<option value=""></option>';

                        $.each(data.districts, function (key, value) {

                            if (district_id == value.id) {

                                options += '<option value="' + value.id + '" selected="selected">' + value.name + '</option>';
                            } else {

                                options += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        });

                        $('select[name="district_id"]').html(options);

                        $('select[name="district_id"]').select2({
                            width: 200
                        });
                    }
                }
            }
        });
    }
</script>
<!-- Scripts -->