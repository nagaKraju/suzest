<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('roles_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <h6 class="panel-title"><?php echo $this->config->item('roles_index_title'); ?></h6>
                <?php echo anchor(base_url($this->config->item('roles_add_uri')), 'Add', 'class="btn btn-success pull-right"'); ?>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <?php if(!empty($roles)): ?>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach($roles as $role): ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $role->name; ?></td>
                                    <td>
                                        <?php
                                            echo anchor(base_url($this->config->item('roles_edit_uri').$role->id), 'Edit', 'class="btn btn-info"');  
                                            echo ' ';   
                                            echo anchor(base_url($this->config->item('roles_ajax_delete_uri').$role->id), 'Delete', 'class="btn btn-danger delete"');
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    <?php endif; ?>
                </table>
            </div>
        </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->