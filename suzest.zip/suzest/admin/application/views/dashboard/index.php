<!-- Page container -->
<div class="page-container container">
        
    <!-- Sidebar -->
    <?php $this->load->view($this->config->item('sidebar_view')) ?>
    <!-- /sidebar -->

    <!-- Page content -->
    <div class="page-content">

        <!-- Page title -->
        <div class="page-title">
            <h5><i class="fa fa-table"></i> <?php echo $this->config->item('dashboard_header_title'); ?></h5>
        </div>
        <!-- /page title -->

        <div class="panel panel-default">
            <div class="panel-heading">
                <h6 class="panel-title"><?php echo $this->config->item('dashboard_orders_title'); ?></h6>
            </div>

            <div class="panel-body">
                <td>
                    <?php echo anchor(base_url("user_logs"), 'View user logs', 'class="btn btn-danger"');?>
                </td>
            </div>

        </div>

        <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo $this->config->item('dashboard_forms_title'); ?></h6>
                    <?php echo anchor(base_url("countires"), 'View all countires','class= "btn pull-right"'); ?>
                </div>

                <div class="panel-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Code</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <?php if(!empty($countires)): ?>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach($countires as $country): ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo anchor(base_url($this->config->item('countires_view_uri').$country->id), $country->name); ?></td>
                                        <td><?php echo $country->code; ?></td>
                                        <td><?php echo $country->status; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        <?php endif; ?>
                    </table>
                </div>
        </div>

        <!-- Footer -->
        <?php $this->load->view($this->config->item('footer_view')); ?>
        <!-- /footer -->

    </div>
    <!-- /page content -->

</div>
<!-- page container -->

<!-- Scripts -->
<?php $this->load->view($this->config->item('scripts_view')); ?>
<!-- Scripts -->