<div class="footer">
    &copy; Copyright <?php echo date("Y"); ?>. All rights reserved, <?php echo $this->config->item('website_title'); ?> Inc.
</div>

<!-- Delete modal -->
<div id="delete_modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h5 class="modal-title">Are you sure you want to delete this record?</h5>
            </div>

            <div class="modal-footer">
                <button class="btn btn-warning" data-dismiss="modal">No</button>
                <button class="btn btn-primary" id="yes" data-url="" data-redirect="">Yes</button>
            </div>
        </div>
    </div>
</div>
<!-- /Delete modal -->

<!-- Timezone Modal -->
<?php if($this->dx_auth->is_logged_in()): ?>
    <div id="timezone-modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h5 class="modal-title">Change your location</h5>
                </div>

                <form action="javascript:void(0);" id="timezone-form">
                    <div class="modal-body has-padding">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Country: </label>
                                    <?php echo form_dropdown('country_id',  array('' => 'Select Country'), '', 'data-placeholder="Choose a Country..." class="select-search" tabindex="2" style="display: block"'); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>City: </label>
                                    <?php echo form_dropdown('city_id', array('' => 'Select City'), '', 'data-placeholder="Choose a City..." class="select-search" tabindex="2" style="display: block"'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <?php echo form_button(array('content' => 'Close', 'class' => 'btn btn-warning', 'data-dismiss' => 'modal')); ?>
                        <?php echo form_submit(array('value' => 'Submit', 'class' => 'btn btn-primary')); ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
<!-- /Timezone Modal -->