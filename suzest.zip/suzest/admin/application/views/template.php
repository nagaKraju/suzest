<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- styles -->
        <?php $this->load->view($this->config->item('styles_view')); ?>
        <!-- /styles -->
    </head>
    <body>
        <!-- Navbar -->
        <?php $this->load->view($this->config->item('navbar_view')); ?>
        <!-- /navbar -->
        <!-- Page header -->
        <?php $this->load->view($this->config->item('page_header_view')); ?>
        <!-- /page header -->
        <!-- Content -->
        <?php $this->load->view($this->config->item($this->router->fetch_class().'_'.$this->router->fetch_method().'_view')); ?>
        <!-- Content -->
    </body>
</html>
