<script type="text/javascript" src="<?php echo base_url($this->config->item('js_jquery_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_jquery_ui_min')); ?>"></script>

<script type="text/javascript" src="<?php echo base_url($this->config->item('jquery_bpopup_min')); ?>"></script>

<script type="text/javascript" src="<?php echo base_url($this->config->item('js_uniform_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_select2_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_autosize')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_listbox')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_tags_min')); ?>"></script>

<script type="text/javascript" src="<?php echo base_url($this->config->item('js_jgrowl_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_prettify')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_fancybox_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_timepicker_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_collapsible_min')); ?>"></script>

<script type="text/javascript" src="<?php echo base_url($this->config->item('js_bootstrap_min')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_search')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_application')); ?>"></script>
<script type="text/javascript" src="<?php echo base_url($this->config->item('js_moment')); ?>"></script>
<?php $this->load->view($this->config->item('success_view')); ?>
<?php $this->load->view($this->config->item('failure_view')); ?>