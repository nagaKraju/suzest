<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- styles -->
        <?php $this->load->view($this->config->item('styles_view')); ?>
        <!-- /styles -->
    </head>

    <body>

        <!-- Content -->
        <?php $this->load->view($this->config->item($this->router->fetch_class().'_'.$this->router->fetch_method().'_view')); ?>
        <!-- Content -->
    </body>
</html>
