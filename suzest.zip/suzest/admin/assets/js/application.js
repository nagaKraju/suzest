
/* ========================================================
*
* It's Brain - premium responsive admin template
*
* ========================================================
*
* File: application_blank.js;
* Description: Minimum of necessary js code for blank page.
* Version: 1.0
*
* ======================================================== */



$(function() {

/* # Bootstrap Multiselects
================================================== */

/* # Select2 dropdowns 
================================================== */

	//===== Default select =====//

	$(".select").select2({
		minimumResultsForSearch: "-1",
		width: 200
	});


	//===== Select with filter input =====//

	$(".select-search").select2({
		width: 200
	});


	//===== jGrowl notifications defaults =====//

	$.jGrowl.defaults.closer = false;
	$.jGrowl.defaults.easing = 'easeInOutCirc';

	//===== Code prettifier =====//

    window.prettyPrint && prettyPrint();


	//===== Fancy box (lightbox plugin) =====//

	$(".lightbox").fancybox({
		padding: 1
	});

/* # Bootstrap Plugins
================================================== */
	

	//===== Tooltip =====//

	$('.tip').tooltip();

	//===== Popover =====//

	$("[data-toggle=popover]").popover().click(function(e) {
		e.preventDefault()
	});



	//===== Loading button =====//

	$('.btn-loading').click(function () {
		var btn = $(this)
		btn.button('loading')
		setTimeout(function () {
			btn.button('reset')
		}, 3000)
	});


	//===== Add fadeIn animation to dropdown =====//

	$('.dropdown, .btn-group').on('show.bs.dropdown', function(e){
		$(this).find('.dropdown-menu').first().stop(true, true).fadeIn(100);
	});


	//===== Add fadeOut animation to dropdown =====//

	$('.dropdown, .btn-group').on('hide.bs.dropdown', function(e){
		$(this).find('.dropdown-menu').first().stop(true, true).fadeOut(100);
	});


/* # Interface Related Plugins
================================================== */

	//===== Collapsible navigation =====//
	
	$('.expand').collapsible({
		defaultOpen: 'second-level, third-level',
		cssOpen: 'level-opened',
		cssClose: 'level-closed',
		speed: 150
	});
        
 	//===== Form elements styling =====//
       
	$(".styled").uniform({ radioClass: 'choice', selectAutoWidth: false });



/* # Default Layout Options
================================================== */

	//===== Hiding sidebar =====//

	$('.sidebar-toggle').click(function () {
		$('.page-container').toggleClass('hidden-sidebar');
	});


/* # Custom Scripts
================================================== */

	// Confirm Dialog
	$('.page-content').on('click', '.delete', function(e) {

		e.preventDefault();

		$('#delete_modal').modal('show');

		url = $(this).attr('href');
		redirect = $(this).data('redirect');

		// Links
		$('#delete_modal #yes').attr('data-url', url).attr('data-redirect', redirect);
	});

	// On click of yes
	$('#delete_modal #yes').click(function(e) {

		e.preventDefault();

		url = $(this).data('url');
		redirect = $(this).data('redirect');

		$.ajax({
            type: "POST",
            url: url,
            async: false,
            dataType: 'json',
            success: function (data) {

                if(data.response == true) {
                    
                    window.location.href = redirect;
                } else {

                	$.jGrowl(
						data.message, 
						{	
							sticky: false, 
							theme: 'growl-error', 
							header: 'Error!' 
						}
					);
                }
            }
        });
	});

	// If error exist
	if($('label').hasClass('error')) {

		$("html, body").animate({ scrollTop: $('label.error').offset().top - 100}, 1000);
	}

	// Fixed top
	$('#fixed-top').affix({
		offset: {
			top: 50
		}
	});
});