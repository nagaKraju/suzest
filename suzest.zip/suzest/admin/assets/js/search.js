
// Search
$.fn.search = function(link) {

	var timer;

	$(this).on('keyup', function() {

		var str = $(this).val();

	    clearTimeout(timer);

	    timer = setTimeout(function() {

	        if(str.length >= 3) {

	            get_list(str, link); 
	        } else {

                get_list('', link); 
	        }
	        
	    }, 800);
	});
};

// Get list
function get_list(str, link) {

    $.ajax({
        type: "POST",
        url: link,
        dataType: "json",
        async: false,
        data: {"search": str},
        processdata: true,
        success: function (data) {

            // Clear table data
            $('.table-responsive').empty();

            // Clear pagination
            $('.pagination').parent().remove();

            if(data.response == true) {
                
                if(data.data != 'undefined') {
                    
                    $('.table-responsive').append(data.data);

                    // Pagination
                    if(data.pagination) {

                        $('.footer').before(data.pagination)

                        $('.pagination').addClass('ajax-paginate');
                    }
                }
            }
        }
    });
}

// Click on ajax page link
$('.page-content').on('click', '.ajax-paginate a', function(e) {

    e.preventDefault();

    var str = $('input[name="search"]').val();

    if(str.length >= 3 || str == "active" || str == "inactive") {

        get_list(str, $(this).attr('href'));
    } else {

        get_list('', $(this).attr('href'));
    }

    return false;
});